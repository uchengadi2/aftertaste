# ext-theme-neptune-fbd31635-8e81-4cfa-bfe3-33d3936d8d77/resources

This folder contains static resources (typically an `"images"` folder as well).
