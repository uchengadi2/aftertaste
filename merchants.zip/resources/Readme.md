# ext-theme-neptune-f24e27bc-37af-43ed-9972-f3284e7acd35/resources

This folder contains static resources (typically an `"images"` folder as well).
