<?php

class DomainVerificationController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listallDomainVerificationRequestForARequestor','listTheDomainForVerification',
                                    'addanewdomainverificationrequest','getDomainVerificationExtraDetails','updatedomainverificationrequest',
                                    'replaceverificationprimarysupportfile','listTheResultOfVerifiedDomainsForAMember','reverifydomainverificationrequest',
                                    'listdomainallverifiedrequests','ListAllDomainsWithAwaitingVerificationRequests','verifyingASubjectDomainVerificationRequest',
                                    'listdomainallconsummablerequests','getConsummableDomainVerificationExtraDetails'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all user verification request by a user
         */
        public function actionlistallDomainVerificationRequestForARequestor(){
            
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='requestor_id=:requestor and status=:status';
            $criteria->params = array(':requestor'=>$user_id,':status'=>'requested');
            $verifications = DomainVerification::model()->findAll($criteria); 
            
            if($verifications===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verification" => $verifications,
                                    
                    
                            ));
                       
                         }
        }
        
        
          /** 
          * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        /**
         * This is the function that retrieves tyhe domain for verification
         */
        public function actionlistTheDomainForVerification(){
            $model = new ResourceGroupCategory;
            $userid = Yii::app()->user->id;
            
            $user_domain_id = $this->determineAUserDomainIdGiven($userid);
            $country_id = $_REQUEST['country'];
            $domain_type = strtolower($_REQUEST['domain_type']);
            $search_string = $_REQUEST['search_string'];
            $category = $_REQUEST['category'];
           // $start = $_REQUEST['start'];
            //$limit = $_REQUEST['limit'];
            
            if($search_string ==""){//search string was not provided
                //if the industry was not given
                if($category == "" or $category=='all'){
                    
                    if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type';
                        $criteria->params = array(':type'=>"$domain_type");
                        $criteria->order = 'id';
                       // $criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains= ResourceGroupCategory::model()->findAll($criteria);
                        
                        //get the total script count
                        $count = $model->getTheTotalCountOfThisScriptWithDomainType($domain_type);
            
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        } else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" => $domains,
                                    "results"=>$count
                          
                           
                           
                          
                            ));
                       
                         }
                        
                        
                    }else{//country was provided
                        //retrieve the domains based on the country and domain type
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type and country_id=:countryid';
                        $criteria->params = array(':type'=>"$domain_type",':countryid'=>$country_id);
                        $criteria->order = 'id';
                       // $criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains= ResourceGroupCategory::model()->findAll($criteria);
                        
                        //get the total script count
                        $count = $model->getTheTotalCountOfThisScriptWithDomainTypeAndCountry($domain_type,$country_id);
            
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        } else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" => $domains,
                                    "results"=>$count
                          
                           
                           
                          
                            ));
                       
                         }
                        
                        
                    }
                    
                    
                    
                    
                }else{//industry was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){
                        //retrieve the domain based on the industry(category), and domain type
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type and category=:category';
                        $criteria->params = array(':type'=>"$domain_type", ':category'=>"$category");
                        $criteria->order = 'id';
                        //$criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains= ResourceGroupCategory::model()->findAll($criteria);
                        
                        //get the total script count
                        $count = $model->getTheTotalCountOfThisScriptWithDomainTypeAndCategory($domain_type,$category);
            
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        } else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" => $domains,
                                    "results"=>$count
                          
                           
                           
                          
                            ));
                       
                         }
                        
                    }else{
                        //retrieve the domain based on the industry(category), country and domain type
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type and (category=:category and country_id=:countryid)';
                        $criteria->params = array(':type'=>"$domain_type", ':category'=>"$category",':countryid'=>$country_id);
                        $criteria->order = 'id';
                       // $criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains= ResourceGroupCategory::model()->findAll($criteria);
                        
                        //get the total script count
                        $count = $model->getTheTotalCountOfThisScriptWithDomainTypeCategoryAndCountry($domain_type,$category,$country_id);
            
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" => $domains,
                                    "results"=>$count
                          
                           
                           
                          
                            ));
                       
                         }
                    }
                    
                    
                    
                    
                }
                
                
                
                
                
                
                
            }else{//search string wss provided
                $search_preference = strtolower($_REQUEST['search_preference']);
                
                //if the industry was not given
                if($category == "" or $category =='all'){
                    
                    if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type, search_preference and the search string
                        if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                           foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id'];
                                   
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                    
                                }
                                
                               
                                 
                             }
                                                       
                         
                        }
                        
                        $count = 0;
                       //retrieve all the searched domains
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type';   
                        $criteria->params = array(':type'=>"$domain_type");
                        $criteria->order = "id";
                       // $criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains = ResourceGroupCategory::model()->findAll($criteria);
                        
                       foreach($domains as $doma){
                            if(in_array($doma['id'],$all_domain_string_ids)){
                                $searchable_items[] = $doma;
                                $count = $count + 1;
                            }
                           
                        }
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                   "domain" => $searchable_items,
                                    "results"=>$count,
                                    "all_string"=>$all_domain_string_ids,
                                    "domainss"=>$domains
                          
                           
                           
                          
                            ));
                       
                         }
                        
                        
                    }else{//country was provided
                        //retrieve the domains based on the country, search_preference, domain type and the search string
                        if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                    
                                }
                                
                               
                                 
                             }
                                                       
                         
                        }
                        
                        $count = 0;
                        //retrieve all the searched domains
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type and country_id=:countryid';   
                        $criteria->params = array(':type'=>"$domain_type",':countryid'=>$country_id);
                        $criteria->order = "id";
                        //$criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains = ResourceGroupCategory::model()->findAll($criteria);
                        
                        foreach($domains as $doma){
                            if(in_array($doma['id'],$all_domain_string_ids)){
                                $searchable_items[] = $doma;
                                $count = $count + 1;
                            }
                           
                        }
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                   "domain" => $searchable_items,
                                    "results"=>$count,
                                    "all_string"=>$all_domain_string_ids,
                                    "domainss"=>$domains
                           
                           
                          
                            ));
                       
                         }
                        
                    }
                    
                    
                    
                    
                }else{//industry was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){//country was not provided
                       //retrieve the domain based on the industry(category), search_preference, domain type and the search strings
                        if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                    
                                }
                                
                               
                                 
                             }
                                                       
                         
                        }
                        
                        $count = 0;
                        //retrieve all the searched domains
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type and category=:category';   
                        $criteria->params = array(':type'=>"$domain_type",':category'=>"$category");
                        $criteria->order = "id";
                       // $criteria->offset = $start;
                        //$criteria->limit = $limit;     
                        $domains = ResourceGroupCategory::model()->findAll($criteria);
                        
                       foreach($domains as $doma){
                            if(in_array($doma['id'],$all_domain_string_ids)){
                                $searchable_items[] = $doma;
                                $count = $count + 1;
                            }
                           
                        }
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                   "domain" => $searchable_items,
                                    "results"=>$count,
                                    "all_string"=>$all_domain_string_ids,
                                    "domainss"=>$domains
                          
                           
                           
                          
                            ));
                       
                         }
                        
                        
                    }else{
                        //retrieve the domain based on the industry(category), search_preference, country, domain type and the search strings
                         if($search_preference == strtolower('byname')){
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                                 foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where name REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                   
                                }
                                 
                             }
                       
                            
                        }else{
                            $searchstring = explode('+',$search_string);
                            $searchWords = preg_replace('/\s/', '', $searchstring);
                            $searchable_items = [];
                            $all_domain_string_ids = [];
                            
                             foreach($searchWords as $word){
                                 $q = "SELECT id FROM resourcegroupcategory where rc_number REGEXP '$word'" ;
                                 $cmd = Yii::app()->db->createCommand($q);
                                 $results = $cmd->query();
                                 foreach($results as $res){
                                    $all_domain_string_ids[] = $res['id']; 
                                    
                                }
                                
                               
                                 
                             }
                                                       
                         
                        }
                        
                        $count = 0;
                        //retrieve all the searched domains
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_type=:type and (country_id=:countryid and category=:category)';   
                        $criteria->params = array(':type'=>"$domain_type",':countryid'=>$country_id,':category'=>"$category");
                        $criteria->order = "id";
                       // $criteria->offset = $start;
                       // $criteria->limit = $limit;     
                        $domains = ResourceGroupCategory::model()->findAll($criteria);
                        
                        foreach($domains as $doma){
                            if(in_array($doma['id'],$all_domain_string_ids)){
                                $searchable_items[] = $doma;
                                $count = $count + 1;
                            }
                           
                        }
                        if($domains===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" => $searchable_items,
                                    "results"=>$count,
                                    "all_string"=>$all_domain_string_ids,
                                    "domainss"=>$domains
                          
                           
                           
                          
                            ));
                       
                         }
                    }
                    
                    
                    
                }
                
                
                
            }
            
        }
        
        
        /**
         * This is the function that adds new verification request
         */
        public function actionaddanewdomainverificationrequest(){
            
            $model = new DomainVerification;
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->domain_id = $_REQUEST['id'];
            $model->issue_of_verification = $_REQUEST['verification_issue'];
            $model->status = strtolower('requested');
            $model->requestor_domain_id = $domain_id;
            $model->domain_type = $_REQUEST['domain_type'];
            $model->requestor_id = $user_id;
            $model->date_requested = new CDbExpression('NOW()');
            
            $icon_error_counter = 0;
            if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "A new verification request is successfully added";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to add a new user verification request was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while adding a new user verification request";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
        }
        
        
         /**
         * This is the function that gets verification extra details
         */
        public function actiongetDomainVerificationExtraDetails(){
            
             $domain_id = $_REQUEST['id'];
             $issue_for_verification = $_REQUEST['issue_for_verification'];
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $user = ResourceGroupCategory::model()->find($criteria);
            
            $name = $user['name'];
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>"$issue_for_verification");
            $verification = VerificationCost::model()->find($criteria);
            
            if($verification['is_cost_quotable'] == 0){
                $cost =  $verification['cost'];
            }else{
                $cost = 0;
            }
            
            //get the consumption cost
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>"$issue_for_verification");
            $consumption = ConsumptionCost::model()->find($criteria);
            
            if($consumption['is_cost_quotable'] == 0){
                $consumption_cost =  $consumption['cost'];
            }else{
                $consumption_cost = 0;
            }
            
            if($user===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "name" => $name,
                                     "verification_cost" => $cost,
                                    "consumption_cost"=>$consumption_cost
                                    
                    
                            ));
                       
                         }
            
        }
        
        /**
         * This is the function that updates a domain verification request
         */
        public function actionupdatedomainverificationrequest(){
            
            $model = new DomainVerification;
            $issue_for_verification = $_REQUEST['verification_issue'];
            $verification_id = $_REQUEST['id'];
            
            
            if($model->isTheUpdateOfTheVerificationIssueASuccess($verification_id,$issue_for_verification)){
                $msg ="You have successfully updated this domain verification request" ;
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    
                                    
                    
                            ));
            }else{
                 $msg ="The attempt to update this domain verification was not successful" ;
                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    
                                    
                    
                            ));
            }
        }
        
        
        /**
         * This is the function that replaces a domain primary file
         */
        public function actionreplaceverificationprimarysupportfile(){
            
            $id = $_REQUEST['id'];
            $model=  DomainVerification::model()->findByPk($id);
            $model->domain_id= $_REQUEST['domain_id'];
            $model->status = $_REQUEST['status'];
            $model->issue_of_verification = $_REQUEST['issue_for_verification'];
            $icon_error_counter = 0;
             if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "Verification primary support file replaced successfully";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to replace the domain verification primary support file was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while attempting to to replace the primary support file";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
        }
        
        
        /**
         * This is the function that list all verified domains for a requester
         */
        public function actionlistTheResultOfVerifiedDomainsForAMember(){
            
           $model = new DomainVerification;
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="(requestor_id=:requestorid and requestor_domain_id=:domainid) and status=:status";
            $criteria->params = array(':requestorid'=>$user_id, ':domainid'=>$domain_id,':status'=>"verified");
            $verify = DomainVerification::model()->findAll($criteria);
            
            if($verify===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verified" =>$verify,
                                    
                                    
                    
                            ));
                       
                         }
            
 
        }
        
        
        /**
         * This is the function that handles the request for reverification
         */
        public function actionreverifydomainverificationrequest(){
            
            $model = new DomainVerification;
            $user_id = Yii::app()->user->id;
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $model->domain_id = $_REQUEST['domain_id'];
            $model->issue_of_verification = $_REQUEST['verification_issue'];
            $model->status = strtolower('requested');
            $model->requestor_domain_id = $domain_id;
            $model->domain_type = $_REQUEST['domain_type'];
            $model->requestor_id = $user_id;
            $model->date_requested = new CDbExpression('NOW()');
            $model->filename = $_REQUEST['filename'];
            
             if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "A new re-verification request is successfully added";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'The attempt to reverify this subject was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
        }
        
        
        /**
         * This is the function that determines if a member has done verification on a subject domain
         */
        public function isThisDomainRequestedForVericationByThisUser($userid,$subject_domain_id){
            
            $model =new DomainVerification;
            return $model->isThisDomainRequestedForVericationByThisUser($userid,$subject_domain_id);
            
        }
        
        
        
        /**
         * This is the function that list all domains verified requests
         */
        public function actionlistdomainallverifiedrequests(){
            
            $model = new DomainVerification;
            
            $subject_domain_id = $_REQUEST['domain_id'];
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="domain_id=:domainid and status=:status";
            $criteria->params = array(':domainid'=>$subject_domain_id,':status'=>"verified");
            $verify = DomainVerification::model()->findAll($criteria);
            
            if($verify===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "verified" =>$verify,
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
         /**
         * This is the function that list all domains pending verification requests
         */
        public function actionListAllDomainsWithAwaitingVerificationRequests(){
            
            $model = new DomainVerification;
            
            $subject_domain_id = $_REQUEST['domain_id'];
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="domain_id=:domainid and (status=:status and is_paid_for=:paidfor)";
            $criteria->params = array(':domainid'=>$subject_domain_id,':status'=>"requested",':paidfor'=>1);
            $requests = DomainVerification::model()->findAll($criteria);
            
            if($requests===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "domain" =>$requests,
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        /**
         * This is the function that effects a domain verification request
         */
        public function actionverifyingASubjectDomainVerificationRequest(){
            
            $id = $_REQUEST['id'];
            $model=  DomainVerification::model()->findByPk($id);
            $model->domain_id =$_REQUEST['domain_id'];
            $model->issue_of_verification =$_REQUEST['issue_for_verification'];
            $model->requestor_id =$_REQUEST['requestor_id'];
            $model->requestor_domain_id =$_REQUEST['requestor_domain_id'];
            $model->domain_type =$_REQUEST['domain_type'];
            $model->status = strtolower('verified');
            $model->date_verified = new CDbExpression('NOW()');
           $icon_error_counter = 0;
             if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeLegal()){
                       
                       $filename = $_FILES['filename']['name'];
                      //$iconsize = $_FILES['filename']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }{
                   $filename=""; 
                }
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->verified_filename = $model->moveTheDocumentToItsPathAndReturnTheFilenameName($model,$filename);
                                                    
                if($model->save()) {
                        
                       // $result['success'] = 'true';
                                $msg = "Domain Subject verification was done successfully";
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg)
                                    );
                              
                      
                         
                     }else {
                         //$result['success'] = 'false'
                         $msg = 'The attempt to verify this domain subject was not succcessful. Please contact customer service';
                                     header('Content-Type: application/json');
                                     echo CJSON::encode(array(
                                            "success" => mysql_errno() != 0,
                                            "msg" => $msg)
                                        );
                         
                     }
                        
                   }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "A validation error was encountered while attempting to to verify this domain subject";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }else{
                            $msg = 'There is an error in the uploaded file. Please try again or contact customer service for assistance';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                     "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                    )); 
                            
                        }
            
        }
        
        
         /**
         * This is the function that list all consumable request for a domain
         */
        public function actionlistdomainallconsummablerequests(){
            
            $model = new DomainVerification;
            
            $subject_domain_id = $_REQUEST['domain_id'];
            
            $user_id = Yii::app()->user->id;
              //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $targets = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="domain_id=:domainid and is_consumption_paid_for=:paidfor";
            $criteria->params = array(':domainid'=>$domain_id,':paidfor'=>1);
            $verify = DomainVerificationConsumedByOtherDomain::model()->findAll($criteria);
            
            foreach($verify as $ver){
                if($model->getTheDomainForThisVerification($ver['verification_id']) ==$subject_domain_id ){
                    $targets[] = $ver;
                }
            }
               
            if($verify==null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "consumable" =>$targets,
                                   
                                    
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that retrieves conaumable verifications for a requestor domain
         */
        public function retrieveAllConsummableVerificationsBelongingToSubjectDomainDomainsForThisUserDomain($domain_id){
            $model = new DomainVerificationConsumedByOtherDomain;
            return $model->retrieveAllConsummableVerificationsBelongingToSubjectDomainDomainsForThisUserDomain($domain_id);
        }
        
        
        
        
         /**
         * This is the function that gets verification extra details
         */
        public function actiongetConsummableDomainVerificationExtraDetails(){
            
             $verification_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition="id=:id and status=:status";
            $criteria->params = array(':id'=>$verification_id,':status'=>"verified");
            $verify = DomainVerification::model()->find($criteria);
             
             
             
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$verify['domain_id']);
            $user = ResourceGroupCategory::model()->find($criteria);
            
            $name = $user['name'];
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>$verify['issue_of_verification']);
            $verification = VerificationCost::model()->find($criteria);
            
            if($verification['is_cost_quotable'] == 0){
                $cost =  $verification['cost'];
            }else{
                $cost = 0;
            }
            
            //get the consumption cost
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='verification_code=:code';
            $criteria->params = array(':code'=>$verify['issue_of_verification']);
            $consumption = ConsumptionCost::model()->find($criteria);
            
            if($consumption['is_cost_quotable'] == 0){
                $consumption_cost =  $consumption['cost'];
            }else{
                $consumption_cost = 0;
            }
            
            if($verify===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "name" => $name,
                                     "verification_cost" => $cost,
                                    "consumption_cost"=>$consumption_cost,
                                    "verification"=>$verify
                                    
                                    
                    
                            ));
                       
                         }
            
        }
}
