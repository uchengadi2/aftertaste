<?php

class SubGroupController extends Controller
{
	
        private $_id;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'. 'listallsubgroups','ListAllPlatformSubgroups'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListUserForSubgroupAssignmentUpdate', 'ListSubgroupForUserBulkScheduling',
                                    'AssignUserToSubgroup','ScheduleSingleUserToSubgroup','ScheduleBulkUserToSubgroup','ListAllSubgroupsInGroup',
                                    'listallusersinthissubgroup', 'ListUsersForSubgroupForSingleScheduling', 'ListSubgroupForUserForSingleAssignment',
                                    'AssignSingleUserToSubgroup', 'AssignNewSingleUserToSubgroup', 'deleteoneassignedusertosubgroup', 'ListAllUsersInUserTypeForSubgroupAssignment',
                                    'ListAllPlatformSubgroups','isTheIconTheDefault','listAllDomainSubgroups'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('ListAllSubgroups','deleteonesubgroup'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new SubGroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                $model->name = $_POST['name'];
                $model->group_id = $_POST['group_id'];
                $model->description = $_POST['description'];
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
               if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideSubgroupIconWhenUnavailable($model);      
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->icon_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' subgroup was created successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' subgroup  was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            // Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
               
                $subgroup = $_POST['group_id'];
                
                
				
				
		$_id = $_POST['id'];
		$model=SubGroup::model()->findByPk($_id);
		$model->name = $_POST['name'];
                if(is_numeric($subgroup)){
                   $model->group_id = $subgroup; 
                    
                }else{
                    $criteria = new CDbCriteria();
                    $criteria->select = 'id';
                    $criteria->condition='name=:id';
                    $criteria->params = array(':id'=>$subgroup);
                    $group_name = Group::model()->find($criteria); 
                    
                    $model->group_id = $group_name->id;
                    
                }
		
		$model->description = $_POST['description'];
		$model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
				
				
                 //get the domain name
                $group_name = $this->getTheSubgroupName($_id);
                
                $icon_error_counter  = 0;
                
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                       $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    //$model->icon = $this->retrieveThePreviousIconName($_id);
                    $icon_filename = $this->retrieveThePreviousIconName($_id);
                    $icon_size = $this->retrieveThePrreviousIconSize($_id);
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->icon_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$group_name' subgroup Information was successfully updated";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$group_name' subgroup information update was not successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneSubGroup()
	{
            $_id = $_POST['id'];
            $model=SubGroup::model()->findByPk($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = 'The data was successfully deleted';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('SubGroup');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListAllSubgroups_old()
	{
		
            //obtain the userid of the user that logged in
            $userid = Yii::app()->user->id;
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformUserAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformGroupAdmin")){
               $subgroup = SubGroup::model()->findAll();
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($subgroup);
                       
                }
            }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainUserAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainGroupAdmin")){
             
                //obtain the usertype_id of the user
                $criteria = new CDbCriteria();
                $criteria->select = 'id, usertype_id';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$userid);
                $usertypeid= User::model()->find($criteria);
                
               //obtain the name of the usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, name';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$usertypeid->usertype_id);
                $usertype= UserType::model()->find($criteria3);
                
                //obtain the grouptype/domain  that corresponds to the usertype
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, name';
                $criteria2->condition='name=:name';
                $criteria2->params = array(':name'=>$usertype->name);
                $type= GroupType::model()->find($criteria2);
                
                //determine all the groups in this grouptype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, name, grouptype_id';
                $criteria3->condition='grouptype_id=:id';
                $criteria3->params = array(':id'=>$type->id);
                $allgroup= Group::model()->findAll($criteria3);
                
                $subgroup = [];
                foreach($allgroup as $groupitem){
                    $criteria4 = new CDbCriteria();
                    $criteria4->select = '*';
                    $criteria4->condition='group_id=:id';
                    $criteria4->params = array(':id'=>$groupitem->id);
                    $allsubgroup= SubGroup::model()->findAll($criteria4);
                    $subgroup = array_merge($subgroup, $allsubgroup);
                    
                }
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($subgroup);
                       
                }
                
                
                
            }else{
                 //spool all the subgroup that was created or updated by the user
                $criteria2 = new CDbCriteria();
                $criteria2->select = '*';
                $criteria2->condition='create_user_id=:id OR update_user_id=:userid';
                $criteria2->params = array(':id'=>$userid, ':userid'=>$userid);
                $subgroup= SubGroup::model()->findAll($criteria2);
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($subgroup);
                       
                }
                
                
                
            }   
	}
        
        
        
        
        /**
	 * Manages all models.
	 */
	public function actionListAllSubgroups()
	{
		
            //obtain the userid of the user that logged in
            $userid = Yii::app()->user->id;
            
            //get the user domain
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformSubgroupSupport")){
                
                $subgroup = SubGroup::model()->findAll();
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($subgroup);
                       
                }
            }else{
               
                //spool all groups for this domain
            $domain_groups = [];
            $domain_groups = $this->retrieveAllDomainGroups($domain_id);
            
            $allsubgroups =[];
            foreach($domain_groups as $group){
               if($this->isAGroupWithASubgroup($group)){
               
                 //retrieve all the subgroup for this group
                 $thissubgroups = $this->getThisGroupSubgroups($group);
                 foreach($thissubgroups as $thissubgroup){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='id=:id';
                     $criteria->params = array(':id'=>$thissubgroup);
                     $subgroup= SubGroup::model()->find($criteria);
                     
                      $allsubgroups[] = $subgroup;
                 }
                
               
                } 
         
            }
           
                if($allsubgroups===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($allsubgroups);
                       
                       
                }
            }
            
             
	}
        
        
       /**
        * This is the function that gets all subgroup id for this group
        */ 
        public function getThisGroupSubgroups($group){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='group_id=:id';
                     $criteria->params = array(':id'=>$group);
                     $subgroups= SubGroup::model()->findAll($criteria);
                     
                     $allsubgroups = [];
                     foreach($subgroups as $subgroup){
                         $allsubgroups[] = $subgroup['id'];
                     }
                     return $allsubgroups;
                     
            
        }
        
        
        /**
	 * Manages all models.
	 */
	public function actionListAllPlatformSubgroups()
	{
		
            //obtain the userid of the user that logged in
            $userid = Yii::app()->user->id;
            
            //get the user domain
                      
            $domain_id = $this->determineAUserDomainIdGiven($userid);
                              
              $group = SubGroup::model()->findAll();
                if($group===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($group);
                       
                }
            
             
	}
        
        
        /**
         * This is the function that retrieves all groups belonging to a domain
         */
        public function retrieveAllDomainGroups($domain_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:id';
                $criteria->params = array(':id'=>$domain_id);
                $groups= Group::model()->findAll($criteria);
                
                $allgroups = [];
                foreach($groups as $group){
                    $allgroups[] = $group['id'];
                }
                return $allgroups;
            
        }
        
        /**
         * This is a function that verifies if a group has a subgroup
         */
        public function isAGroupWithASubgroup($group_id){
            
             $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('subgroup')
                    ->where("group_id = $group_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListUserForSubgroupAssignmentUpdate_old()
	{
		
           $_id = $_REQUEST['subgroup_id'];
            //$_id = 1;
                    
           
            $userid = Yii::app()->user->id;   
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformUserAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAssignmentAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, firstname,lastname,middlename, select_value, usertype_id';
             $result = User::model()->findAll($criteria);     
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, subgroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "subgroup" => $subgroup 
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") ||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainUserAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAssignmentAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") ){ 
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, subgroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='subgroup_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria4);
            
                        
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria5);   
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated the usertable
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, firstname, middlename, lastname, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $allusers= User::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($allusers as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= User::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $usergroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($usergroupid as $userid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$userid);
                    $result2= User::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $domain_result,
                            "subgroup" => $subgroup 
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'user_id, subgroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='subgroup_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria12);
            
                        
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria13);   
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= User::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "subgroup" => $subgroup 
                           
                       ));
                       
                } 
               
               
           }  
	}
        
        
        
         /**
          * listing all the resourcegroup items needed for the resourcegroup to 
          * subgroup assignment 
          */
         public function actionListUserForSubgroupAssignmentUpdate()
	{
		
           $_id = $_REQUEST['subgroup_id'];
            //$_id = 1;
                    
           
            $userid = Yii::app()->user->id;   
            
            //get the group of this subgroup
            $group_id = $this->getTheGroupOfThisSubgroup($_id);
            
            //get the domain of this group
            $domain_id = $this->getTheDomainOfThisGroup($group_id);
            
            //get the logged in user domain
            //$domain_id = $this->determineAUserDomainIdGiven($userid);
            
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, firstname,lastname,middlename, select_value, usertype_id';
             $criteria->condition='domain_id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $result = User::model()->findAll($criteria);     
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria2);
            
                        
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3);   
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "selected" => $selected,
                            "data" => $result,
                            "subgroup" => $subgroup 
                       ));
                       
                }
                
           
	}
        
        
        /**
         * This is the function that gets the group of a subgroup
         */
        public function getTheGroupOfThisSubgroup($subgroup_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$subgroup_id);
            $group = SubGroup::model()->find($criteria); 
            
            return $group['group_id'];
        }
        
        
        /**
         * This is the function that gets the domain id of a group
         */
          public function getTheDomainOfThisGroup($group_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$group_id);
            $group = Group::model()->find($criteria); 
            
            return $group['domain_id'];
              
          }
        
        /**
	 * List all the users in this subgroup belonging to a particular domain
	 */
	public function actionListAllUsersInUserTypeForSubgroupAssignment()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 2;
                
                //determine the group id of this subgroup
                $criteria2 = new CDbCriteria();
                $criteria2->select = 'id, group_id';
                $criteria2->condition='id=:id';
                $criteria2->params = array(':id'=>$_id);
                $groupid= SubGroup::model()->find($criteria2);
                
               
                //determine the domain id of this group
                $criteria3 = new CDbCriteria();
                $criteria3->select = '*';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$groupid['group_id']);
                $group= Group::model()->find($criteria3);
                
                // $users = [];
                $criteria1 = new CDbCriteria();
                $criteria1->select = 'id, firstname, middlename, lastname, username, usertype_id';
                $criteria1->condition='domain_id=:id';
                $criteria1->params = array(':id'=>$group['domain_id']);
                $users= User::model()->findAll($criteria1); 
                
                
               if($users===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($users);
                       
                }
               
               
	}
        
              /**
	 * Assign Users To Subgroup.
	 * If assignment is successful, close the window else insist for an assignment to be done.
	 */
	public function actionAssignUserToSubgroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                
                $cmd =Yii::app()->db->createCommand();
                                             
             
                  //get the subgroup name
                
                $subgroup_name = $this->getThisSubgroupName($_id);
                
                if(isset($_POST['user'])){
                     $existing_users = $this->alreadyAssignedUsersToThisSubgroup($_id);
                    $selected_users = [];
                    foreach($_POST['user'] as $user_id){
                        
                        $selected_users[] = $user_id;
                        
                    }   
                    //get the array difference
                    $discarded_users = array_diff($existing_users,$selected_users);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_users as $discarded){
                        
                        $this->removeThisUserFromThisSubgroup($discarded, $_id);
                    }
                
                    if (is_array($_POST['user'])) {
                            foreach($_POST['user'] as $value){    
                                if($this->isUserNotAlreadyAssignedToThisSubgroup($_id,$value)){
                                     $cmd->insert('user_has_subgroups',
                                        array(
                                           'subgroup_id'=>$_POST['id'],
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                           'user_id'=>$value,
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id
                                              
                                        ));
                                }else{
                                  $subgroup_id = $_POST['id'];
                                    $cmd->update('user_has_subgroups',
                                        array(
                                           'assign_name'=>$_POST['assign_name'],
                                           'assign_description'=>$_POST['assign_description'],
                                          
                                            'date_assigned'=>new CDbExpression('NOW()'),
                                            'assigned_by'=>Yii::app()->user->id
                                              
                                        ),
                                       ("subgroup_id=$subgroup_id and user_id=$value"));
                                    
                                   
                                }
                                   
                                   
                                  
                                      
                               
                             }
                             
                       }else {
                           $value = $_POST['user'];
                           $cmd->insert('user_has_subgroups',
                                   array(
                                        'subgroup_id'=>$_POST['id'],
                                        'assign_name'=>$_POST['assign_name'],
                                        'assign_description'=>$_POST['assign_description'],
                                        'user_id'=>$value,
                                        'date_assigned'=>new CDbExpression('NOW()'),
                                         'assigned_by'=>Yii::app()->user->id
                                              
                                    ));
                           
                       }
                      
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>"User(s) successfully assigned to the '$subgroup_name' subgroup"
                       ));
                        
                    } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Using this bulk module, you cannot effect or add zero number of user to a subgroup. PLEASE USE THE SINGLE USER TO SUBGROUP ASSIGNMENT MODULE INTSTEAD'
                          )); 
                        
                    }
                  
                          
                               
           
                    
            }
         
            
            /**
             * this is the function that gets the subgroup name
             */
            public function getThisSubgroupName($subgroup_id){
               
                $criteria6 = new CDbCriteria();
                $criteria6->select = '*';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$subgroup_id);
                $subgroup= SubGroup::model()->find($criteria6);
                
                return $subgroup['name'];
            }
        
        
        /**
         * listing all the usergroup items needed for the subgroup to 
         * user scheduling
         */
        public function actionListSubgroupForUserBulkScheduling_old()
	{
		
            $_id = $_REQUEST['subgroup_id'];
            //$_id = 1;
                    
           
            $userid = Yii::app()->user->id;   
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformScheduleAdmin")){   
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, firstname,lastname,middlename, select_value, usertype_id';
             $result = User::model()->findAll($criteria);     
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'user_id, subgroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria2);
            
             /**           
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3);   
              * 
              */
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result,
                           // "subgroup" => $subgroup 
                       ));
                       
                }
                
           }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainScheduleAdmin") ){ 
                         
             $criteria4 = new CDbCriteria();
             $criteria4->select = 'user_id, subgroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria4->condition='subgroup_id=:id';
             $criteria4->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria4);
            
            /**            
             $criteria5 = new CDbCriteria();
             $criteria5->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria5);
             * 
             */   
                


                //determine the logged-in user usertype
                $criteria6 = new CDbCriteria();
                $criteria6->select = 'id, usertype_id';
                $criteria6->condition='id=:id';
                $criteria6->params = array(':id'=>$userid);
                $user= User::model()->find($criteria6);
                
                //determine the id and name  of the usertype/user domain
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'id, name';
                $criteria7->condition='id=:id';
                $criteria7->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria7);
              
                //obtain all the users that created or updated the usertable
                $criteria8 = new CDbCriteria();
                $criteria8->select = 'id, firstname, middlename, lastname, create_user_id, update_user_id';
                //$criteria5->condition='id=:id';
                //$criteria5->params = array(':id'=>$user->usertype_id);
                $allusers= User::model()->findAll($criteria8);
                
                //create array to hold the users that created or updated  resourcegroup
                
                $group_users = [];
                $result = [];
                
                foreach($allusers as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria9 = new CDbCriteria();
                    $criteria9->select = 'id, usertype_id';
                    $criteria9->condition='id=:id OR id=:userid';
                    $criteria9->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria9);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria10 = new CDbCriteria();
                                        $criteria10->select = '*';
                                        $criteria10->condition='create_user_id=:id OR update_user_id=:userid';
                                        $criteria10->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                                        $allgroups= User::model()->findAll($criteria10);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resourcegroup table
                 $usergroupid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($usergroupid as $userid){
                    $criteria11 = new CDbCriteria();
                    $criteria11->select = '*';
                    $criteria11->condition='id=:id';
                    $criteria11->params = array(':id'=>$userid);
                    $result2= User::model()->findAll($criteria11);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $domain_result
                           // "subgroup" => $subgroup 
                           
                           
                          
                       ));
                       
                } 
               
           }else{
              
             $criteria12 = new CDbCriteria();
             $criteria12->select = 'user_id, subgroup_id,assign_name, assign_description, isfirst_assignment, date_last_assigned, date_first_assigned';
             $criteria12->condition='subgroup_id=:id';
             $criteria12->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria12);
            
            /**            
             $criteria13 = new CDbCriteria();
             $criteria13->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria13);  
             * 
             */ 
               
               
               $criteria14 = new CDbCriteria();
               $criteria14->select = '*';
               $criteria14->condition='create_user_id=:id OR update_user_id=:userid';
               $criteria14->params = array(':id'=>$userid, ':userid'=>$userid);
               $result= User::model()->findAll($criteria14);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result
                           // "subgroup" => $subgroup 
                           
                       ));
                       
                } 
               
               
           }  
	}
         
        
        /**
         * This is the function that list all subgroups that could be assigned to a user in a domain
         */
        public function actionListSubgroupForUserBulkScheduling(){
            
            $_id = $_REQUEST['subgroup_id'];
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $result = User::model()->findAll($criteria);     
           
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='subgroup_id=:id';
             $criteria2->params = array(':id'=>$_id);
             $selected = UserHasSubgroups::model()->findAll($criteria2);
            
             /**           
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'id, name';
             $subgroup = SubGroup::model()->findAll($criteria3);   
              * 
              */
            
            
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() == 0,
                            "assigned" => $selected,
                            "data" => $result,
                           // "subgroup" => $subgroup 
                       ));
                       
                }
            
            
        }
        
        
        
         /**
	 * Schedule User To Subgroup.
	 * If schedule is successful, close the window else insist on doing the single item 
           * scheduling.
	 */
	public function actionScheduleSingleUserToSubgroup()
	{
		//$model=new UserHasSubgroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $excluded_days = [];
                $_id = $_POST['subgroup_id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                $user_id = $_POST['user_id'];
               
                
                if(isset($_POST['sunday'])){
                    $excluded_days[] = $_POST['sunday'];
                }
                if(isset($_POST['monday'])){
                    $excluded_days[] = $_POST['monday'];
                }
                if(isset($_POST['tuesday'])){
                    $excluded_days[] = $_POST['tuesday'];
                }
                if(isset($_POST['wednesday'])){
                    $excluded_days[] = $_POST['wednesday'];
                }
                if(isset($_POST['thursday'])){
                    $excluded_days[] = $_POST['thursday'];
                }
                if(isset($_POST['friday'])){
                    $excluded_days[] = $_POST['friday'];
                }
                if(isset($_POST['saturday'])){
                    $excluded_days[] = $_POST['saturday'];
                }
                 
                 //get the toolbox name
                 $username = $this->getTheUsername($user_id);
                 
                 //get the domain name
                 $subgroupname = $this->getTheSubgroupName($_id); 
             
                //check if the start_date is less than the min_date
                $cmd =Yii::app()->db->createCommand();           
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                   if(($end_date <= $max_date) AND ($end_date >= $start_date)){                
                       //perform the assignment table update here
                       $cmd->update('user_has_subgroups',
                                    array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                    'end_date'=>$end_date),
					 "subgroup_id = $_id and user_id = $user_id"
                                     );
                      // if(isset($excluded_days)){
                         if(is_array($excluded_days) AND $excluded_days != NULL) {
                               $num = 0;
                               foreach($excluded_days as $value){
                                   if($value == 'Sunday' ) {
                                       $num = $num + 1;
                                        $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                     );
                                   }elseif($value == 'Monday'){
                                       $num = $num + 2;
                                       $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        );       
                                       
                                   }elseif($value == 'Tuesday'){
                                       $num = $num + 4;
                                       $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        ); 
                                       
                                   } elseif($value == 'Wednesday'){
                                       $num = $num + 8;
                                       $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        ); 
                                       
                                   }elseif($value == 'Thursday'){
                                       $num = $num + 16;
                                       $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        ); 
                                       
                                   } elseif($value == 'Friday'){
                                       $num = $num + 32;
                                       $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        ); 
                                                                              
                                   }elseif($value == 'Saturday'){
                                       $num = $num + 64;
                                       $cmd->update('user_has_subgroups',
                                            array('excluded_days'=>'excluded_days'|$num),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        ); 
                                   
                                       
                                   }
                                       
                                       
                                                
                                  
                                   
                               }
                                                                                          
                           }elseif($excluded_days == NULL){
                                      // $num = $num + 64;
                                       $cmd->update('user_has_subgroups',
                                             array('excluded_days'=>NULL),
                                             "subgroup_id = $_id and  user_id = $user_id"
                                        ); 
                                   
                                       
                       }
                     $msg = "'$username' is successfully scheduled on the '$subgroupname' subgroup ";      
                     header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
                       
                   }else {
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'End Date is out of range with the Time to Live period or it is less than the Start Date'
                          )); 
                       
                   }             
                    
                }else {
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" => 'Start Date is out of range with the Time To Live period or it is greater than the End Date'
                          )); 
                    
                    
                }
                
  
                
        }//end of single user to subgroup scheduling function 
         
         
        
       /**
	 * Schedule User To Subgroup in bulk.
	 * If schedule is successful, close the window else insist on doing the a single item 
           * scheduling.
	 */
	public function actionScheduleBulkUserToSubgroup()
	{
		//$model=new GroupHasResourcegroup;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                $_id = $_POST['id'];
                $min_date = date("Y-m-d H:i:s", strtotime($_POST['min_date'])); 
                $max_date = date("Y-m-d H:i:s", strtotime($_POST['max_date']));
                $start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
                $end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
                //$resourcegroup_id = $_POST['resourcegroup_id'];
                //check if the start_date is less than the min_date
                $counter = 0;
                
                //get the subgroup name
                $subgroupname = $this->getTheSubgroupName($_id);
                $cmd =Yii::app()->db->createCommand();   
                if(($start_date >= $min_date) AND ($start_date <= $end_date)){
                    if(($end_date <= $max_date) AND ($end_date >= $start_date)){  
                        if(isset($_POST['user'])){
                            if(is_array($_POST['user'])) {
                                 foreach($_POST['user'] as $user){
                                     //save all the data into the database except the set the data type 
                                     $cmd->update('user_has_subgroups',
                                             array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "subgroup_id = $_id and user_id = $user"
                                     );
                                     $counter = $counter + 1;
                                     //update table to save the excluded_days data into the database
                                     if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  user_id = $user"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('user_has_subgroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "subgroup_id = $_id and  user_id = $user"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('user_has_subgroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('user_has_subgroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('user_has_subgroups',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  user_id = $user"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('user_has_subgroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('user_has_subgroups',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('user_has_subgroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('user_has_subgroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  user_id = $user"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }//end of the excluded_days isset if statement
                             
                                }//end of the resourcegroup array  foreach statement
                                
                         
                            } else { //end of resourcegroup is_array if  statement
                                $user = $_POST['user'];
                                $cmd->update('user_has_subgroups',
                                             array('min_date'=>$min_date, 'max_date' =>$max_date, 'start_date'=>$start_date,
                                             'end_date'=>$end_date),
                                             "subgroup_id = $_id and user_id = $user"
                                  );
                                $counter = $counter + 1;
                                  if(isset($_POST['excluded_days'])){
                                         if(is_array($_POST['excluded_days'])) {
                                              $num = 0;
                                              foreach($_POST['excluded_days'] as $value){ 
                                                   if($value == 'sunday' ) {
                                                       $num = $num + 1;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  user_id = $user"
                                                        );
                                                       
                                                       
                                                   }elseif ($value == 'monday') {
                                                       $num = $num + 2;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        );  
                                                       
                                                       
                                                   }elseif ($value == 'tuesday'){
                                                        $num = $num + 4;
                                                        $cmd->update('user_has_subgroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                                       
                                                       
                                                   }elseif($value == 'wednesday'){
                                                       $num = $num + 8;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                         "subgroup_id = $_id and  user_id = $user"
                                                       ); 
                                                       
                                                       
                                                   }elseif($value == 'thursday'){
                                                       $num = $num + 16;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                                       
                                                   }elseif($value == 'friday'){
                                                       $num = $num + 32;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                         ); 
                                                       
                                                       
                                                   }elseif($value == 'saturday'){
                                                       $num = $num + 64;
                                                       $cmd->update('user_has_subgroups',
                                                       array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                                       
                                                       
                                                   }//end of the $value = saturday else if statement
                                                  
                                                  
                                              }//end of the foreach excluded_days statement
                                             
                                             
                                         }else {
                                             
                                             //update the bridge/assignment table when checkbox is not an array
                                             $value = $_POST['excluded_days'];
                                             $num = 0;
                                             if($value == 'sunday'){
                                                $num = $num + 1;
                                                update('user_has_subgroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                );  
                                   
                                                }elseif($value == 'monday'){
                                                    $num = $num + 2;
                                                    update('user_has_subgroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                            "subgroup_id = $_id and  user_id = $user"
                                                        ); 
                                   
                                                }elseif($value == 'tuesday'){
                                                    $num = $num + 4;
                                                    update('user_has_subgroups',
                                                         array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  user_id = $user"
                                                    ); 
                                   
                                                }elseif($value == 'wednesday'){
                                                    $num = $num + 8;
                                                    update('user_has_subgroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                    ); 
                                   
                                                }elseif($value == 'thursday'){
                                                     $num = $num + 16;
                                                     update('user_has_subgroups',
                                                     array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                    ); 
                                   
                                                }elseif($value == 'friday'){
                                                    $num = $num + 32;
                                                    update('user_has_subgroups',
                                                    array('excluded_days'=>'excluded_days'|$num),
                                                        "subgroup_id = $_id and  user_id = $user"
                                                ); 
                                   
                                                }elseif($value == 'saturday'){
                                                    $num = $num + 64;
                                                    update('user_has_subgroups',
                                                        array('excluded_days'=>'excluded_days'|$num),
                                                             "subgroup_id = $_id and  user_id = $user"
                                                ); 
                                   
                                                }
                                             
                                             
                                         }//end of the excluded_days is_assay if-else statement
                                         
                                         
                                     }// end of the excluded_day isset statement for non-array resourcegroup
                                
                                
                            }//end of resourcegroup is_array if else  statement
                            $msg= "$counter user(s) successfully scheduled in the '$subgroupname' subgroup"; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                     "success" => mysqli_connect_errno() == 0,
                                     "msg"=>$msg
                             ));
                            
                    
                }else{
                    header('Content-Type: application/json');
                          echo CJSON::encode(array(
                          "success" => mysqli_connect_errno() != 0,
                           "msg" => "Select at least one item in the folder to schedule"   
                      ));
                    
                    
                }//end of resourcegroup isset if-else statement 
                        
                        
                        
         }else {
               header('Content-Type: application/json');
                     echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() != 0,
                         "msg" => 'End Date is out of range with the time to Live period or it is less than the Start Date'
                      )); 
                        
                        
          }//end of end_date check if-else statement
                    
                    
          }else{
              header('Content-Type: application/json');
                  echo CJSON::encode(array(
                     "success" => mysqli_connect_errno() != 0,
                     "msg" => 'Start Date is out of range with the Time To Live period or it is greater than the End Date'
               ));  
                    
                    
                    
          }//end of start_date check if-else  statement
          
        }//end of bulk user to Subgroup scheduling function  
        
         /**
	 * List all the subgroups that belong to a particular group
	 */
	public function actionListAllSubgroupsInGroup()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 3;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='group_id=:id';
                $criteria->params = array(':id'=>$_id);
                $subgroup= SubGroup::model()->findAll($criteria);
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($subgroup);
                       
                }
	}
        
           /**
	 * List all the users in the subgroup
	 */
	public function actionListAllUsersInThisSubgroup()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                   
		$userid = Yii::app()->user->id;   
		
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='subgroup_id=:id';
                    $criteria->params = array(':id'=>$_id);
                    $users= UserHasSubgroups::model()->findAll($criteria);
                
               if($users===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode($users);
                       
                }
            
               
               
	}
        
        
         /**
	 * List all the Devices for a User for single scheduling
	 */
	public function actionListUsersForSubgroupForSingleScheduling()
	{
		
             $user_id = $_REQUEST['user_id'];
             $subgroup_id = $_REQUEST['subgroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, firstname, middlename, lastname';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$user_id);
             $user = User::model()->findAll($criteria2);
               
                if($subgroup===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "user" => $user,
                            "subgroup" => $subgroup)
                       );
                       
                } 
               
               
	}
        
        
         /**
	 * List  the subgroup for this user for single assignment
	 */
	public function actionListSubgroupForUserForSingleAssignment()
	{
		
             $user_id = $_REQUEST['user_id'];
             $subgroup_id = $_REQUEST['subgroup_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, firstname, middlename, lastname, username';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $user = User::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$subgroup_id);
             $subgroup = SubGroup::model()->findAll($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'assign_name, assign_description';
             $criteria3->condition='subgroup_id=:id AND user_id=:user';
             $criteria3->params = array(':id'=>$subgroup_id, ':user'=>$user_id);
             $assignment = UserHasSubgroups::model()->findAll($criteria3);
               
                if($user===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "subgroup" => $subgroup,
                            "user" => $user,
                           "assignment"=> $assignment)
                       );
                       
                } 
               
               
	}
        
        
         /**
	 * Deletes a particular assigned user in a subgroup.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneAssignedUserToSubgroup()
	{
            //delete a resourcegroup from subgroup
            $user_id = $_POST['user_id'];
            $subgroup_id = $_POST['subgroup_id'];
           
            //$model=GroupHasResourcegroup::model()->findByPk($_id);
           $cmd =Yii::app()->db->createCommand();  
           $cmd->delete('user_has_subgroups', 'user_id=:id and subgroup_id=:groupid', array(':id'=>$user_id, ':groupid'=>$subgroup_id ));
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>'The User had successfully been removed from the Subgroup',
                       ));
	}
        
        
         /**
	 * assign a a single new user to a subgroup for single assignment process
	 */
	public function actionAssignNewSingleUserToSubgroup()
	{
		
             $user_id = $_REQUEST['user'];
             $subgroup_id = $_REQUEST['id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
	
             //get the subgroup name
           
           $subgroupname = $this->getTheSubgroupName($subgroup_id);
           
           //get the user  name
           
           $username = $this->getTheUsername($user_id);
           if($this->isUserNotAlreadyAssignedToThisSubgroup($subgroup_id,$user_id)){
               $cmd =Yii::app()->db->createCommand();  
             $cmd->insert('user_has_subgroups',
                	array('subgroup_id'=>$subgroup_id,
				'user_id'=>$user_id,
				'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'date_assigned'=>new CDbExpression('NOW()'),
                                'assigned_by'=>Yii::app()->user->id,
					
					
			)
			
		);
             $msg = "'$username'  is successfully added to '$subgroupname' subgroup  ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
               
               
           }else{
               $msg = "'$username'  is already available in '$subgroupname' subgroup ";
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
           } 
             
               
	}
        
        
        /**
	 * assign a user to a subgroup for single assignment process
	 */
	public function actionAssignSingleUserToSubgroup()
	{
		
             $subgroup_id = $_REQUEST['subgroup_id'];
             $user_id = $_REQUEST['user_id'];
             $assign_name = $_REQUEST['assign_name'];
             $assign_description = $_REQUEST['assign_description'];
             //$_id = 1;
		
             //get the subgroup name
           
           $subgroupname = $this->getTheSubgroupName($subgroup_id);
           
           //get the user  name
           
           $username = $this->getTheUsername($user_id);
			 
            
             $cmd =Yii::app()->db->createCommand();  
             $result = $cmd->update('user_has_subgroups',
                	array(
                                'assign_name'=> $assign_name,
				'assign_description' => $assign_description,
                                'update_time'=>new CDbExpression('NOW()')
                               
					
					
			),
			"user_id = $user_id and  subgroup_id = $subgroup_id"
		);
             if($result > 0){
                 $msg = "'$username' information in '$subgroupname' subgroup is successfully updated"; 
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg"=>$msg
                       ));
             }else{
                 $msg = "'$username' information in '$subgroupname' subgroup could not be updated "; 
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg"=>$msg
                       ));
             }
             
               
               
	}
        
        
        /**
        * Provide icon when unavailable
	 */
	public function provideSubgroupIconWhenUnavailable($model)
	{
		return 'subgroup_unavailable.png';
	}
        
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        
        /**
             * This is the function that test if a tool is already assigned to a toolbox
             */
            public function isUserNotAlreadyAssignedToThisSubgroup($subgroup_id,$user_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('user_has_subgroups')
                    ->where("user_id = $user_id and subgroup_id = $subgroup_id");
                $result = $cmd->queryScalar();
                
                if($result <= 0){
                    return true;
                }else{
                    return false;
                }
            }
        
            
            /**
             * This is the function that extracts all users already assigned to this subgroup
             */
            public function alreadyAssignedUsersToThisSubgroup($subgroup_id){
                
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='subgroup_id=:id';
               $criteria->params = array(':id'=>$subgroup_id);
               $users= UserHasSubgroups::model()->findAll($criteria); 
               
               $allusers = [];
               foreach($users as $user){
                   $allusers[] = $user['user_id'];
               }
               
               return $allusers; 
            }
        
            
            /**
             * This is the function that removes a user from a subgroup
             */
            public function removeThisUserFromThisSubgroup($user_id, $subgroup_id){
                
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('user_has_subgroups', 'subgroup_id=:subgroupid and user_id=:userid', array(':subgroupid'=>$subgroup_id, ':userid'=>$user_id ));
            
                return $result;
                
                
            }
         
             /**
             * This is the function that gets the name of a subgroup
             */
            public function getTheSubgroupName($subgroup_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$subgroup_id);
                $group= SubGroup::model()->find($criteria);
                
                return $group['name'];
            }
            
            
            /**
             * This is the function that gea user name
             */
            public  function getTheUsername($user_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$user_id);
                $user= User::model()->find($criteria);
                
                $name = $user['firstname']." ".$user['middlename']. " ". $user['lastname'];
                
                return $name;
                
            }
            
            
             /**
         * This is the function that determines the type and size of icon file
         */
        public function isIconTypeAndSizeLegal(){
            
           $size = []; 
            if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['icon']['tmp_name'];
                $iconFileName = $_FILES['icon']['name'];    
                $iconFileType = $_FILES['icon']['type'];
                $iconFileSize = $_FILES['icon']['size'];
            } 
           if (isset($_FILES['icon'])) {
             $filename = $_FILES['icon']['tmp_name'];
             list($width, $height) = getimagesize($filename);
           }
      

           
            $platform_width = $this->getThePlatformSetIconWidth();
            $platform_height = $this->getThePlatformSeticonHeight();
            
            $width = $width;
            $height = $height;
           
            //$size = $width * $height;
           
            $icontypes = $this->retrieveAllTheIconMimeTypes();
            
          
           
            //if(($iconFileType === 'image/png'|| $iconFileType === 'image/jpg' || $iconFileType === 'image/jpeg') && ($iconFileSize = 256 * 256)){
            if((in_array($iconFileType,$icontypes)) && ($platform_width == $width && $platform_height = $height)){
                return true;
               
            }else{
                return false;
            }
            
        }



/**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousIconName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = SubGroup::model()->find($criteria);
            
            
            return $icon['icon'];
            
            
        }
        
        /**
         * This is the function that retrieves the previous icon size
         */
        public function retrieveThePrreviousIconSize($id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = SubGroup::model()->find($criteria);
            
            
            return $icon['icon_size'];
        }
		
		
		
		 /**
         * This is the function that gets the platform height setting
         */
        public function getThePlatformSeticonHeight(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_height'];
        }
		
		
		
		 /**
         * This is the function that gets the platform icon set width
         */
        public function getThePlatformSetIconWidth(){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_width'];
        }
		
		
		
		/**
         * This is the function that retrieves all icon mime types in the platform
         */
        public function retrieveAllTheIconMimeTypes(){
            
            $icon_mimetype = [];
            $icon_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon_mime = PlatformSettings::model()->find($criteria); 
            
            $icon_mimetype = explode(',',$icon_mime['icon_mime_type']);
            foreach($icon_mimetype as $icon){
                $icon_types[] =$icon; 
                
            }
            
            return $icon_types;
            
        }
		
		
		
		/**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                   }
                    
                    if($iconName !== null) {
                                                  
                       if($model->id === null){
                          //$iconFileName = time().'_'.$icon_filename; 
                           //$iconFileName = $icon_filename;
                           if($icon_filename != 'subgroup_unavailable.png'){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            } 
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['icons'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                           if($icon_filename != 'subgroup_unavailable.png'){
                               
                               if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['icons'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                           }
                            
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                            
                      
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
		
		
		 /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            //retreve the existing zip file from the database
            
            if($this->isTheIconTheDefault($id) === false){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= SubGroup::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\icons\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['icon'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
            
            
        }
        
	
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= SubGroup::model()->find($criteria);
                
               if($icon['icon'] == 'subgroup_unavailable.png' || $icon['icon'] ===NULL){
                 return true;
                   
                }else{
                    return false;
                   
                }
        }
		
		
		
		/**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, icon';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= SubGroup::model()->find($criteria);
                
                if($icon['icon']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
            
            
            
	/**
         * This is the function that list all domain groups
         */
        public function actionlistAllDomainSubgroups(){
            
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainIdGiven($user_id);
           
           //get all the groups for this domain
           
           $groups = $this->retrieveAllDomainGroups($domain_id);
           
           $all_subgroup = [];
           $serial_subgroup = [];
           
           foreach($groups as $group){
               
               $criteria1 = new CDbCriteria();
               $criteria1->select = '*';
               $criteria1->condition='group_id=:id';
               $criteria1->params = array(':id'=>$group);
               $subgroups = SubGroup::model()->findAll($criteria1);
              
               foreach($subgroups as $sub){
                   $serial_subgroup[] = $sub['id'];
               }
               
               
           }
           $domain_subgroups = [];
           foreach($serial_subgroup as $subgroup){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$subgroup);
               $group = SubGroup::model()->find($criteria);
               $domain_subgroups[] = $group;
           }
           
                 
           if($domain_subgroups===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "subgroup" => $domain_subgroups,
                          
                       ));
                       
                }
           
           
            
        }
}
