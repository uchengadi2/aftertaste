<?php

class DomainHasLicensesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listalldomainlicenses','assigninglicensestothisdomain','toppingupthisdomainlicenses','changethisdomainlicenses'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that list all domain licenses in the database
         */
        public function actionlistalldomainlicenses(){
            
            $licenses = DomainHasLicenses::model()->findAll();
                if($licenses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "license" => $licenses,
                                   
                    
                            ));
                       
                }
        }
        
        /**
         * This is the function that adds licenses to a domain
         */
        public function actionassigninglicensestothisdomain(){
            $model=new DomainHasLicenses;

            if($model->isThisDomainWithoutLicense($_POST['domain_id'])){
                if($_REQUEST['license_option'] =="both"){
                    $model->feedback_license_id = $_POST['feedback_license_id'];
                    $model->reviews_license_id = $_POST['reviews_license_id'];
                    $model->total_acquired_views = $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);
                    $model->total_remaining_views = $model->total_acquired_views;
                    $model->reviews_license_status = $_REQUEST['reviews_license_status'];
                    $model->reviews_license_end_date =$model->getTheReviewsEndDate($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);
                    $model->maximum_reviews_users_number = $model->getTheMaximumUsersRequired($_POST['reviews_license_id']);
                    $model->feedback_license_status = $_REQUEST['feedback_license_status'];
                    $model->feedback_license_end_date = $model->getTheFeedbackLIcenseEndDate($_POST['feedback_license_id'],$_REQUEST['number_of_months']);
                    $model->total_remaining_monthly_feedback_response = $model->getTheTotalRemainingFeedbackResponse($_POST['feedback_license_id'],$_REQUEST['number_of_months']);
                    
                }else if($_REQUEST['license_option'] =="reviews"){
                    $model->reviews_license_id = $_POST['reviews_license_id'];
                    $model->total_acquired_views = $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);
                    $model->total_remaining_views = $model->total_acquired_views;
                    $model->reviews_license_status = $_REQUEST['reviews_license_status'];
                    $model->reviews_license_end_date =$model->getTheReviewsEndDate($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);
                    $model->maximum_reviews_users_number = $model->getTheMaximumUsersRequired($_POST['reviews_license_id']);
                    
                    $model->feedback_license_id = null;
                    $model->feedback_license_status = "inactive";
                    $model->feedback_license_end_date=null;
                    $model->total_remaining_monthly_feedback_response=0;
               
                }else if($_REQUEST['license_option'] =="feedback"){
                    $model->feedback_license_id = $_POST['feedback_license_id'];
                    $model->feedback_license_status = $_REQUEST['feedback_license_status'];
                    $model->feedback_license_end_date = $model->getTheFeedbackLIcenseEndDate($_POST['feedback_license_id'],$_REQUEST['number_of_months']);
                    $model->total_remaining_monthly_feedback_response = $model->getTheTotalRemainingFeedbackResponse($_POST['feedback_license_id'],$_REQUEST['number_of_months']);
                    
                    $model->reviews_license_id=null;
                    $model->total_acquired_views=0;
                    $model->total_remaining_views=0;
                    $model->reviews_license_status="inactive";
                    $model->reviews_license_end_date=null;
                    $model->maximum_reviews_users_number=0;
                }
                $model->domain_id = $_POST['domain_id'];
                 $model->license_option = $_POST['license_option'];
                 $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Assignment of licenses to this domain was successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Assignment of licenses to this domain was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
                
                
            }else{
                 $msg = 'This domain already has an assigned license(s). To modify the current license, please use the top-up facility';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                
                
            }
            
               
            
            
        }
        
        
        /**
         * This is the function that tops up domain licenses
         */
        public function actiontoppingupthisdomainlicenses(){
          
          $_id = $_REQUEST['id'];
           $model= DomainHasLicenses::model()->findByPk($_id); 
           
           if($model->reviews_license_id != $_POST['reviews_license_id'] and $model->reviews_license_id !=NULL){
               $msg = 'Ilegal Operation: You cannot change the reviews plan with this operation';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
           }else if($model->feedback_license_id != $_POST['feedback_license_id'] and  $model->feedback_license_id !=NULL){
               $msg = 'Ilegal Operation: You cannot change the feedback plan with this operation';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
               
           }else{
                if($_REQUEST['license_option'] =="both"){
                 
                 $model->reviews_license_id = $_POST['reviews_license_id'];
                 $model->reviews_license_status = $_REQUEST['reviews_license_status'];
                 
                 if($model->isLicenseViewUnlimited($_POST['reviews_license_id'])){
                         $model->total_acquired_views =  -1;
                     }else{
                         if($model->total_acquired_views == -1){
                             $model->total_acquired_views = 0;
                             $model->total_acquired_views =$model->total_acquired_views +  $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);   
                         }else{
                             $model->total_acquired_views =$model->total_acquired_views +  $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);   
                         }
                       
                     }
                     
                 if($model->isLicenseViewUnlimited($_POST['reviews_license_id'])){
                         $model->total_remaining_views = -1;
                     }else{
                         if($model->total_remaining_views == -1){
                             $model->total_remaining_views = 0;
                             $model->total_remaining_views = $model->total_remaining_views + $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }else{
                             $model->total_remaining_views = $model->total_remaining_views + $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }
                         
                     }
                     
                 if($model->isUserLimitless($_POST['reviews_license_id'])){
                         $model->maximum_reviews_users_number = -1;
                     }else{
                         if($model->maximum_reviews_users_number == -1){
                             $model->maximum_reviews_users_number = 0;
                             $model->maximum_reviews_users_number = $model->maximum_reviews_users_number + $model->getTheUserLimitOfThisReviewsLicense($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }else{
                             $model->maximum_reviews_users_number = $model->maximum_reviews_users_number + $model->getTheUserLimitOfThisReviewsLicense($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }
                          
                     }
                     
                 $model->reviews_license_end_date = $model->getTheNewDateOfThisReviewsLicense($model->reviews_license_id,$model->reviews_license_end_date,$_REQUEST['number_of_views_block']);
                 
                 $model->feedback_license_id = $_POST['feedback_license_id'];
                 $model->feedback_license_status = $_REQUEST['feedback_license_status'];
                 $model->feedback_license_end_date = $model->getTheNewDateForThisFeedbackLicense($model->feedback_license_end_date,$_REQUEST['number_of_months']);
                 $model->total_remaining_monthly_feedback_response = $model->total_remaining_monthly_feedback_response + $model->getTheTotalRemainingFeedbackResponse($_POST['feedback_license_id'],$_REQUEST['number_of_months']);
                     
                
                 
             }else if($_REQUEST['license_option'] =="reviews"){
                
                     $model->reviews_license_id = $_POST['reviews_license_id'];
                     $model->reviews_license_status = $_REQUEST['reviews_license_status'];
                if($model->isLicenseViewUnlimited($_POST['reviews_license_id'])){
                         $model->total_acquired_views =  -1;
                     }else{
                         if($model->total_acquired_views == -1){
                             $model->total_acquired_views = 0;
                             $model->total_acquired_views =$model->total_acquired_views +  $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);   
                         }else{
                             $model->total_acquired_views =$model->total_acquired_views +  $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']);   
                         }
                       
                     }
                  if($model->isLicenseViewUnlimited($_POST['reviews_license_id'])){
                         $model->total_remaining_views = -1;
                     }else{
                         if($model->total_remaining_views == -1){
                             $model->total_remaining_views = 0;
                             $model->total_remaining_views = $model->total_remaining_views + $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }else{
                             $model->total_remaining_views = $model->total_remaining_views + $model->getTheTotalAcquiredViews($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }
                         
                     }
                 
                if($model->isUserLimitless($_POST['reviews_license_id'])){
                         $model->maximum_reviews_users_number = -1;
                     }else{
                         if($model->maximum_reviews_users_number == -1){
                             $model->maximum_reviews_users_number = 0;
                             $model->maximum_reviews_users_number = $model->maximum_reviews_users_number + $model->getTheUserLimitOfThisReviewsLicense($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }else{
                             $model->maximum_reviews_users_number = $model->maximum_reviews_users_number + $model->getTheUserLimitOfThisReviewsLicense($_POST['reviews_license_id'],$_REQUEST['number_of_views_block']); 
                         }
                          
                     }
                 
                 $model->reviews_license_end_date = $model->getTheNewDateOfThisReviewsLicense($model->id,$model->reviews_license_end_date,$_REQUEST['number_of_views_block']);
                     
                 
                 
             }else if($_REQUEST['license_option'] =="feedback"){
                 
                 $model->feedback_license_id = $_POST['feedback_license_id'];
                 $model->feedback_license_status = $_REQUEST['feedback_license_status'];
                 $model->feedback_license_end_date = $model->getTheNewDateForThisFeedbackLicense($model->feedback_license_end_date,$_REQUEST['number_of_months']);
                 $model->total_remaining_monthly_feedback_response = $model->total_remaining_monthly_feedback_response + $model->getTheTotalRemainingFeedbackResponse($_POST['feedback_license_id'],$_REQUEST['number_of_months']);
                 
             }
             $model->license_option = $_POST['license_option'];
              $model->update_user_id = Yii::app()->user->id;
              
              if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Modification of this domain license was successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to modify this domain license was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
               
           }
 
        }
        
        
        /**
         * This is the function that changes a domain's license
         */
        public function actionchangethisdomainlicenses(){
            $_id = $_REQUEST['id'];
           $model= DomainHasLicenses::model()->findByPk($_id); 
           
            if($_REQUEST['license_option'] =="both"){
                 
                 $model->reviews_license_id = $_POST['reviews_license_id'];
                 $model->reviews_license_status = "inactive";
                 if($model->maximum_reviews_users_number == -1){
                     $model->reviews_license_end_date = null;
                 }
                 if($model->total_acquired_views == -1){
                     $model->total_acquired_views  = 0;
                 }
                 if($model->total_remaining_views == -1){
                     $model->total_remaining_views  = 0;
                 }
                 if($model->maximum_reviews_users_number == -1){
                     $model->maximum_reviews_users_number  = 0;
                 }
                                   
                 $model->feedback_license_id = $_POST['feedback_license_id'];
                 $model->feedback_license_status = "inactive";
                 
                
                 
             }else if($_REQUEST['license_option'] =="reviews"){
                
                     $model->reviews_license_id = $_POST['reviews_license_id'];
                     $model->reviews_license_status = "inactive";
                      if($model->maximum_reviews_users_number == -1){
                            $model->reviews_license_end_date = null;
                       }
                        if($model->total_acquired_views == -1){
                            $model->total_acquired_views  = 0;
                        }
                        if($model->total_remaining_views == -1){
                            $model->total_remaining_views  = 0;
                        }
                        if($model->maximum_reviews_users_number == -1){
                            $model->maximum_reviews_users_number  = 0;
                        }
                 
                     $model->feedback_license_id = null;
                    $model->feedback_license_status = "inactive";
                 
             }else if($_REQUEST['license_option'] =="feedback"){
                 
                 $model->feedback_license_id = $_POST['feedback_license_id'];
                 $model->feedback_license_status = "inactive";
                 
                 $model->reviews_license_id = null;
                 $model->reviews_license_status = "inactive";
                
             }
             $model->license_option = $_POST['license_option'];
              $model->update_user_id = Yii::app()->user->id;
              
              if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Modification of this domain license was successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to modify this domain license was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
           
            
            
        }
}
