<?php

class WhitelistController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewUserWhitelist','AddNewDomainWhitelist','UpdateUserWhitelist',
                                    'UpdateDomainWhitelist','listPlatformWhitelist','listDomainUserWhitelist','listDomainWhitelist','DeleteOneWhitelist',
                                    'stringprocessing','stringprocessing2','strinprocesing3','reversestring','reversestringasarray','stringpermutation',
                                    'stringpermutation','addspacestostringspaces','stringcompression','stringcompression2','multiarray',
                                    'rotatingarraymatrixofNbyN','settingarraycolumnsandrowstozero','checkingforrotationbetweenstrings',
                                    'checkingforrotationbetweenstrings2','updateBits','solution','rotationOfarrayByKSteps','findingUnpairedElementInArray','jumpMinCount',
                                    'findingMissingIntegerInAnArray','findingMinDiffBetweenArrayHalfs','findWhetherArrayIsAPermutation','FrogJumpingFromFromOneBankToAnother',
                                    'maxCounters','MissingInteger','CountDiv','DistintIntegersInArray','CorrectlyNestedStrings'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that creates a new user blacklist
         */
        public function actionAddNewUserWhitelist(){
            
            $model = new Whitelist;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
           if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_created = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully created '$model->name' user whitelist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' user whitelist could not be created";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        
         /**
         * This is the function that creates a new user blacklist
         */
        public function actionAddNewDomainWhitelist(){
            
            $model = new Whitelist;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
           if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_created = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully created '$model->name' domain whitelist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' domain whitelist could not be created";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() != 0,
                       "msg" => $msg
                       ));
           } 
            
            
        }
        
        
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
        /**
         * This  is the function that gets the name of a domain
         */
        public function getTheNameOfThisDomain($domain_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$domain_id);
             $domain = Resourcegroupcategory::model()->find($criteria);   
             
             return $domain['name'];
        }
        
        
        /**
         * This is the function that updates a user blacklist information
         */
        public function actionUpdateUserWhitelist(){
            
           $_id = $_POST['id'];
           $model= Whitelist::model()->findByPk($_id); 
           
           $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
            if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_updated = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully updated '$model->name' user whitelist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' user whitelist could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() != 0,
                       "msg" => $msg
                       ));
           } 
           
            
        }
        
        /**
         * This is the function that updates a user blacklist information
         */
        public function actionUpdateDomainWhitelist(){
            
           $_id = $_POST['id'];
           $model= Whitelist::model()->findByPk($_id); 
           
           $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_name = $this->getTheNameOfThisDomain($domain_id);
            
                       
            $model->name = $_POST['name'];
            $model->description = $_POST['description'];
            $model->reason = $_POST['reason'];
           if(isset($_POST['is_conditional'])){
                $model->is_conditional = $_POST['is_conditional'];
            }else{
                $model->is_conditional = 0;
            }
            $model->domain_id = $domain_id;
            if(isset($_POST['type'])){
                $model->type = strtolower($_POST['type']);
            }
            $model->date_updated = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            
           if($model->save()){
               $msg = "Successfully updated '$model->name' domain whitelist";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' domain whitelist could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() != 0,
                       "msg" => $msg
                       ));
           } 
           
            
        }
        
        
        /**
         * This is the function that deletes a user blacklist
         */
        public function actionDeleteOneWhitelist(){
            
            $_id = $_POST['id'];
            //get the name of this location
            $whitelist = $this->getWhitelistName($_id);
            $model= Whitelist::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$whitelist' whitelist was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$whitelist' whitelist could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
         /**
         * This is the function that gets the blacklist name
         */
        public function getWhitelistName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id); 
            $name = Whitelist::model()->find($criteria);
            
            return $name['name'];
            
        }
        /**
         * This is the function that list all user blacklists on the platform
         */
        public function actionlistPlatformWhitelist(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='type!=:type';
            //$criteria->params = array(':type'=>'special_report');
            $whitelists = Whitelist::model()->findAll($criteria);
                 
            if($whitelists===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "whitelist" => $whitelists
            
                       ));
                       
                }
            
            
            
        }
        
        /**
         * This is the function that list all user blacklists for a domain
         */
        public function actionlistDomainUserWhitelist(){
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid and type=:type';
           $criteria->params = array(':domainid'=>$domain_id,':type'=>'user');
           $whitelist =  Whitelist::model()->findAll($criteria);
                 
           if($whitelist===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "whitelist" => $whitelist
            
                       ));
                       
                }
            
            
            
        }
        
        
        /**
         * This is the function that list all user blacklists for a domain
         */
        public function actionlistDomainWhitelist(){
            
            $user_id = Yii::app()->user->id;
            
           $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
           
                     
           $criteria = new CDbCriteria();
           $criteria->select = '*';
           $criteria->condition='domain_id=:domainid and type=:type';
           $criteria->params = array(':domainid'=>$domain_id,':type'=>'domain');
           $whitelist =  Whitelist::model()->findAll($criteria);
                 
           if($whitelist===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "whitelist" => $whitelist
            
                       ));
                       
                }
            
            
            
        }
        
        
        public function actionstringprocessing(){
            //testing if a string has unique characters
            $str = "abcdefghijklmnopa";
            //spilt this string into characters to get an array of characters
            $str_char = str_split($str, 1);
           //find the uniqueness of the array
            $str_unique = array_unique($str_char);
            
            //if both the length of the both the unique and non unique strings are equal, then the string is unique
            if(sizeof($str_char) == sizeof($str_unique)){
                //return true;
                 echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "is_string_unique" => true
            
                       ));
            }else{
               // return false;
                echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "is_string_unique" => false
            
                       ));
            }
            
        }
        
        
        
        public function actionstringprocessing2(){
            //testing if a string has unique characters
            $str = "abcdefghijklmnop";
           
                   
            //if both the length of the both the unique and non unique strings are equal, then the string is unique
            if(sizeof(str_split($str)) == sizeof(array_unique(str_split($str)))){
                //return true;
                 echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "is_string_unique" => true
            
                       ));
            }else{
               // return false;
                echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "is_string_unique" => false
            
                       ));
            }
            
        }
        
        //if additional data steucture is not to be used
        
        public function actionstrinprocesing3(){
            $str = "abcdefghijklmnopa";
            if(strlen($str) == strlen(count_chars($str, $mode=3))){
                echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "is_string_unique" => true
            
                       ));
            }else{
                echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "is_string_unique" => false
            
                       ));
            }
        }
        
        //Implement a function void reverse(char* str) in C or C++ which reverses a null terminated string

        public function actionreversestring(){
            $str = "abcdefghijklmnop";
            $reversed = strrev($str);
           /** echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "reversed" => $reversed
            
                       ));
            * 
            */
            echo $reversed;
        }
           
        
        //do this in another way by splitting the string into an array and reversing the array
        public function actionreversestringasarray(){
            
            $str = "Who can ever get stuff like this";
            $reversed2 = strrev($str);
            $reversed = array_reverse(str_split($str));
            /**echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "reversed" => implode("",$reversed),
                      "string_reversal"=>$reversed2
            
                       ));
             * 
             */
            echo implode("",$reversed);
            
        }
        
        
        //Given two strings, write a method to decide if one is a permutation of the other.
       /**
        * This is the function to determine if a string is a permutation of another string
        */
        public function actionstringpermutation(){
            $str1 = "abc";
            $str2 = "bacd";
            
            $str1_array = str_split(strtolower($str1));
            $str2_array = str_split(strtolower($str2));
           
            //fing the difference between array 1 and array 2
            $str1_diff = array_diff($str1_array,$str2_array);
            
            $str2_diff = array_diff($str2_array,$str1_array);
            
          //find the lenght of the array diffs
            $str1_diff_len = sizeof($str1_diff);
            $str2_diff_len = sizeof($str2_diff);
            
            if($str1_diff_len == 0){
                $result1="string 1 is a permutation of string 2";
            }else{
                $result1="string 1 is not a permutation of string 2";
            }
            
            if($str2_diff_len == 0){
                $result2="string 2 is a permutation of string 1";
            }else{
                $result2="string 2 is not a permutation of string 1";
            }
          /** echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "string1_result" => $result1,
                      "string2_result"=>$result2
            
                       ));
           * 
           */
            echo "$result1,$result2";
                      
            
        }
        
        
        //ading a string to spaces in a  string. 
        
        public function actionaddspacestostringspaces(){
            $str = "I was heading to Lagos when I saw the Police and made a U turn";
            
            //btreak this string into words and return an array
           $words = str_word_count($str, $format=1, "%$#@!^&*()");
           $padded = [];
           //pad '%20' to each word except the last
           for($i=0;$i<sizeof($words) - 1;++$i){
               $padded[$i] = $words[$i].'%20';
           }
           $size = sizeof($words)-1;
           
           $padded[$size] =$words[$size];
          /** echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                     // "words" => implode("",$words),
                      "padded"=>implode("",$padded),
                     // "string2_result"=>$result2
            
                       ));
           * 
           */
           echo implode("",$padded);
            
        }
        
        
        
        /**
         * Implement a method to perform basic string compression using the counts
            of repeated characters. For example, the string aabcccccaaa would become
                a5blc5. If the "compressed" string would not become smaller than the original
                string, your method should return the original string.
         */
        
        public function actionstringcompression(){
            
            $str = "aabcccccaaa"; //a5b1c5
            
                       
            $compressed = [];
           foreach( count_chars($str,1) as $data=>$val){
              //echo "There were $val instance(s) of \"" , chr($data) , "\" in the string.\n";
              $compressed[] =chr($data).$val;
           }
        if(strlen($str)<strlen(implode("",$compressed))){
              echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                     // "words" => implode("",$words),
                      "string"=>$str,
                     // "string2_result"=>$result2
            
                       ));
              
           }else{
              echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                     // "words" => implode("",$words),
                      "string"=>implode("",$compressed),
                     // "string2_result"=>$result2
            
                       ));
             
               echo implode("",$compressed);
           }
        
         
        }
        
        
        /**
         * Implement a method to perform basic string compression using the counts
            of repeated characters. For example, the string aabcccccaaa would become
                a2blc5a3. If the "compressed" string would not become smaller than the original
                string, your method should return the original string.
         */
        public function actionstringcompression2(){
            $str = "aabcccccaaa"; //a2b1c5a3
            
            //sp;it string to an array
            $splitted = str_split($str, 1);
           $freq = 0;
           $compressed = [];
           $frequency = [];
          $start = 0;
         foreach($splitted as $split){
               
              for($i=$start;$i<sizeof($splitted);++$i){
                  if($split !=$splitted[$i]){
                     
                     break;
                  }else{
                      $freq = $freq + 1;
                  }
                  
              }
              $start = $start + $freq;
             
          if($freq>0){
                  $compressed[] = $split . $freq;
              }
          
              
              $freq = 0;
              
           }
           if(strlen($str)>strlen(implode("",$compressed))){
               echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                     "compressed" => implode("",$compressed),
                     // "string"=>$compressed,
                     "length"=>strlen($str)
            
                       ));
           }else{
                echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                     "compressed" => $str,
                     // "string"=>$compressed,
                     "length"=>strlen($str)
            
                       ));
           }
         
         
            
        }
        
        
        
        /**
         * Given an image represented by an NxN matrix, where each pixel in the image is 4 bytes, write a method to rotate the image by 90 degrees. 
         * Can you do this in place?
         */
        public function actionmultiarray(){
            $another_array =[];
            $all_values = [];
            $my_array = array(
                array(
                  array("a","b","c"),
                  array("aa","bb","cc"),
                  array("aaa","bbb","ccc")  
              ),
                array(
                    array("d","e","f"),
                    array("dd","ee","ff"),
                    array("ddd","eee","fff"),
               ),
                array(
                    array("g","h","i"),
                    array("gg","hh","ii"),
                    array("ggg","hhh","iii")
                ) 
            );
            
            foreach($my_array as $my){
                foreach($my as $key=>$vals){
                   $all_values[]=$vals;
                }
            }
             echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                 "row0" => $my_array[0][0],
                 "row1" => $my_array[0][1],
                 "row2" => $my_array[0][2],
                 "row3" => $my_array[1][0],
                 "row4" => $my_array[1][1],
                 "row5" => $my_array[1][2],
                    //"all_values"=>$all_values
            
                       ));
        }
        
        
        public function actionrotatingarraymatrixofNbyN(){
             $matrix = array(
                array(
                  array("a","b","c"),
                  array("aa","bb","cc"),
                  array("aaa","bbb","ccc")  
              ),
                array(
                    array("d","e","f"),
                    array("dd","ee","ff"),
                    array("ddd","eee","fff"),
               ),
                array(
                    array("g","h","i"),
                    array("gg","hh","ii"),
                    array("ggg","hhh","iii")
                ) 
            );
             $n = 3;
             for($layer = 0;$layer<$n/2; ++$layer){
                 $first = $layer;
                 $last = $n-1-$layer;
                 for($i=$first;$i<$last;++$i){
                     //get the offset
                     $offset = $i-$first;
                     //save the top
                     $top = $matrix[$first][$i];
                     //move left to top
                     $matrix[$first][$i] = $matrix[$last-$offset][$first];
                     
                     //move bottom to left
                     $matrix[$last-$offset][$first] = $matrix[$last][$last-$offset];
                     
                     //right to botton
                     $matrix[$last][$last-$offset] = $matrix[$i][$last];
                     
                     //move top to right
                     $matrix[$i][$last] = $top;
                 }
                 
             }
              echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "rotated_matric" => $matrix,
                               
                       ));
        }
        
        
        /**
         * Write an algorithm such that if an element in an MxN matrix is 0, its entire row and column are set to 0.
         */
        public function actionsettingarraycolumnsandrowstozero(){
             $matrix = array(
                array(
                  array("a","0","c"),
                  array("aa",0,"cc"),
                  array("aaa","0","ccc")  
              ),
                array(
                    array("d",0,"f"),
                    array("dd",0,"ff"),
                    array("ddd","eee",0),
               ),
                array(
                    array("g",0,"i"),
                    array("gg",0,"ii"),
                    array("ggg",0,"iii")
                ) 
            );
             
             $row = array_fill(0, sizeof($matrix), false);
             $column = array_fill(0, sizeof($matrix[0]), false);
            
             //store all the columns and rows with 0 in the row and column matrix
             
             for($i=0;$i<sizeof($row);$i++){
                 for($j=0;$j<sizeof($column);$j++){
                     if($matrix[$i][$j] ==0){
                         $row[$i] = true;
                         $column[$j] = true;
                     }
                 }
             }
             
             //set the rows and columns to zero
             for($i=0;$i<sizeof($row);$i++){
                 for($j=0;$j<sizeof($column);$j++){
                     if($row[$i] == true or $column[$j] == true){
                         $matrix[$i][$j] = 0;
                     }
                 }
             }
              echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "new_matrix" => $matrix,
                    
                               
                       ));
            
        }
        
        
        /**
         * Assume you have a method isSubstring which checks if one word is a substring of another. Given two strings, si and s2, write code to check 
         * if s2 is a rotation of si using only one call to isSubstring (e.g.,"waterbottle"is a rotation of "erbottlewat").
         */
        
        public function actioncheckingforrotationbetweenstrings(){
            $str1 = "erbottlewat";
            $str2 = "waterbottle";
            
            $splitted = str_split($str2, 1);
            $sub_spitted = [];
            
            $rotation_string_length = 3;
            
             if(strlen($str1) == strlen($str2)){
                  for($i=0;$i<$rotation_string_length;$i++){
                             $sub_spitted[] = $splitted[$i];
                  }
            
            //compare the sub splitted to the last three words of the original string
                 if(strcmp(strtolower(implode("",$sub_spitted)),strtolower(substr($str1, -$rotation_string_length))) ===0){
                   echo CJSON::encode(array(
                      "success" => mysqli_connect_errno() == 0,
                      "msg" => "str2 is a rotation of str1",
                      "sub_splitted"=>implode("",$sub_spitted),
                          "substring"=>strtolower(substr($str1, -$rotation_string_length))   
                    
                               
                       ));
                 }else{
                      echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "msg" => "str2 is not a rotation of str1",
                          "sub_splitted"=>implode("",$sub_spitted),
                          "substring"=>strtolower(substr($str1, -$rotation_string_length))
                    
                               
                       ));
                 }
                 
                 
             }else{
                 
                echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "msg" => "str2 is not a aaa rotation of str1"
                    
                               
                       ));
             }
                
            
            
           
           
                
        }
        
       
      /**
       * This is the function that inserts some bits into another bits (example of bit manipulation)
       */  
        public function actionupdateBits(){
            
            $m =1001;
            $n = 1000;
            
            $sum = $n & $m;
            $sub = $m | $n;
            $xor = $n ^ $m;
            
             echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "sum" => $sum,
                          "sub"=>$sub,
                          "XOR"=>$xor
                    
                               
                       ));
                   
                    
                    
                    
        }
        
        /**
         * Tis is te function that returns the longest bit o gap in an interger
         */
        public function actionsolution(){
            $n = 32;
            $longest_zero = [];
            //convert this integer into bits
            $interger_bin = decbin($n);
            
            $bits = str_split(decbin($n), 1);
            $frequency = 0;
                        //start counting the number of 0 gaps
           if($n >=1){
               for($i = 1; $i<sizeof($bits); $i++){
                 if($this->isExistNext1($bits,$i)){
                    if($bits[$i] == 0){
                       $frequency = $frequency + 1;
                   }else{
                       
                       $longest_zero[] = $frequency;
                       $frequency = 0;
                   }
                       
                   }else{
                      $longest_zero[] = $frequency;
                       $frequency = 0;
                   }
                   
                   
                   
                  
               }
               //get the highest frequency from the array;
               $highest = $this->getThisArrayHighestValue($longest_zero);
               
               echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "longest_gap"=>$highest,
                         "gap_frequencies"=>$longest_zero,
                         "bits"=>$interger_bin
                           
                       ));
               
               
               
           }else{
                echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "freqency"=>0
                           
                       ));
               
               
           }
           
            
            
           
            
        }
        
        
        /**
         * This is the function that determines if the another 1 bit is still in the array
         */
        public function isExistNext1($bits,$i){
            
            for($j =$i;$j<sizeof($bits);++$j){
                if($bits[$j] == "1"){
                    return true;
                }
            }
            return false;
        }
        
        /**
         * This is the function that retrievs the highest value in an array
         */
        public function getThisArrayHighestValue($longest_zero){
            
            $highest =0;
            foreach($longest_zero as $high){
                if($high>$highest){
                    $highest = $high;
                }
            }
            return $highest;
            
            
        }
        
        
        /**
         * Rotate an array to the right by a given number of steps.
         */
        public function actionrotationOfarrayByKSteps(){
            
            $numbers = [1,2,4,8,9,10,11];
            $k = 3;
            $temp = [];
            $movables = [];
            $merged = [];
            $count = 0;
          if($this->isArrayContentAndStepsSuitable($numbers,$k)){
              if($this->isArrayMembersAllZeros($numbers) == false){
                if(sizeof($numbers)>$k){
                                   
                for($i=0;$i<sizeof($numbers)-$k;$i++){
                        $temp[] = $numbers[$i];
                        $count = $count + 1;
                    }
                    
                    //collect all the movable integers
                  for($j=$count;$j<sizeof($numbers);$j++){
                        $movables[] = $numbers[$j];
                    }
                   /** 
                    //merge the two arrays
                    foreach($movables as $mov){
                       $merged[] = $mov;
                      
                   }
                
                   foreach($temp as $tem){
                       $merged[] = $tem;
                    }
                  * 
                  */
                    $merged = array_merge($movables,$temp);
                   
                    echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>$merged,
                       
                           
                       ));
                    
                }else{
                    echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>$numbers
                           
                       ));
                    
                    
                }
                
                
          }else{
                echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>$numbers
                           
                       ));
            }
              
              
              
          }else{
              echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "msg"=>"Sorry, the array must be only integers and must contain maximum number of 100 integers and must be within a legal bound of -1000 to 1000. Also the rotation step must not exceed 100"
                           
                       ));
              
              
          }  
           
          
            
            
        }
        
        
        /**
         * This is the function that test if an array contain only 0 element
         */
        public function isArrayMembersAllZeros($numbers){
            foreach($numbers as $num){
                if($num>0){
                    return false;
                }
            }
            return true;
        }
        
        
        /**
         * This is the function that determines if array contents ae suitable
         */
        public function isArrayContentAndStepsSuitable($numbers,$steps){
            if($steps>100){
                return false;
            }
            
            foreach($numbers as $num){
                
                if(is_int($num) == false){
                    return false;
                    
                }
                if($num<-1000 or $num>1000){
                    return false;
                }
            }
            if(sizeof($numbers<=100)){
                return true;
            }else{
                return false;
            }
            
            
        }
        
        
        
        /**
         * Find value that occurs in odd number of elements.
         */
        public function actionfindingUnpairedElementInArray(){
            
            $numbers = [9,3,9,3,9,7,9,7,1];
                        
            if($this->isArrayParametersAndContentLegal($numbers)){
                foreach($numbers as $num){
                    if($this->isNumberPairedInTheArray($numbers, $num)==false){
                        $the_number = $num;
                        break;
                    }
                }
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "unpaired"=>$the_number
                           
                       ));
                
                
            }else{
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>"Array parameters or content is not legal"
                           
                       ));
                
            }
        }
        
        
        /**
         * This is the function that determines if this array content is legal and acceptable
         */
        public function isArrayParametersAndContentLegal($numbers){
            
            if(sizeof($numbers)%2 ==0){
                return false;
            }
            if(sizeof($numbers)<1 or sizeof($numbers)>1000000){
                return false;
            }
            
            foreach($numbers as $num){
                if(is_int($num)==false){
                    return false;
                }
                
                if($num<1 or $num>1000000000){
                    return false;
                }
                
            }
            return true;
            
        }
        
        
        /**
         * This is the function that determines if a number is paired in an array
         */
        public function isNumberPairedInTheArray($numbers, $num){
            $freq =0;
            
           for($i=0;$i<sizeof($numbers);$i++){
               if($numbers[$i] == $num){
                   $freq = $freq + 1;
               }
           }
           if($freq>1){
               if($freq%2!=0){
                   return false;
               }
               
               return true;
               
           }else{
               return false;
           }
        }
        
        
        /**
         * Count minimal number of jumps from position X to Y.
         */
        public function actionjumpMinCount(){
            
            $x = 10000;
            $y = 855999;
            $step = 300;
            
            $count = 0;
            
            
            if($this->isConditionsRightForThisJump($x,$y,$step)){
                for($i=$x;$i<=$y;){
                  $count = $count + 1;
                    $i = $i+$step;
                    if($i>$y){
                        break;
                    }
                     
                    
               }
               echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Minimum_jump_time"=>$count,
                          "condition"=>$this->isConditionsRightForThisJump($x,$y,$step)
                           
                       ));
                
            }else{
                echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"One of the input your supplied is not valid or your initial position is higher than the destination",
                          
                           
                       ));
                
            }
            
            
         }
         
         /**
          * This is the functin that determines if inouted data are valid
          */
         public function isConditionsRightForThisJump($x,$y,$step){
             
             if($x>$y){
                 return false;
             }
             if(is_int($x)){
                 if($x<1 or $x>1000000000){
                 return false;
             }
             }else{
                 return false;
             }
             
             
             if(is_int($y)){
                 if($y<1 or $y>1000000000){
                 return false;
             }
             }else{
                 return false;
             }
             
              if(is_int($step)){
                 if($step<1 or $step>1000000000){
                 return false;
             }
             }else{
                 return false;
             }
             
             return true;
         }
         
         
         /**
          * Find the missing element in a given permutation.
          */
         public function actionfindingMissingIntegerInAnArray(){
             $numbers = [1,2,3,4,6,7,8,9,10];
             
             sort($numbers,SORT_NUMERIC);
             $missing = 0;
             
             $range_step = 1;
        
             if($this->isArrayParametersAndContentAcceptable($numbers)){
               
                for($i=0;$i<sizeof($numbers)-1;$i++){
                    $current = $numbers[$i];
                   if($numbers[$i+1] !=$current + $range_step){
                       $missing = $current + $range_step;
                   }
                   
                }
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Missing_number"=>$missing
                          
                           
                       ));
                 
             }else{
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"The required input data conditions are not met. Please try again",
                          
                           
                       ));
                 
             }
             
             
             
         }
         
         /**
          * This is the function that confirms the acceptability of an array and its content
          */
         public function isArrayParametersAndContentAcceptable($numbers){
             if($this->isArrayAllIntegers($numbers) == false){
                 return false;
             }
             
          if(sizeof($numbers)<0 or sizeof($numbers)>100000){
                 return false;
             }
         
             
            return true;
         }
         
         
         /**
          * This is the function that test the content of an array
          */
         public function isArrayAllIntegers($numbers){
           foreach($numbers as $num){
                 if(is_int($num)==false){
                     return false;
                 }
                 if($num<1 or $num>sizeof($numbers)+1){
                     return false;
                 }
             }
           
             return true;
         }
         
         
         
        /**
         * Minimize the value |(A[0] + ... + A[P-1]) - (A[P] + ... + A[N-1])|.
         */ 
         
         public function actionfindingMinDiffBetweenArrayHalfs(){
             $numbers = [3,1,2,4,3];
             $diff = array();
             $first_sum = 0;
             $second_sum = 0;
             $first = [];
             $second = [];
             
             $min = 0;
             
             if($this->isArrayParameterAcceptable($numbers)){
                 
                for($i=1;$i<sizeof($numbers);$i++){
                  //get the sum of the first half  
                 $first_sum = $this->getTheSumOfTheArrayFirstHalf($i, $numbers);
                 //get the sum of the second half
                 $second_sum = $this->getTheSumOfTheArraySecondHalf($i, $numbers);
                 // comoute the difference of the first half and the second half
                 $diff[] =abs($first_sum - $second_sum);
                }
                $min = $this->getTheMinNumberInThisArray($diff);
             
                echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "differences"=>$diff,
                         "Minimum_Difference"=>$min
                          
                           
                       ));
                 
             }else{
                  echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"The Array Parameters are not acceptable."
                          
                           
                       ));
             }
           
         }
         
         
         /**
          * This os the function that gets the sum of the first half
          */
         public function getTheSumOfTheArrayFirstHalf($i, $numbers){
             $sum = 0;
             for($j=0;$j<$i;$j++){
                 $sum = $sum + $numbers[$j];
             }
             return $sum;
         }
         
         
          /**
          * This os the function that gets the sum of the first half
          */
         public function getTheSumOfTheArraySecondHalf($i, $numbers){
             $sum = 0;
             for($j=$i;$j<sizeof($numbers);$j++){
                 $sum = $sum + $numbers[$j];
             }
             return $sum;
         }
         
         
         /**
          * This is the number that checks if all array parameters are acceptabl
          * e
          */
         public function isArrayParameterAcceptable($numbers){
            
                     
           foreach($numbers as $num){
                if(is_int($num) == false){
                    return false;
                }
               if($num<-1000 or $num>1000){
                    return false;
               }
            }
         
             if(sizeof($numbers)<2 or sizeof($numbers)>100000){
                return false;
            }
            
           
            
            return true;
            
         }
         
         /**
          * This is the function tyhat gets athe minimum number in an array
          */
         public function getTheMinNumberInThisArray($diff){
             $min = $diff[0];
             for($i=1;$i<sizeof($diff);$i++){
                if($min>$diff[$i]){
                     $min=$diff[$i];
                 }
             }
             return $min;
         }
         
         
         /**
          * Check whether array A is a permutation.
          */
         public function actionfindWhetherArrayIsAPermutation(){
             $numbers = [4,3,1,2];
             
             //sort this array
             sort($numbers,SORT_NUMERIC);
             $count = 0;
             
             $sequence_gap = 1;
             if($this->isArrayAndcontentUsable($numbers)){
                 for($i=0;$i<sizeof($numbers)-1; $i++){
                     $current = $numbers[$i];
                   if($numbers[$i+1] !=$current + $sequence_gap){
                       $count = $count + 1;
                   }
                   
                     
                     
                 }
                 if($count == 0){
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "is_permutation"=>1,
                         
                       ));
                     
                 }else{
                     echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "is_permutation"=>0,
                         
                       ));
                     
                 }
             }else{
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong array parameters",
                         
                       ));
                 
             }
         }
         
         
         /**
          * This is the function that confirms if array parameters are usable
          */
         public function isArrayAndcontentUsable($numbers){
             
             if(sizeof($numbers)<1 or sizeof($numbers)>100000){
                 return false;
             }
             foreach($numbers as $num){
                if(is_int($num) == false){
                    return false;
                }
               if($num<1 or $num>1000000000){
                    return false;
               }
            }
           if($this->isArrayDistinct($numbers) == false){
                return false;
            }
          
            return true;
             
         }
       
         
         /**
          * This is the function that confirms if an array is distinct
          */
         public function isArrayDistinct($numbers){
             $count = 0;
            foreach($numbers as $num){
                 for($i=0;$i<sizeof($numbers);$i++){
                     if($num == $numbers[$i]){
                         $count = $count + 1;
                     }
                     if($count>1){
                         return false;
                     }
                }
                $count = 0;
            }
            return true;
             
         }
         
         
         /**
          * Find the earliest time when a frog can jump to the other side of a river.
          */
         public function actionFrogJumpingFromFromOneBankToAnother(){
             
             $numbers = [1,3,1,4,2,3,5,4];
                                     
             $positions = 5;
             $value = -1;
                       
             if($this->isThisArrayParametersContentsAndNumbersAcceptable($numbers, $positions)){
                 if($this->isAllPositionsInTheArrayOccupied($numbers,$positions)){
                     foreach($numbers as $key=>$vals){
                        if($vals==$positions){
                             $value = $key;
                             break;
                         }
                         
                     }
                    echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>$value,
                                                
                       )); 
                 }else{
                     echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>$value,
                         
                       ));
                 }
                  
                 
                 
                 
             }else{
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong array parameters",
                         
                       ));
                 
             }
         }
         
         /**
          * This is the function that determines if all positions in the array is occupied
          */
         public function isAllPositionsInTheArrayOccupied($numbers,$positions){
             $new_array = array_unique($numbers);
             
             if(sizeof($new_array)<$positions){
                 return false;
             }
             
             if(sizeof($new_array)>$positions){
                 return false;
             }
             
            return true;
             
         }
         
         
         
         /**
          * this is the function that determines if array parameters and numbers are valid
          */
         public function isThisArrayParametersContentsAndNumbersAcceptable($numbers,$positions){
             
             if(sizeof($numbers)<0  or sizeof($numbers)>100000){
                 return false;
             }
             
             if(is_int($positions) == false){
                 return false;
             }
             
             if($positions<1 or $positions>100000){
                 return false;
             }
             
             foreach($numbers as $num){
                if(is_int($num) == false){
                    return false;
                }
               if($num<1 or $num>$positions){
                    return false;
               }
            }
            
            return true;
             
             
         }
         
         
         
         /**
          * Calculate the values of counters after applying all alternating operations: increase counter by 1; set value of all counters to current maximum.
          */
         public function actionmaxCounters(){
             $numbers = [3,4,4,6,1,4,4]; //[3,2,2,4,2]
             
             $n = 5;
             
             //initialise all the result array counter to 0
             for($k=0;$k<$n;$k++){
                 $result[] = 0;
             }
                       
             if($this->isArrayAndNumbersWellAcceptable($numbers, $n)){
                 for($i=0;$i<sizeof($numbers); $i++){
                     if($numbers[$i]>=1 and $numbers[$i]<=$n){
                         for($j=0;$j<$n;$j++){
                             if($j ==$numbers[$i]-1){
                                  $result[$j] = $result[$j] + 1;
                             }
                             
                         }
                        
                     }else if($numbers[$i]=$n+1){
                        $max_counter =$this->getTheMaxCounterInResult($result);
                        for($p=0;$p<$n;$p++){
                             $result[$p] = $max_counter;
                         }
                                             }
                     
                 }
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "counter"=>$result,
                         "max"=>$max_counter
                         
                       ));
                 
             }else{
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong array parameters",
                         
                       ));
                 
             }
             
             
         }
         
         /**
          * This is the function that returns the maximum value in an array
          */
         public function getTheMaxCounterInResult($result){
             $max = $result[0];
             foreach($result as $res){
                 if($max<$res){
                     $max=$res;
                 }
             }
             return $max;
         }
         
         
         /**
          * This is the value taht confirms tha validity of some inputted data
          */
         public function isArrayAndNumbersWellAcceptable($numbers, $n){
             if(is_int($n) == false){
                 return false;
             }
             if($n<1 or $n>100000){
                 return false;
             }
             
             if(sizeof($numbers)<1 or sizeof($numbers)>100000){
                 return false;
             }
             foreach($numbers as $num){
                 if(is_int($num)==false){
                     return false;
                 }
                 if($num<1 or $num>$n+1){
                     return false;
                 }
             }
             return true;
         }
         
         
         /**
          * Find the smallest positive integer that does not occur in a given sequence.
          */
         public function actionMissingInteger(){
             
             $numbers = [1,2,6,4,1,2,5,7,8,10,9,11,13,12];
             
             $numbers = array_unique($numbers);
             //sort this array
             sort($numbers);
             $sequence_gap= 1;
             
             if($this->isArrayAndNumbersValid($numbers)){
                 for($i=0;$i<sizeof($numbers)-1; $i++){
                     $current = $numbers[$i];
                   if($numbers[$i+1] !=$current + $sequence_gap){
                       if($current + $sequence_gap<0){
                           $missing = 1;
                       }else{
                          $missing = $current + $sequence_gap; 
                       }
                       
                   }else{
                       if(($numbers[sizeof($numbers)-1] + 1)<0){
                           $missing = 1;
                       }else{
                            $missing = $numbers[sizeof($numbers)-1] + 1;
                       }
                      
                   }
                 } 
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Missing Integer"=>$missing,
                         
                         
                       ));
             }else{
                  echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong array parameters",
                         
                       ));
                 
                 
             }
         }
         
         
         
         /**
          * This is the function that confirms validity of array and numbers
          */
         public function isArrayAndNumbersValid($numbers){
             if(sizeof($numbers)<1 or sizeof($numbers)>100000){
                 return false;
             }
             
             foreach($numbers as $num){
                 if(is_int($num) == false){
                     return false;
                 }
                 
                 if($num<-1000000 or $num>1000000){
                     return false;
                 }
             }
             return true;
         }
         
         
         
         /**
          * Compute number of integers divisible by k in range [a..b].
          */
         public function actionCountDiv(){
             $a = 6;
             $b = 11;
             $k = 3;
             $counter = 0;
             if($this->isGivenParametersValid($a,$b,$k)){
                 for($i=6;$i<=$b;$i++){
                     if($i%$k == 0){
                         $counter = $counter + 1;
                     }
                 }
                  echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Number of Integers divisble by k"=>$counter,
                         
                         
                       ));
                 
             }else{
                  echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong parameters",
                         
                       ));
             }
                     
         }
         
         
         
         /*8
          * Valid parameter checks
          */
         public function isGivenParametersValid($a,$b,$k){
             
             if(is_int($a)==false){
                 return false;
             }
             if(is_int($b)==false){
                 return false;
             }
             if(is_int($k)==false){
                 return false;
             }
             
             if($a>$b){
                 return false;
             }
             
             if($a<0 or $a>2000000000){
                 return false;
             }
             
              if($b<0 or $b>2000000000){
                 return false;
             }
             
              if($k<1 or $k>2000000000){
                 return false;
             }
             return true;
         }
         
         
         
         /**
          * Compute number of distinct values in an array.
          */
         
         function actionDistintIntegersInArray(){
             
             $numbers = [2,1,1,2,3,1];
             
             //sort this array
             sort($numbers);
             
             //find the distict members of thus array
             $new_numbers = array_unique($numbers);
             
            if($this->isParameterValid($numbers)){
                 $count = sizeof($new_numbers);
                 
                  echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Distinct Numbers"=>$count,
                         
                         
                       ));
             }else{
                 echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong parameters",
                         
                       ));
             }
             
         }
         
         
         /**
          * This is the function that confirms if parameters is valid
          */
         public function isParameterValid($numbers){
             if(sizeof($numbers)<0 or sizeof($numbers)>100000){
                 return false;
             }
             
             foreach($numbers as $num){
                 if(is_int($num) == false){
                     return false;
                 }
                 if($num<-1000000 or $num>1000000){
                     return false;
                 }
             }
             return true;
         }
         
         
         
         
         /**
          * Determine whether a given string of parentheses (multiple types) is properly nested.
          */
         public function actionCorrectlyNestedStrings(){
             //$str = "{[()()]}";
            $str = "())(";
            // $str = "(()(())())";
             $str_rev = str_split(strrev($str),1);
             
             
             
             $open = [];
             $close = [];
             $error_counter = 0;
             
             if($this->areParametersValid($str)){
                 if(strlen($str)%2==0){
                     //convert to an array
                     $array =  str_split($str, 1);
                     //push into the open array
                    for($i=0;$i<sizeof($array)/2;$i++){
                        $open[] = $array[$i];
                        
                    }
                    
                    //push the other half to the other array
                 for($j=0;$j<sizeof($str_rev)/2;$j++){
                        $close[] = $str_rev[$j];
                    }
                    
                  for($j=0;$j<sizeof($open);$j++){
                      
                      if(($open[$j] =='{' and $close[$j]=='}')or $open[$j] =='}' and $close[$j]=='{'){
                          continue;
                      }
                      if(($open[$j] =='(' and $close[$j]==')')or $open[$j] ==')' and $close[$j]=='('){
                          continue;
                      }
                      if(($open[$j] =='[' and $close[$j]==']')or $open[$j] ==']' and $close[$j]=='['){
                          continue;
                      }
                     
                      $error_counter = $error_counter + 1;
                      
                  }  
                    
                  
                  
                   if($error_counter == 0){
                       
                        echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "open"=>$open,
                         "close"=>$close,
                          "result"=>1  
                            
                         
                       ));  
                   }else{
                       echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "open"=>$open,
                         "close"=>$close,
                          "result"=>0  
                            
                         
                       ));  
                       
                   }  
                  
                     
                     
                 }else{
                      echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "result"=>0
                         
                       ));
                     
                 }
                 
                 
                 
             }else{
                  echo CJSON::encode(array(
                         "success" => mysqli_connect_errno() == 0,
                         "Message"=>"You inputed wrong parameters",
                         
                       ));
                 
             }
             
         }
         
         
         /**
          * This si the function to check if parameters are valid
          */
         public function areParametersValid($str){
             if(strlen($str)<0 or strlen($str)>200000){
                 return false;
             } 
             
             $array=  str_split($str, 1);
             $strings =["(", "{", "[", "]", "}",")"];
             foreach($array as $arr){
                 if(in_array($arr,$strings) ==false){
                     return false;
                 }
                 
             }
             return true;
                     
         }
         
         
         
         public function actionsolution2($S,$T){
             
             if($this->areParametersAreValid($S,$T)){
                 $result = $this->thepossibleactiononthestrings($S,$T);
                 return $result;
                 
             }
             
             
         }
         
         
         function areParametersAreValid($S,$T){
             
             $arrays = str_split($S,1);
             $arrayt = str_split($T,1);
             if((strlen($S)<1 or strlen($S)>100)){
                 return false;
             }
             
             if((strlen($T)<1 or strlen($T)>100)){
                 return false;
             }
             
             foreach($arrays as $arr){
                 if(is_int($arr)){
                     return false;
                 }
                 
                 if(is_float($arr)){
                     return false;
                 }
                 
                 if(is_double($var)){
                     return false;
                 }
             }
             
              foreach($arrayt as $arr){
                 if(is_int($arr)){
                     return false;
                 }
                 
                 if(is_float($arr)){
                     return false;
                 }
                 
                 if(is_double($var)){
                     return false;
                 }
             }
             
             
             
         }
         
         
         public function thepossibleactiononthestrings($S,$T){
             $arrays = str_split($S, 1);
             $arrayt = str_split($T, 1);
             
            //sort te arrays
             sort($arrays);
             sort($arrayt);
             $count = 0;
             $t_collector =[];
             $s_collector = [];
             
             if(strlen($S) == strlen($T)){
                 for($i = 0; $i<sizeof($arrays);$i++){
                     if($arrays[$i] != $arrayt[$i]){
                         $t_collector[] = $arrayt[$i];
                         $s_collector[] = $arrays[$i];
                         $count = $count + 1;
                     }
                 }
                 if($count==1){
                     $from_s = implode("",$s_collector);
                     $from_t = implode("",$t_collector);
                     return "REPLACE $from_s $from_t";
                 }else if($count ==2){
                     $from_s = implode("",$s_collector);
                     $from_t = implode("",$t_collector);
                     return "SWAP $from_s,$from_t";
                 }else{
                     return "IMPOSSIBLE";
                 }
             }else if(strlen($T-strlen($S)==1)){
                 foreach($arrayt as $arrt){
                     for($i=0;$i<sizeof($arrays);$i++){
                         if($arrt !=$arrays[$i]){
                            $t_collector[] = $arrt;
                            $count = $count + 1;
                         }
                     }
                 }
             }
             $from_t = implode("",$t_collector);
             return "INSERT $from_t";
         }
         
         
         
}
