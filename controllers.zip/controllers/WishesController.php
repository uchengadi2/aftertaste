<?php

class WishesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListAllWishesPerUser','DeleteOneWish',
                                    'ListAllWishesBelongingToADomain','RetrieveThisWishInfo','CreateNewWish','UpdateUserWish',
                                    'retrieveTheTaskNameGivenTheId','AddNewWish'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function to delete one need
         */
        public function actionDeleteOneWish(){
            
            $_id = $_POST['id'];
            $model=Wishes::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'A Wish Item Successfully Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'wish Item Not Deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        /**
         * This is the function that will list all the wishes base on tool owner domain
         * or the wishes creator domain id
         */
        public function actionListAllWishesBelongingToADomain(){
            //determine the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //obtain the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
             if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformWishSupport")){
                 
                  
                //determine the users domain
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                //$criteria->condition='(category_id=:id or tool_domain_id=:toolid)';
                //$criteria->params = array(':id'=>$domainid, ':toolid'=>$domainid);
                $wishes= Wishes::model()->findAll($criteria1);
            
                if($wishes===null) {
                    http_response_code(404);
                    $msg ='No record found';
                   header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" =>$msg
                       ));
                       
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "wishes" =>$wishes
                       ));
                       
                } 
                 
             }else{
                 
                  //determine the users domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(category_id=:id or tool_domain_id=:toolid)';
            $criteria->params = array(':id'=>$domainid, ':toolid'=>$domainid);
            $wishes= Wishes::model()->findAll($criteria);
            
            if($wishes===null) {
                    http_response_code(404);
                    $msg ='No record found';
                   header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "msg" =>$msg
                       ));
                       
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "wishes" =>$wishes
                       ));
                       
                } 
                 
             }
           
            
            
     
        }
        
        
        /**
         * This is the function that will list all wishes peruser
         */
        public function actionListAllWishesPerUser(){
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //retrieve all wishes created by this user
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='create_user_id=:id';
            $criteria->params = array(':id'=>$userid);
            $wishes= Wishes::model()->findAll($criteria);
            
             if($wishes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "wishes" =>$wishes
                       ));
                       
                } 
            
        }
        
        
        /**
         * This is the function that retrieves a wish information
         */
        public function actionRetrieveThisWishInfo(){
            
             $_id = $_POST['id'];
            
             //$_id = 1;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$_id);
            $wish= Wishes::model()->find($criteria);
            
            $tool_owner_domain = $this->determineDomainNameGivenItId($wish['tool_domain_id']);
            $requester_domain = $this->determineDomainNameGivenItId($wish['category_id']);
            $toolbox = $this->retrieveWishToolboxName($wish['resourcegroup_id']);
            $tool = $this->determineResourceOrToolName($wish['resource_id']);
            
            //spool the requester detail
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, firstname, middlename, lastname';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$wish['create_user_id']);
            $user= User::model()->find($criteria1);
            
            if($wish===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "userdomain" => $tool_owner_domain,
                           "requester_domain"=>$requester_domain,
                            "toolbox" => $toolbox,
                            "tool" =>$tool,
                           "user" =>$user,
                           "wish" =>$wish
                          
                           
                          
                       ));
                       
                } 
            
            
        }
        
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that determines a toolbox/resourcegroup name given its id
         */
        public function retrieveWishToolboxName($toolboxid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolboxid);
            $name= Resourcegroup::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        
        /**
         * This is the function for creating new wishes
         */
        public function actionCreateNewWish(){
            
            $model=new Wishes;
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            //tool id is
            $toolid = $_POST['tool'];
            
            //determine the resourcegroup/toolbox given resource/toolid and the userid
            $toolboxid = $this->determineToolboxIdGivenToolId($userid,$toolid);
            
            
            //determine the id of the creator of the tool
            $creatorid = $this->determineCreatorIdGiventheToolId($toolid);
            
            //determine the domain of the creator of the tool
            $ownerid = $this->determineAUserDomainIdGiven($creatorid);
            
            $model->resource_id = $_POST['tool'];
            if(isset($_POST['wishes'])){
                $model->wishes = $_POST['wishes'];
            }
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
            }
           if(isset($_POST['benefit'])){
                $model->benefit = $_POST['benefit'];
           }
            $model->category_id = $domainid;
            $model->create_user_id = Yii::app()->user->id;
            $model->create_time = new CDbExpression('NOW()');
            $model->tool_domain_id = $ownerid;
            $model->resourcegroup_id = $toolboxid;
            
           
             if($model->save()){
                      
                            $msg = 'A Wish was Successfully Created';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'A Wish Not Created Successfully';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
        
        }
        
        /**
         * This is the function for creating new wishes
         */
        public function actionAddNewWish(){
            
            $model=new Wishes;
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
                              
             //tool id is
            $toolid = $_POST['toolid'];           
            //determine the resourcegroup/toolbox given resource/toolid and the userid
           // $toolboxid = $this->determineToolboxIdGivenToolId($userid,$toolid);
            $toolboxid = $_POST['toolboxid'];
            
            //determine the id of the creator of the tool
            $creatorid = $this->determineCreatorIdGiventheToolId($toolid);
            
            //determine the domain of the creator of the tool
            $ownerid = $this->determineAUserDomainIdGiven($creatorid);
            
            $model->resource_id = $_POST['toolid'];
            if(isset($_POST['wishes'])){
                $model->wishes = $_POST['wishes'];
            }
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
            }
           if(isset($_POST['benefit'])){
                $model->benefit = $_POST['benefit'];
           }
            $model->category_id = $domainid;
            $model->create_user_id = Yii::app()->user->id;
            $model->create_time = new CDbExpression('NOW()');
            $model->tool_domain_id = $ownerid;
            $model->resourcegroup_id = $toolboxid;
            
           
             if($model->save()){
                      
                            $msg = 'A Wish was Successfully Created';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                       "msg" => $msg
                                    
                                )
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'A Wish Not Created Successfully';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg
                                  
                             )
                           );
                  }  
            
        
        }
        
        
        
        /**
         * This is the function that determines a tool creator id given its tool id
         */
        public function determineCreatorIdGiventheToolId($toolid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, create_user_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolid);
            $id= Resources::model()->find($criteria);
            
            return $id['create_user_id'];
            
        }
        
        
        /**
         * This is the function that determines the toolbox id given a toolid and the userid
         */
        public function determineToolboxIdGivenToolId($userid,$toolid){
            
            //determine all the toolboxes/resourcegroup assigned to this user
            $toolboxes = $this->determineAllToolboxesAssignedToUser($userid);
            
            //determine the toolbox that has this tool
            
            foreach($toolboxes as $toolbox){
                
                if($this->isToolInToolbox($toolid,$toolbox) == true){
                    return $toolbox;
                    
                }
                
            }
            return null;
            
        }
        
        /**
         * This is the function that all toolboxes assigned to a user
         */
        public function determineAllToolboxesAssignedToUser($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='user_id=:id';
            $criteria->params = array(':id'=>$userid);
            $toolboxes= UserHasResourcegroup::model()->findAll($criteria);
            
            $alltoolboxes = [];
            
            foreach($toolboxes as $toolbox){
                
                $alltoolboxes[] = $toolbox['resourcegroup_id'];
            }
            
            return $alltoolboxes;
            
        }
       
        
        /**
         * This is the function that determines if a tool is in a toolbox
         */
        public function isToolInToolbox($toolid, $toolbox){
            
            //determine if tool is in toolbox
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resource_has_resourcegroups')
                    ->where("resource_id=$toolid and resourcegroup_id=$toolbox");
                $result = $cmd->queryScalar();
            
                     
               //confirm if this tool is in the toolbox
               if($result > 0){
                        return true;
                    
                     }else{
                         
                         return false;
                     }
            
            
        }
        
        /**
         * This is the function to update user wishes
         */
        public function actionUpdateUserWish(){
            
            $_id = $_POST['id'];
            $model=Wishes::model()->findByPk($_id);
            
            $toolname = $_POST['tool'];
            $toolid = $this->determineResourceOrToolId($toolname);
            
            $model->resource_id= $toolid;
            if(isset($_POST['wishes'])){
                $model->wishes = $_POST['wishes'];
            }
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
            }
           if(isset($_POST['benefit'])){
                $model->benefit = $_POST['benefit'];
           }
            $model->update_user_id = Yii::app()->user->id;
            $model->update_time = new CDbExpression('NOW()');
            
            if($model->save()){
                      
                            $msg = 'A Wish was Successfully Updated';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                            );
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'A Wish Not Updated Successfully';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
           
            
            
            
        }
        
        /**
         * This is the function to retreive the name of a tool given the id
         */
        public function actionRetrieveTheTaskNameGivenTheId(){
            
            $resourceid = $_POST['id'];
            
            $resourcename = $this->determineResourceOrToolName($resourceid);
            
            if($resourcename===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "name" =>$resourcename,  
                           
                          
                       ));
                       
                } 
            
            
        }
        
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Wishes the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Wishes::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Wishes $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='wishes-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
