<?php

class ClusterNeighbourhoodsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','removeneighbourhoodincluster','addneighbourhoodtocluster'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that adds new neighbourhood to city
         */
        public function actionaddneighbourhoodtocluster(){
            $model = new ClusterNeighbourhoods;
            
            $model->cluster_id = $_REQUEST['cluster_id'];
            $model->neighbourhood_id = $_REQUEST['hood_id'];
            $cluster_name = $_REQUEST['cluster_name'];
            
            if($model->isThisNeighbourhoodAlreadyAssignedToACluster($model->neighbourhood_id) == false){
                 if($model->save()){
                $msg = "This neighbourhood is successfully assigned to the '$cluster_name' cluster";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to assign this neighbourhood to the '$cluster_name' cluster was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
              
            }else{
                $msg = "This neighbourhood is already assigned to this or another cluster. To reassign this neighbourhood, you have to first remove it from that cluster";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
        }
        
        
        
        /**
         * This is the function that removes a neihbourhood from a cluster
         */
        public function actionremoveneighbourhoodincluster(){
            
            
            $cluster_id = $_REQUEST['cluster_id'];
            $neighbourhood_id = $_REQUEST['hood_id'];
            $cluster_name = $_REQUEST['cluster_name'];
            
                       
            if($this->isThisNeighbourhoodAlreadyAssignedToThisCluster($cluster_id,$neighbourhood_id)){
                //get the grouping id
                
                $grouping_id= $this->getTheGroupingIdOfThisClusterAssignment($cluster_id,$neighbourhood_id);
                
                $model= ClusterNeighbourhoods::model()->findByPk($grouping_id);
                
                 if($model->delete()){
                $msg = "This neighbourhood is successfully removed from the '$cluster_name' cluster";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to remove  this neighbourhood  from the '$cluster_name' cluster was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
              
            }else{
                $msg = "This neighbourhood is not currently assigned to the '$cluster_name' cluster. Therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
            
        }
        
        
        
         /**
         * This is the function that retrieves a grouping id
         */
        public function getTheGroupingIdOfThisClusterAssignment($cluster_id,$neighbourhood_id){
            $model = new ClusterNeighbourhoods;
            return $model->getTheGroupingIdOfThisClusterAssignment($cluster_id,$neighbourhood_id);
        }
        
        /**
         * This is the function that confirms if a neighbourhood is already assigned to a cluster
         */
        public function isThisNeighbourhoodAlreadyAssignedToThisCluster($cluster_id,$neighbourhood_id){
            $model = new ClusterNeighbourhoods;
            return $model->isThisNeighbourhoodAlreadyAssignedToThisCluster($cluster_id,$neighbourhood_id);
        }
}
