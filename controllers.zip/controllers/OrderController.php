<?php

class OrderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllOpenOrders','listAllMerchantOpenOrders','listAllOrders','retrievesomeitemsdetails',
                                    'listAllOpenOrders','listAllOpenOrdersWithConfirmedPayment'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * This is the function that list all open orders
         */
        public function actionlistAllOpenOrders(){
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"open");
              $orders= Order::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $orders,
                                   
                    
                            ));
              
        }
        
        
        /**
         * This is the function that retrieves all merchant items in open oeders
         */
        public function actionlistAllMerchantOpenOrders(){
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
                        
            //retrieve all the open orders
                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>"open");
            $orders= Order::model()->findAll($criteria);
            
            
            
             
           $target = [];
           foreach($orders as $order){
              if($this->isThisOrderWithMerchantProduct($order['id'],$merchant_id)){
                   $target[] = $order;
               }
              
          }
           
           
           
           
           
           header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    //"order" => $items,
                                    "order"=>$target,
                                   
                            ));
            
            
        }
        
        
        /**
         * This is the function that confirms if an order containes a merchant's product
         */
        public function isThisOrderWithMerchantProduct($order_id,$merchant_id){
            $model = new OrderItem;
            return $model->isThisOrderWithMerchantProduct($order_id,$merchant_id);
        }
        
        
        /**
         * this is the function that list all orders
         */
        public function actionlistAllOrders(){
             $order = Order::model()->findAll();
               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $order,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves some details about an order item
         */
        public function actionretrievesomeitemsdetails(){
            
            $product_id = $_REQUEST['product_id'];
            $order_id = $_REQUEST['order_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $promotion_id = $_REQUEST['promotion_id'];
                    
            
            //get the product details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $product= Product::model()->find($criteria);
            
            //get the order details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order_id);
            $order= Order::model()->find($criteria);
            
             //get the city of delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order['delivery_city_id']);
            $city= City::model()->find($criteria);
            
            
             //get the stateof delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city['state_id']);
            $state= State::model()->find($criteria);
            
            //get the unit pricing details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing= Pricing::model()->find($criteria);
            
            //get the pricing details
              //get the unit measurement type details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing['measurement_type_id']);
            $unit= MeasurementType::model()->find($criteria);
            
               //get the product pricing promotion details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$promotion_id);
            $promotion= Promotion::model()->find($criteria);
            
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $order,
                                   "product"=>$product,
                                    "unit"=>$unit,
                                    "pricing"=>$pricing,
                                    "promotion"=>$promotion,
                                    "city"=>$city,
                                    "state"=>$state
                    
                            ));
            
        }
        
        
        
        /**
         * This is the function that list all open orders with confirmed payment
         */
        public function actionlistAllOpenOrdersWithConfirmedPayment(){
            $model = new Payment;
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"open");
              $orders= Order::model()->findAll($criteria);
              
              $target = [];
              
              foreach($orders as $order){
                  if($model->isThePaymentOfThisOrderConfirmed($order['id'])){
                      $target[] = $order;
                  }
              }
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $target,
                                   
                    
                            ));
              
        }
        
        
}
