<?php

class ReviewsLicensingController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listallreviewslicenses','addingthisnewreviewsplan','deleteonereviewslicense',
                                    'modifythisreviewsplan'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all reviews licenses in the database
         */
        public function actionlistallreviewslicenses(){
            
             $licenses = ReviewsLicensing::model()->findAll();
                if($licenses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "license" => $licenses,
                                   
                    
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that adds a reviews license
         */
        public function actionaddingthisnewreviewsplan(){
            $model=new ReviewsLicensing;

		$model->plan = $_POST['plan'];
                $model->views_limit = $_POST['views_limit'];
                $model->cost_per_1000_views = $_POST['cost_per_1000_views'];
                $model->minimum_views_block = $_POST['minimum_views_block'];
                $model->plan_cost = $_POST['plan_cost'];
                if(isset($_REQUEST['is_with_duration'])){
                    $model->is_with_duration = $_REQUEST['is_with_duration'];
                    $model->duration = $_REQUEST['duration'];
                 }else{
                    $model->is_with_duration =0;
                     $model->duration="none";
                 }
                if(isset($_REQUEST['could_be_rolled_over'])){
                    $model->could_be_rolled_over = $_REQUEST['could_be_rolled_over'];
                 }else{
                    $model->could_be_rolled_over=0;
                   
                }
                $model->users_limit = $_REQUEST['users_limit'];
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New reviews license plan created successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The creation of new reviews license plan was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
        }
        
        
        /**
         * This is the function that modifies a reviews license
         */
        public function actionmodifythisreviewsplan(){
             $_id = $_POST['id'];
            $model= ReviewsLicensing::model()->findByPk($_id);

		$model->plan = $_POST['plan'];
                $model->views_limit = $_POST['views_limit'];
                $model->cost_per_1000_views = $_POST['cost_per_1000_views'];
                $model->minimum_views_block = $_POST['minimum_views_block'];
                $model->plan_cost = $_POST['plan_cost'];
                if(isset($_REQUEST['is_with_duration'])){
                    $model->is_with_duration = $_REQUEST['is_with_duration'];
                    $model->duration = $_REQUEST['duration'];
                 }else{
                     $model->is_with_duration =0;
                     $model->duration="none";
                 }
                if(isset($_REQUEST['could_be_rolled_over'])){
                    $model->could_be_rolled_over = $_REQUEST['could_be_rolled_over'];
                 }else{
                     $model->could_be_rolled_over =0;
                 }
                $model->users_limit = $_REQUEST['users_limit'];
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This reviews license plan was updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The modification of this reviews license plan was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
        }
        
        
        /**
         * This is the function that deletes a reviews license 
         */
        public function actiondeleteonereviewslicense(){
            $_id = $_POST['id'];
            $model= ReviewsLicensing::model()->findByPk($_id);
            
          if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->plan' reviews license plan is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
}
