<?php

class DeliberationSidetalkController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','senddeliberationmessagesidetalktorecepients','retrieveMessageDeliberationSideTalk',
                                    'replyingtoadeliberationsidetalk','retrieveAllEligibleThisSidetalkParticipant','retrievethisDeliberationSidetalkContent',
                                    'retrievethisMessageDeliberationSidetalkContent','replyingtothisdeliberationmessage','deletdeliberationsidetalkfromthesidetalkboard'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that sends deliberation side talk message its intended recepients
         */
        public function actionsenddeliberationmessagesidetalktorecepients(){
            $model = new DeliberationSidetalk;
            
            $deliberation_id =$_REQUEST['deliberation_id'];
            
            $message_id =$_REQUEST['message_id'];
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $message = $_REQUEST['sidetalk_message'];
            $bucket_counter = 0;
            $counter = 0;
            $category = strtolower('chat');
            $code = $model->generateTheCodeForThisDeliberationSidetalk($deliberation_id);
            
            
                //get the side talk recepient
             $sidetalk_recepients = [];
             $number_of_recepient = 0;
             if(empty($_REQUEST['sidetalk_participant']) == false){
               foreach($_REQUEST['sidetalk_participant'] as $rece){
                   if(is_numeric($rece)){
                       $sidetalk_recepients[] = $rece;
                       $number_of_recepient = $number_of_recepient + 1;
                   }
                    
                }
                
           
             }
             if($number_of_recepient>0){
                 $file_error_counter = 0;
            
            //move the mesage file if available
          if($message == ""){
                if($_FILES['sidetalk_filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['sidetalk_filename']['name'];
                      $filename_size = $_FILES['sidetalk_filename']['size'];
                      $file_type =  $_FILES['sidetalk_filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
            
            
          foreach($sidetalk_recepients as $recee){
              if($recee != $user_id){
                  if($this->isThisColleagueEligibleForThisMessage($this->getTheIssueAndValueIdOfThisMessage($message_id),$recee)){
                        $sidetalk_id =$model->executesendingChatDeliberationSideTalkToThisMember($deliberation_id,$message_id,$recee,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$sidetalk_recepients);
                        $counter = $counter + 1;
                   }
         
                    } 
              }
                     
            
                 //write to the chat message outbox here
         $model->writeThisChatDeliberationSidetalkToTheSenderOutbox($deliberation_id,$message_id,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$sidetalk_recepients);        
           
           
            $msg = "Deliberation side talk is made successfully";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg,
                                    "recepients"=>$sidetalk_recepients,
                                    "counter"=>$counter,
                                    "number_of_recepient"=>$number_of_recepient
                                  
                                   
                            ));
                
                
                 
                 
             }else{
                 
                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => "Please select the member(s) you wish to have a sidetalk with",
                                   
                            ));
                 
             }
           
            
                
            
            
        }
        
        
          /**
         * This is the function that retrieves the issues and values of a message
         */
        public function getTheIssueAndValueIdOfThisMessage($message_id){
            $model = new Message;
            return $model->getTheIssueAndValueIdOfThisMessage($message_id);
        }
        
        
         /**
         * This is the function that determines if a colleague is eligible for a chat message reciept
         */
        public function isThisColleagueEligibleForThisMessage($issue_id,$member_id){
            $model = new IssuesForMember;
            return $model->isThisColleagueEligibleForThisMessage($issue_id,$member_id);
        }
        
        
        
        /**
         * This is the function that replles to a side talk
         */
        public function actionreplyingtothisdeliberationmessage(){
            
            $model = new DeliberationSidetalk;
            
            $deliberation_id =$_REQUEST['deliberation_id'];
            
            $sidetalk_id =$_REQUEST['sidetalk_id'];
            
            $message_id =$_REQUEST['message_id'];
            
                      
            $user_id = Yii::app()->user->id;
            
            $domain_id = $model->determineAUserDomainIdGiven($user_id);
            
            $message = $_REQUEST['sidetalk_message'];
            $counter = 0;
            $category = strtolower('chat');
            $code = $model->getTheCodeOfThisSidetalkDeliberation($sidetalk_id);
            
            //get the side talk recepient
            $sidetalk_recepients = [];
           
             $sidetalk_recepients = explode(',',$_REQUEST['recepients_list']);
            //add the original sender to the lisr of recepients
             
             if($_REQUEST['from'] == $user_id){
                 $sidetalk_recepients = $sidetalk_recepients;
             }else{
                 $sidetalk_recepients[] = $_REQUEST['from'];
             }
             //$sidetalk_recepients = array_unique($sidetalk_recepients);
             $file_error_counter = 0;
           
            //move the mesage file if available
        if($message == ""){
                if($_FILES['sidetalk_filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['sidetalk_filename']['name'];
                      $filename_size = $_FILES['sidetalk_filename']['size'];
                      $file_type =  $_FILES['sidetalk_filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
            
            
           //send the chat message to all eligible colleagues
            foreach($sidetalk_recepients as $recipient){
                if($recipient != $user_id){
                     if($this->isThisColleagueEligibleForThisMessage($this->getTheIssueAndValueIdOfThisMessage($message_id),$recipient)){
                        $new_sidetalk_id =$model->sendingareplyChatDeliberationSideTalkToThisMember($sidetalk_id,$deliberation_id,$message_id,$recipient,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$sidetalk_recepients);
                        $counter = $counter + 1;
                    }
                }
                  
         
            }     
                
        
            
                 //write to the chat message outbox here
         $model->writeThisReplyChatDeliberationSidetalkToTheSenderOutbox($sidetalk_id,$deliberation_id,$message_id,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$sidetalk_recepients);        
            
      
            $msg = "Deliberation side talk is made successfully";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "msg" => $msg,
                                    "recepients"=>$sidetalk_recepients,
                                    "code"=>$code
                                  
                                   
                            ));
        }
        
        
        /**
         * This is the function that retrieves this member deliberstion all side talks
         */
        public function actionretrieveMessageDeliberationSideTalk(){
            $model = new DeliberationSidetalk;
            
            $user_id = Yii::app()->user->id;
            
            $deliberation_id = $_REQUEST['deliberation_id'];
            //get all side talks sent out by user
                      
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='((category=:cat and (`from`=:from and type=:type)) or ((category=:cat and type=:ttype) and `to`=:to)) and deliberation_id=:del';
            $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':to'=>$user_id,':ttype'=>"inbox",':del'=>$deliberation_id);
            $criteria->order='id,parent_id';
            $messages= DeliberationSidetalk::model()->findAll($criteria);
            
             if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "sidetalk" => $messages,
                     
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves the list of eligible participants for a side talk
         */
        public function actionretrieveAllEligibleThisSidetalkParticipant(){
            $group_id = $_REQUEST['group_id'];
            
             $user_id = Yii::app()->user->id;
            
             if($group_id == 0){
                //get all the colleagues of this member
                $target_members = $this->getAllTheColleaguesOfThisMember($user_id);
            }else{
                //send to all group members
                $target_members = $this->getAllTheMembersOfThisNetwork($group_id);
            }
            $participant = [];
            foreach($target_members as $member){
                $criteria1 = new CDbCriteria();
                $criteria1->select = 'id, name';
                $criteria1->condition='id=:id';
                $criteria1->params = array(':id'=>$member);
                $user= User::model()->find($criteria1);
                $participant[] = $user;
                
            }
            
             if($target_members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "participant" => $participant,
                     
                       ));
                       
                }
        }
        
         /**
         * This is the function that retrieves the colleagues of a user 
         */
        public function getAllTheColleaguesOfThisMember($user_id){
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesOfThisMember($user_id);
        }
        
        
        /**
         * This is the function that gets all the members of a network group
         */
        public function getAllTheMembersOfThisNetwork($network_id){
            $model = new NetworkHasMembers;
            return $model->getAllTheMembersOfThisNetwork($network_id);
        }
        
        
        /**
         * This is the platform that deletes a message deliberation sidetalk from the sidetalk board
         */
        public function actiondeletdeliberationsidetalkfromthesidetalkboard(){
            $sidetalk_id = $_REQUEST['sidetalk_id'];
                     
            $model= DeliberationSidetalk::model()->findByPk($sidetalk_id);
            
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                             "msg" => $msg
                
                       ));
                                      
          }else if($model->isDeliberationSidetalkMessageWithChild($sidetalk_id) == false){
                if($model->delete()){
                    $msg = "This deliberation sidetalk message is successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                               "msg" => $msg
                          
                          
                       ));
                 }else{
                     $msg = "Deliberation message could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                     
                 }    
                       
                   
                    
           
     
            }else{
               $msg = "You have to first delete all replied messages on this deliberation sidetalk before deleting it"; 
                            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() != 0,
                                "msg" => $msg
                          
                          
                            )); 
                            
                }
                
            
            
        }
        
        
        
       
        
        /**
         * This is the function that retrieves a particular deliberation side talk content
         */
        public function actionretrievethisMessageDeliberationSidetalkContent(){
            
           $sidetalk_id = $_REQUEST['sidetalk_id'];
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$sidetalk_id);
             $sidetalk= DeliberationSidetalk::model()->find($criteria);
            
            if($sidetalk===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "sidetalk" => $sidetalk,
                     
                       ));
                       
                }
            
        }
        
        
        
      
}
