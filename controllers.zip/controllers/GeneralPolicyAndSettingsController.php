<?php

class GeneralPolicyAndSettingsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','savegeneralpolicyparameters','modifygeneralpolicyparameters','savegeneralbaserateparameters','modifygeneralbaserateparameters','saverateparameters',
                                    'modifyrateparameters','retrievepolicyparameters','retrievepolicyandsettingsinfo','retrievemarketplacesettingsdetails','settheorphandeliveryrate'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that creates a new policy
         */
        public function actionsavegeneralpolicyparameters(){
            
            $model=new GeneralPolicyAndSettings;

		
		$model->order_request = $_POST['order_request'];
                $model->delivery_request = $_POST['delivery_request'];
                $model->payment_on_delivery_request = $_POST['payment_on_delivery_request'];
                $model->deposit_payment_request = $_POST['deposit_payment_request']; 
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This general policy setting is save successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "policy_id"=>$model->id,
                                        "order_request"=>$model->order_request,
                                        "delivery_request"=>$model->delivery_request,
                                        "payment_on_delivery_request"=>$model->payment_on_delivery_request,
                                        "deposit_payment_request"=>$model->deposit_payment_request,
                                  )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to save this general policy was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        /**
         * This is the function that modifies a new policy
         */
        public function actionmodifygeneralpolicyparameters(){
            
             $_id = $_POST['id'];
             $model=  GeneralPolicyAndSettings::model()->findByPk($_id);

		
		$model->order_request = $_POST['order_request'];
                $model->delivery_request = $_POST['delivery_request'];
                $model->payment_on_delivery_request = $_POST['payment_on_delivery_request'];
                $model->deposit_payment_request = $_POST['deposit_payment_request']; 
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This general policy setting is updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "policy_id"=>$model->id,
                                        "order_request"=>$model->order_request,
                                        "delivery_request"=>$model->delivery_request,
                                        "payment_on_delivery_request"=>$model->payment_on_delivery_request,
                                        "deposit_payment_request"=>$model->deposit_payment_request,
                                  )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to update this general policy was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        
        /**
         * This is the function that adds the general base rate parameters
         */
        public function actionsavegeneralbaserateparameters(){
            
            $model=new GeneralPolicyAndSettings;

		
		$model->general_base_rate = $_POST['general_base_rate'];
                $model->base_rate_condition = $_POST['base_rate_condition'];
                $model->measurement_type_preference = $_POST['measurement_type_preference'];
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This general base rate parameters are set successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "policy_id"=>$model->id,
                                        "general_base_rate"=>$model->general_base_rate,
                                        "base_rate_condition"=>$model->base_rate_condition
                                        
                                  )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to set this general base rate parameters was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        
        /**
         * This is the function that modifies the general base rate parameters
         */
        public function actionmodifygeneralbaserateparameters(){
            
           $_id = $_POST['id'];
             $model=  GeneralPolicyAndSettings::model()->findByPk($_id);

		
		$model->general_base_rate = $_POST['general_base_rate'];
                $model->base_rate_condition = $_POST['base_rate_condition'];
                $model->measurement_type_preference = $_POST['measurement_type_preference'];
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This general base rate parameters are set successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "policy_id"=>$model->id,
                                        "general_base_rate"=>$model->general_base_rate,
                                        "base_rate_condition"=>$model->base_rate_condition
                                        
                                  )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to set this general base rate parameters was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        /**
         * This is the function that adds the payment and delivery rate parameters
         */
        public function actionsaverateparameters(){
            
            $model=new GeneralPolicyAndSettings;

		
		$model->at_one_delivery_threadshold = $_POST['at_one_delivery_threadshold'];
                $model->payment_on_delivery_threshold = $_POST['payment_on_delivery_threshold'];
                $model->minimum_total_order_value = $_POST['minimum_total_order_value'];
                $model->minimum_initial_deposit_in_percentages = $_POST['minimum_initial_deposit_in_percentages'];
                if(isset($_POST['is_promotional_items_allowed_for_deposit_payment'])){
                    $model->is_promotional_items_allowed_for_deposit_payment = $_POST['is_promotional_items_allowed_for_deposit_payment'];
                }else{
                    $model->is_promotional_items_allowed_for_deposit_payment=0;
                }
                if(isset($_POST['is_promotional_items_allowed_for_payment_on_delivery'])){
                    $model->is_promotional_items_allowed_for_payment_on_delivery = $_POST['is_promotional_items_allowed_for_payment_on_delivery'];
                }else{
                    $model->is_promotional_items_allowed_for_payment_on_delivery =0;
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This rate parameters are set successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "policy_id"=>$model->id,
                                        "at_one_delivery_threadshold"=>$model->at_one_delivery_threadshold,
                                        "payment_on_delivery_threshold"=>$model->payment_on_delivery_threshold,
                                        "minimum_total_order_value"=>$model->minimum_total_order_value,
                                        "minimum_initial_deposit_in_percentages"=>$model->minimum_initial_deposit_in_percentages
                                        
                                  )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to set this rate parameters was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        
         /**
         * This is the function that modifies the payment and delivery rate parameters
         */
        public function actionmodifyrateparameters(){
            
            $_id = $_POST['id'];
             $model=  GeneralPolicyAndSettings::model()->findByPk($_id);
		
		$model->at_one_delivery_threadshold = $_POST['at_one_delivery_threadshold'];
                $model->payment_on_delivery_threshold = $_POST['payment_on_delivery_threshold'];
                $model->minimum_total_order_value = $_POST['minimum_total_order_value'];
                $model->minimum_initial_deposit_in_percentages = $_POST['minimum_initial_deposit_in_percentages'];
               if(isset($_POST['is_promotional_items_allowed_for_deposit_payment'])){
                    $model->is_promotional_items_allowed_for_deposit_payment = $_POST['is_promotional_items_allowed_for_deposit_payment'];
                }else{
                    $model->is_promotional_items_allowed_for_deposit_payment=0;
                }
                if(isset($_POST['is_promotional_items_allowed_for_payment_on_delivery'])){
                    $model->is_promotional_items_allowed_for_payment_on_delivery = $_POST['is_promotional_items_allowed_for_payment_on_delivery'];
                }else{
                    $model->is_promotional_items_allowed_for_payment_on_delivery =0;
                }
                
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'This rate parameters are updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        "policy_id"=>$model->id,
                                       "at_one_delivery_threadshold"=>$model->at_one_delivery_threadshold,
                                        "payment_on_delivery_threshold"=>$model->payment_on_delivery_threshold,
                                        "minimum_total_order_value"=>$model->minimum_total_order_value,
                                        "minimum_initial_deposit_in_percentages"=>$model->minimum_initial_deposit_in_percentages
                                        
                                  )
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Attempt to update this rate parameters was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
        }
        
        
        
        /**
         * This is the function that list all countries on the platform
         */
        public function actionretrievepolicyparameters(){
            
            $policy = GeneralPolicyAndSettings::model()->findAll();
                if($policy===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "policy" => $policy,
                                   
                    
                            ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieve the policy and settings info
         */
        public function actionretrievepolicyandsettingsinfo(){
            
            $policy = GeneralPolicyAndSettings::model()->findAll();
                if($policy===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "policy" => $policy,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves the general settings of the market place
         */
        public function actionretrievemarketplacesettingsdetails(){
            
            //get the settings default delivery settings
            $settings = GeneralPolicyAndSettings::model()->findAll();
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "settings" => $settings,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that sets the intra cluster delivery rate of a cluster
         */
        public function actionsettheorphandeliveryrate(){
            
                   
            $_id = $_REQUEST['id'];
            
            $model= GeneralPolicyAndSettings::model()->findByPk($_id);
            $model->default_orphan_base_rate = $_REQUEST['default_orphan_base_rate'];
            $model->default_orphan_maximum_base_weight = $_REQUEST['default_orphan_maximum_base_weight'];
            $model->orphan_rate_per_additional_kg = $_REQUEST['orphan_rate_per_additional_kg'];
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'The orphan location delivery rate for this marketplace is successfully set or modified';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'Attempt to set or modify the orphan delivery rate for this marketplace failed';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
        }
   
        
}
