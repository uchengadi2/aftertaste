<?php

class FeedbackLicensingController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listallfeedbacklicenses','addingthisnewfeedbackplan','modifythisfeedbackplan',
                                    'deleteonefeedbacklicense'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        
        /**
         * This is the function that retrieves all feedback license plans in the database 
         */
        public function actionlistallfeedbacklicenses(){
            
            $licenses = FeedbackLicensing::model()->findAll();
                if($licenses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "license" => $licenses,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that adds a feedback license
         */
        public function actionaddingthisnewfeedbackplan(){
            $model=new FeedbackLicensing;

		$model->plan = $_POST['plan'];
                $model->response_limit = $_POST['response_limit'];
                $model->cost_per_month = $_POST['cost_per_month'];
                $model->cost_per_year = $_POST['cost_per_year'];
                if(isset($_REQUEST['is_with_monthly_discount'])){
                    $model->is_with_monthly_discount = $_REQUEST['is_with_monthly_discount'];
                    $model->monthly_discount = $_POST['monthly_discount'];
                }else{
                    $model->is_with_monthly_discount=0;
                    $model->monthly_discount = 0;
                }
                if(isset($_REQUEST['is_with_yearly_discount'])){
                    $model->is_with_yearly_discount = $_REQUEST['is_with_yearly_discount'];
                     $model->yearly_discount = $_POST['yearly_discount'];
                }else{
                    $model->is_with_yearly_discount=0;
                    $model->yearly_discount = 0;
                }
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'New feedback license plan created successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The creation of new feedback license plan was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
            
        }
        
        
        /**
         * This is the function that modifies the feedback license information
         */
        public function actionmodifythisfeedbackplan(){
            $_id = $_POST['id'];
            $model=  FeedbackLicensing::model()->findByPk($_id);
            
                $model->plan = $_POST['plan'];
                $model->response_limit = $_POST['response_limit'];
                $model->cost_per_month = $_POST['cost_per_month'];
                $model->cost_per_year = $_POST['cost_per_year'];
                if(isset($_REQUEST['is_with_monthly_discount'])){
                    $model->is_with_monthly_discount = $_REQUEST['is_with_monthly_discount'];
                    $model->monthly_discount = $_POST['monthly_discount'];
                }else{
                    $model->is_with_monthly_discount =0;
                    $model->monthly_discount =0;
                }
                if(isset($_REQUEST['is_with_yearly_discount'])){
                    $model->is_with_yearly_discount = $_REQUEST['is_with_yearly_discount'];
                    $model->yearly_discount = $_POST['yearly_discount'];
                }else{
                    $model->is_with_yearly_discount =0;
                    $model->yearly_discount =0;
                }
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Feedback license plan updated successfully';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                 }else {
                         //$result['success'] = 'false';
                         $msg = 'The modification of feedback license plan was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                  }  
            
        }
        
        /**
         * This is the function that deletes a feedback license 
         */
        public function actiondeleteonefeedbacklicense(){
            $_id = $_POST['id'];
            $model=  FeedbackLicensing::model()->findByPk($_id);
            
          if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$model->plan' feedback license plan is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
	
}
