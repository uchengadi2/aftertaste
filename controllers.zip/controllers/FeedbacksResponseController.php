<?php

class FeedbacksResponseController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','submittinguserfeedback','retrievefeedbackresponsedetails'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that submits product feedbacks from a user
         */
        public function actionsubmittinguserfeedback(){
            
            $model = new FeedbacksResponse;
            $code_id = $_REQUEST['code_id'];
            $model->feedback_id = $_REQUEST['feedback_id'];
            $model->user_id = $_REQUEST['user_id'];
            $model->product_likes = $_REQUEST['product_likes'];
            $model->product_hates = $_REQUEST['product_hates'];
            $model->was_needs_met = $_REQUEST['was_needs_met'];
            $model->unfillfulled_needs = $_REQUEST['unfillfulled_needs'];
            $model->recommendation_to_friends = $_REQUEST['recommendation_to_friends'];
            $model->can_get_product_again = $_REQUEST['can_get_product_again'];
            $model->your_expected_improvements_in_our_product = $_REQUEST['your_expected_improvements_in_our_product'];
            $model->preferred_product_to_this = $_REQUEST['preferred_product_to_this'];
            $model->default_feedback_comment = $_REQUEST['default_feedback_comment'];
            $model->date_provided = new CDbExpression('NOW()');
            if(isset($_REQUEST['is_atm_not_operational'])){
                 $model->is_atm_not_operational = $_REQUEST['is_atm_not_operational'];
            }
           if(isset($_REQUEST['is_atm_out_of_cash'])){
               $model->is_atm_out_of_cash = $_REQUEST['is_atm_out_of_cash'];
           }
            if(isset($_REQUEST['is_atm_out_of_service'])){
                $model->is_atm_out_of_service = $_REQUEST['is_atm_out_of_service'];
            }
            if(isset($_REQUEST['is_atm_debiting_but_not_giving_cash'])){
                $model->is_atm_debiting_but_not_giving_cash = $_REQUEST['is_atm_debiting_but_not_giving_cash'];
            }
            if(isset($_REQUEST['is_atm_giving_out_dirty_notes'])){
                $model->is_atm_giving_out_dirty_notes = $_REQUEST['is_atm_giving_out_dirty_notes'];
            }
            
            
            if($_REQUEST['feedback_id'] != NULL  or $_REQUEST['feedback_id'] != ""){
                 $code = $this->getThisCode($code_id);
            if($model->isUserPermittedToProvideThisFeedbackResponse($model->feedback_id,$model->user_id,$code_id)){
                
             if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"The owner of this product or service will like to say thank you to you for providing them with a valuable feedback on their product or service. They are committed to serving you better. "
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"There was a vaidation issue while trying to provide feedback on this product. Kindly check your input data and try again or contact customer service for assistance"
                        ));  
            }
           }else{
                
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" =>"Sorry, this '$code' code does not support multiple feedback responses per an individual as you had already provided a feedback response before"
                        ));
            }
           
                
            }else{
                
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                            "msg" =>"Sorry, The template for this feedback is yet to be provided therefore this feedback cannot be given at this point. Please try again after some days"
                        ));
            }
            
        }
        
        
          /**
         * This is the function that retrieves a code given a code is
         */
        public function getThisCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->getThisCode($code_id);
        }
	
        /**
         * This is the function that retrieves feedback response details
         */
        public function actionretrievefeedbackresponsedetails(){
            
            $user_id = Yii::app()->user->id;
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $domain_reg_number = $this->getThisDomainUniqueNumber($domain_id);
            
            $domain_country = $this->getThisDomainCountryCode($domain_id);
            
            $response_id = $_REQUEST['response_id'];
            //get the feedback response details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$response_id);
            $response = FeedbacksResponse::model()->find($criteria); 
            
            //get the feedback enlistment details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$response['feedback_id']);
            $feedback = FeedbacksForEnlistment::model()->find($criteria); 
            
            if($response===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "feedback" =>$feedback,
                                    "response"=>$response,
                                    "domain_id"=>$domain_id,
                                    "reg_number"=>$domain_reg_number,
                                    "domain_country"=>$domain_country
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
        
        
        /**
         * This is the function that retrieves a domain code
         */
        public function getThisDomainUniqueNumber($domain_id){
            $model = new ResourceGroupCategory;
            return $model->getThisDomainUniqueNumber($domain_id);
        }
        
        
        /**
         * This is the function that gets a domain's country
         */
        public function getThisDomainCountryCode($domain_id){
            $model = new ResourceGroupCategory;
            return $model->getThisDomainCountryCode($domain_id);
        }
}
