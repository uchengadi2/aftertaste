<?php

class DuplicationsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','ListAllDuplicatedTools','EditToolDuplication',
                                    'CreateNewToolDuplication','retrieveToolName','DeleteOneDuplicateTool',
                                    'ListAllTaskForThisTool','retrieveReconstructableToolValue','DeleteOneTaskFromDuplicatedTool',
                                    'AddNewTaskToDuplicatedTool','retrieveToolAndTaskName','EditDuplicatedToolInformation'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that list all duplicated tools in this domain
         */
        public function actionListAllDuplicatedTools(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformToolDuplicationSupport")){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='is_duplicate=:duplicate';
                $criteria->params = array(':duplicate'=>1);
                $tools = Resources::model()->findAll($criteria);
                 
                if($tools===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "tool" => $tools
                          
                           
                           
                          
                       ));
                       
                }
                
            }else{
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid and is_duplicate=:duplicate';
                $criteria->params = array(':domainid'=>$domainid,':duplicate'=>1);
                $tools = Resources::model()->findAll($criteria);
                 
                if($tools===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "tool" => $tools
                          
                           
                           
                          
                       ));
                       
                }
            }
            
            
        }
	
        
        /**
         * This is the function to create new duplicated tool for this tool
         */
        public function actionCreateNewToolDuplication(){
            
             $model=new Duplications;
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if(is_numeric($_POST['original_tool'])){
               $model->original_tool_id = $_POST['original_tool'];
            }else{
                $model->original_tool_id = $_POST['original_tool_id'];
            }
             $model->name = $_POST['name'];
          
            if(isset($_POST['duplicate'])){
                $model->duplicate = $_POST['duplicate'];
            }else{
                $model->duplicate = 0;
            }
            if(isset($_POST['reconstruct_tool'])){
                $model->reconstruct_tool = $_POST['reconstruct_tool'];
            }else{
              $model->reconstruct_tool = 0;  
            }
            
            //retrieve all the values from the original tool and assign to the duplicate tool
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$model->original_tool_id);
            $original = Resources::model()->find($criteria);
            
            $model->price = $original['price'];
            $model->discount_rate = $original['discount_rate'];
            $model->is_duplicate = 1;
            $model->discount_proof = $original['discount_proof'];
            $model->select_value = $original['select_value'];
            $model->cumulative_component_price = $original['cumulative_component_price'];
            $model->price_preference = $original['price_preference'];
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
             }else{
                 $model->description = $original['description'];
             }
            $model->resourcetype_id = $original['resourcetype_id'];
            $model->product_id = $original['product_id'];
            $model->text = $original['text'];
            $model->url = $original['url'];
            $model->icon = $original['icon'];
            $model->filename = $original['filename'];
            $model->poster = $original['poster'];
            $model->zipped_filename = $original['zipped_filename'];
            $model->index_html = $original['index_html'];
            $model->enforce_equal_share = $original['enforce_equal_share'];
            $model->domain_id = $domainid;
            $model->create_user_id = $userid;
            $model->create_time = new CDbExpression('NOW()');
            
            //obtain the domain of the user that created the toolbox
            //$original_tool_domain_id = $this->determineAToolDomainGivenId($original['id']); 
            if($model->save()){
                        if($this->assignSameTaskToThisDuplicatedTool($model->id,$model->original_tool_id,$domainid,$original['domain_id'])){
                            $msg = "$original->name File was successfully duplicated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                        }else{
                            $msg = "Some or all of the slot from $original->name file was not assigned to the duplicate";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            ); 
                        }
                           
                           
                       
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "Validation Error: File Duplication was not successful";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  } 
            
        }
        
          /**
         * This is the function that is used to edit or update duplicated tool information
         */
        public function actionEditToolDuplication(){
            $_id = $_POST['id'];
            $model=Duplications::model()->findByPk($_id);
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if(is_numeric($_POST['original_tool'])){
               $model->original_tool_id = $_POST['original_tool'];
            }else{
                $model->original_tool_id = $_POST['original_tool_id'];
            }
             $model->name = $_POST['name'];
          
            if(isset($_POST['duplicate'])){
                $model->duplicate = $_POST['duplicate'];
            }else{
                $model->duplicate = 0;
            }
            if(isset($_POST['reconstruct_tool'])){
                $model->reconstruct_tool = $_POST['reconstruct_tool'];
            }else{
              $model->reconstruct_tool = 0;  
            }
            
            //retrieve all the values from the original tool and assign to the duplicate tool
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$model->original_tool_id);
            $original = Resources::model()->find($criteria);
            
            $model->price = $original['price'];
            $model->discount_rate = $original['discount_rate'];
            $model->is_duplicate = 1;
            $model->discount_proof = $original['discount_proof'];
            $model->select_value = $original['select_value'];
            $model->cumulative_component_price = $original['cumulative_component_price'];
            $model->price_preference = $original['price_preference'];
            if(isset($_POST['description'])){
                 $model->description = $_POST['description'];
             }else{
                 $model->description = $original['description'];
             }
            $model->resourcetype_id = $original['resourcetype_id'];
            $model->product_id = $original['product_id'];
            $model->text = $original['text'];
            $model->url = $original['url'];
            $model->icon = $original['icon'];
            $model->filename = $original['filename'];
            $model->poster = $original['poster'];
            $model->zipped_filename = $original['zipped_filename'];
            $model->index_html = $original['index_html'];
            $model->enforce_equal_share = $original['enforce_equal_share'];
            $model->domain_id = $domainid;
            $model->create_user_id = $userid;
            $model->create_time = new CDbExpression('NOW()');
            
            //obtain the domain of the user that created the toolbox
            //$original_tool_domain_id = $this->determineAToolDomainGivenId($original['id']); 
            if($model->save()){
                            $msg = "$original->name File was successfully duplicated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                            );
                        
                 }else {
                         //$result['success'] = 'false';
                         $msg = "Validation Error: File Duplication was not successful";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
        }
        
        
        
        
        /**
         * This is the function that assigns same task to the duplicated tool as it was in the original tool
         */
        public function assignSameTaskToThisDuplicatedTool($new_tool_id,$original_tool_id,$new_tool_domainid,$original_tool_domain){
           
                //retrieve all tasks in the original tool
            if($this->isOriginalNotAlsoADuplicate($original_tool_id)){
                
                $all_tasks = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='parent_id=:id';
                $criteria->params = array(':id'=>$original_tool_id);
                $tasks= Resources::model()->findAll($criteria);
                
                foreach($tasks as $task){
                    //assign this task to this duplicated tool
                    $this->assignThisTaskToThisDuplicateTool($new_tool_id,$task['id'],$original_tool_id);
                }
              return true;
                
            }else{
                //get the basement original tool id
                $main_original_id = $this->obtainTheMainOriginalToolId($original_tool_id);
                $all_tasks = [];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='parent_id=:id';
                $criteria->params = array(':id'=>$main_original_id);
                $tasks= Resources::model()->findAll($criteria);
                
                foreach($tasks as $task){
                    //assign this task to this duplicated tool
                    $this->assignThisTaskToThisDuplicateTool($new_tool_id,$task['id'],$original_tool_id);
                }
              return true;
            }
               
                
           
        }
        
        /**
         * This is the function that performs the actual assignment of task to the new tool
         */
        public function assignThisTaskToThisDuplicateTool($new_tool_id,$task_id,$original_tool_id){
            
            if($this->noOccurrenceOfThisTaskInThisTool($new_tool_id,$task_id)){
               //retrieve some values from the main original tool
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$task_id);
                    $original= Resources::model()->find($criteria);

                     //Assign this original paras to the new task assignment
                    $cmd =Yii::app()->db->createCommand();
                    $result = $cmd->insert('duplicate_tool_has_task',
                	array('tool_id'=>$new_tool_id,
				'task_id'=>$task_id,
                                'price'=>$original['price'],
                                'percentage_share'=>$original['percentage_share'],
                                'respect_task_percentage_share'=>$original['respect_task_percentage_share'],
                                'create_time'=>new CDbExpression('NOW()'),
                                'create_user_id'=>Yii::app()->user->id
                                
		
			)
			
                    );
                    if($result>0){
                        return true;
                    }else{
                        return false;
                    }
                
             
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that verifies if a task had already been assigned to a duplicate tool
         */
        public function noOccurrenceOfThisTaskInThisTool($new_tool_id,$task_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('duplicate_tool_has_task')
                    ->where("tool_id = $new_tool_id && task_id =$task_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return false;
                }else{
                    return true;
                }
        }
        
        /**
         * This is the function that deletes one task from a duplicated tool
         */
        public function actionDeleteOneDuplicateTool(){
            
            $_id = $_POST['id'];
            $model=Resources::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'This Duplicated File had been deleted successfully'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'Validation Error: This Duplicated File was not deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        
        /**
         * This is the function that retrieves the name of a tool
         */
        public function actionretrieveToolName(){
            
             $tool_id = $_REQUEST['id'];
             $product_id = $_REQUEST['product_id'];
             $original_tool_id = $_REQUEST['original_tool_id'];
             
             //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the prefferred currency code
            
            $currency_code = $this->getThisCurrencyCode($preferred_currency);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
             
            
          if($this->isOriginalNotAlsoADuplicate($original_tool_id)){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $toolname = Resources::model()->find($criteria); 
            
            //retrieve the product name
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$product_id);
            $productname = Products::model()->find($criteria1); 
            
            //retrieve all the other details of the tool
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$tool_id);
             $tool_details = Resources::model()->find($criteria2); 
             
             
             if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheOriginalToolOrTaskPrice($original_tool_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheOriginalToolOrTaskPrice($original_tool_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
            
            
            //return $creator['create_user_id'];
            if($toolname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolname" => $toolname['name'],
                           "productname"=>$productname['name'],
                           "tooldetails"=>$tool_details,
                           "price"=>$price,
                           "currency_code"=>$currency_code
                           
                           
                          
                       ));
                       
                }
                
        }else{
            $main_original_id = $this->obtainTheMainOriginalToolId($original_tool_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $toolname = Resources::model()->find($criteria); 
            
            //retrieve the product name
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $productname = Products::model()->find($criteria); 
            
            //retrieve all the other details of the tool
             $criteria2 = new CDbCriteria();
             $criteria2->select = '*';
             $criteria2->condition='id=:id';
             $criteria2->params = array(':id'=>$main_original_id);
             $tool_details = Resources::model()->find($criteria2); 
             
             if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheOriginalToolOrTaskPrice($main_original_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheOriginalToolOrTaskPrice($main_original_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
            
            //return $creator['create_user_id'];
            if($toolname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolname" => $toolname['name'],
                           "productname"=>$productname['name'],
                           "tooldetails"=>$tool_details,
                           "price"=>$price,
                           "currency_code"=>$currency_code
                           
                           
                           
                          
                       ));
                       
                }
                
                
            }
           
        }
        
        
        
        /**
         * This is the function that retrieves the task and the tools names in a duplicated tool
         */
        public function actionretrieveToolAndTaskName(){
            
            $tool_id = $_REQUEST['tool_id'];
             $task_id = $_REQUEST['task_id'];
           
                 
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $toolname = Resources::model()->find($criteria); 
            
            //retrieve the task name
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$task_id);
            $taskname = Resources::model()->find($criteria1); 
            
             if($toolname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolname" => $toolname['name'],
                           "taskname"=>$taskname['name']
                           
                           
                           
                          
                       ));
                       
                }
        }
        
        /**
         * This is the tool that verifies if a tool is original but not also a dupicate tool
         */
        public function isOriginalNotAlsoADuplicate($tool_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$tool_id);
               $original= Resources::model()->find($criteria);
               
               if($original['is_duplicate'] == 1){
                   return false;
                   
               }else{
                   return true;
                   
               }
            
        }
        
        /**
         * This is the function that recursively determines the original tool id within a duplicate tree
         */
        public function obtainTheMainOriginalToolId($tool_id){
             $original = 0;
            if($this->isOriginalNotAlsoADuplicate($tool_id)){
                //retrieve its original toolbox
                $original = $this->retrieveTheOriginalToolIdForThisTool($tool_id);
                if($this->isOriginalNotAlsoADuplicate($original)){
                    ;
                    
                }else{
                  $original = $this->obtainTheMainOriginalToolId($original);
                }
            }else{
               $original = $this->retrieveTheOriginalToolIdForThisTool($tool_id);
               $original = $this->obtainTheMainOriginalToolId($original);
                
            }
             
            return $original;
        }
      
        /**
         * This is the function that retrieves the original tool id for a tool
         */
        public function retrieveTheOriginalToolIdForThisTool($tool_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$tool_id);
               $original= Resources::model()->find($criteria);
               
               return $original['original_tool_id'];
            
        }
        
        
        /**
         * This is the function that list all task in a duplicate tool
         */
        public function actionListAllTaskForThisTool(){
           
            $tool_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='tool_id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $tasks = DuplicateToolHasTask::model()->findAll($criteria);
            
                       
            if($tasks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "task" => $tasks
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves the recontructable tool value
         */
        public function actionretrieveReconstructableToolValue(){
            
            $tool_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $recon = Resources::model()->find($criteria); 
            
            //return $creator['create_user_id'];
            if($recon===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "reconstruct" => $recon['reconstruct_tool']
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that will remove one task from a duplicated task
         * 
         */
        public function actionDeleteOneTaskFromDuplicatedTool(){
            
            $task_id = $_POST['task_id'];
            $tool_id = $_POST['tool_id'];
            
            $domainid = $this->retrieveTheIdOfTheDomainThatOwnsThisTool($tool_id);
            //get the domain of the toolbox creator
            //$domainid = $this->determineAUserDomainIdGiven($toolbox_creator);
            
            if($this->isPermittedToRemoveTaskFromToolByThisDomain($domainid)){
                $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('duplicate_tool_has_task', 'task_id=:id and tool_id=:toolid', array(':id'=>$task_id, ':toolid'=>$tool_id ));
                if($result > 0){
                    //retrieve the task that were squeezable and update their share value with their original value 
                    if($this->isSqueezedShareValuesOfThisToolReplaced($tool_id,$domainid)){
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'The document had successfully been removed from the File',
                       ));
                 
                        
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'Document successfully removed from the file but the squeezed share value was not updated',
                       ));
                
                    }
                   
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'The document was not removed from the file',
                       ));
                 
                }
               
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'The owner of the file does not permit the removal of documents from their file',
                       ));
                }
            
        }
        
        /**
         * This is the function that determines if the original squeezed tasks value had been replaced
         */
        public function isSqueezedShareValuesOfThisToolReplaced($tool_id,$domainid){
            
            //retrieve all the squeezable task in the tool
            $tasks = $this->retrieveAllSqueezableTaskInTool($tool_id);
            
            foreach($tasks as $task){
                //obtain the original squeezable value of the task
                $original_value = $this->retrieveTaskOriginalSqueezedValue($tool_id,$task);
                if($this->isThereSpaceInThisTool($task,$tool_id, $original_value,$domainid)){
                    //replace the squeezed in value with the actual value
                    if($this->assignTaskPercentageShare($original_value,$tool_id,$task)){
                                 return true;
                             }else{
                                 return false;
                             }
                }elseif($this->toolRemainingSpaceValue($tool_id,$task) > 0){
                  if($original_value > $this->toolRemainingSpaceValue($tool_id,$task)){
                         $original_value = $this->toolRemainingSpaceValue($tool_id,$task);
                         if($this->isTaskShareValueAcceptable($original_value,$tool_id,$task)){
                      
                             //assign orginal value as the task percentage share
                             if($this->assignTaskPercentageShare($original_value,$tool_id,$task)){
                                 return true;
                             }else{
                                 return false;
                             }
                  }}else{
                      if($this->assignTaskPercentageShare($original_value,$tool_id,$task)){
                                 return true;
                             }else{
                                 return false;
                             }
                  }
                }
                
            }
            
            
        }
        
        /**
         * This is the function that retrieves all sqyueezable tasks in a tool
         */
        public function retrieveAllSqueezableTaskInTool($tool_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='tool_id=:id and respect_share_but_could_squeeze_in=:squeeze';
            $criteria->params = array(':id'=>$tool_id,':squeeze'=>1);
            $squeezed = DuplicateToolHAsTask::model()->findAll($criteria); 
            
            $tasks = [];
            foreach( $squeezed as $squeeze){
                $task[] = $squeeze['task_id'];
            }
            
            return $tasks;
        }
        
        /**
         * This is the function that retrieves the original value of the squeezed task
         */
        public function retrieveTaskOriginalSqueezedValue($tool_id,$task){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='tool_id=:toolid and task_id=:taskid';
            $criteria->params = array(':toolid'=>$tool_id,':taskid'=>$task);
            $original = DuplicateToolHasTask::model()->find($criteria); 
            
            return $original['original_squeezed_share'];
            
        }
        
        /**
         * This is the function that assigns original value as the percentage share
         */
        public function assignTaskPercentageShare($original_value,$tool_id,$task_id){
            $cmd =Yii::app()->db->createCommand(); 
            $result = $cmd->update('duplicate_tool_has_task',
                                    array('percentage_share'=>$original_value,'update_time'=>new CDbExpression('NOW()'),
                                    'update_user_id'=>Yii::app()->user->id),
					 "tool_id = $tool_id and task_id = $task_id"
                                     );
            if($result>0){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that retrieves the domain id of a tool given the tool id
         */
        public function retrieveTheIdOfTheDomainThatOwnsThisTool($tool_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $domain = Resources::model()->find($criteria); 
            
            return $domain['domain_id'];
        }
        
        
        /**
         * This is the function that determines if a domain permits the removal of task from a their tool
         */
        public function isPermittedToRemoveTaskFromToolByThisDomain($domainid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $permit = DomainPolicy::model()->find($criteria); 
                          
            if($permit['allow_task_removal_from_duplicate_reconstructable_tools'] == 1){
                return true;
                
            }else{
                return false;
                
            }
        }
        
        /**
         * This is the function that permits the addition of task to duplicate reconstructable tools
         */
        public function isPermittedToAddTaskToToolByThisDomain($domainid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $permit = DomainPolicy::model()->find($criteria); 
                          
            if($permit['allow_task_addition_to_duplicate_reconstructable_tools'] == 1){
                return true;
                
            }else{
                return false;
                
            }
            
        }
        
        /**
         * This is the function that allows a task to be added to a duplicated tool
         */
        public function actionAddNewTaskToDuplicatedTool(){
           
           $task_id = $_POST['task'];
           $tool_id = $_POST['id'];
            if(isset($_POST['respect_task_percentage_share'])){
                $respect_task_percentage_share = $_POST['respect_task_percentage_share'];
            }else{
                $respect_task_percentage_share = 0;
            }
            if(isset($_POST['respect_share_but_could_squeeze_in'])){
               $respect_share_but_could_squeeze_in = $_POST['respect_share_but_could_squeeze_in'];  
            }else{
                $respect_share_but_could_squeeze_in = 0;
            }
            
            
            //get the domain of the tool owner
            $domainid = $this->retrieveTheIdOfTheDomainThatOwnsThisTool($tool_id);
            //get the domain of the tool consumer 
            $userid = Yii::app()->user->id;
            $consumer_domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->isPermittedToAddTaskToToolByThisDomain($domainid)){
                if($this->noOccurrenceOfThisTaskInThisTool($tool_id,$task_id)){
                   if($this->isOriginatingToolDomainDuplicateToolPolicyApplicable($domainid)){
                       $percentage_share = $this->determineTheCorrectPercentageShareForThisToolPerThisDomain($domainid);
                       if($this->isThereSpaceInThisTool($task_id,$tool_id,$percentage_share,$domainid)){
                           if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                                $result = $cmd->insert('duplicate_tool_has_task',
                                  array('tool_id'=>$tool_id,
                                    'task_id'=>$task_id,
                                    'percentage_share'=>$percentage_share,
                                    'respect_task_percentage_share'=>$respect_task_percentage_share,
                                    'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                                    'create_time'=>new CDbExpression('NOW()'),
                                    'create_user_id'=>$userid
                               
		
                            )
			
                        );
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully added to the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not added to the file',
                       )); 
                    } 
                               
                           }else{
                              $msg = 'Space Constraints: Remove some document from this file if you must add this document to the file';
                              header('Content-Type: application/json');
                              echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                              ); 
                               
                           }
                           
                           
                  }elseif(isset($_POST['respect_share_but_could_squeeze_in'])&& $this->toolRemainingSpaceValue($tool_id,$task_id) > 0){
                      if($percentage_share > $this->toolRemainingSpaceValue($tool_id,$task_id)){
                          $original_percentage_share = $percentage_share;
                          $percentage_share = $this->toolRemainingSpaceValue($tool_id,$task_id);
                          if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                                $result = $cmd->insert('duplicate_tool_has_task',
                                  array('tool_id'=>$tool_id,
                                    'task_id'=>$task_id,
                                    'percentage_share'=>$percentage_share,
                                    'respect_task_percentage_share'=>$respect_task_percentage_share,
                                    'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                                    'original_squeezed_share'=>$original_percentage_share,  
                                    'create_time'=>new CDbExpression('NOW()'),
                                    'create_user_id'=>$userid
                               
		
                            )
			
                        );
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully added to the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not added to the file',
                       )); 
                    } 
                               
                           }else{
                              $msg = 'Space Constraints: Remove some document from this file if you must add this document to the file';
                              header('Content-Type: application/json');
                              echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                              ); 
                               
                           }
                      }
                      
                      
                  }else{
                      $msg = 'Space Constraints: Remove some document from this file if you must add this slot to the file';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }//end of if there is space conditional statement
                       
                           
                      
                   }else{
                      $percentage_share = $this->determineTheCorrectPercentageShareForThisToolPerThisDomain($consumer_domainid);
                      if($this->isThereSpaceInThisTool($task_id,$tool_id,$percentage_share,$consumer_domainid)){
                          if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                           $result = $cmd->insert('duplicate_tool_has_task',
                           array('tool_id'=>$tool_id,
				'task_id'=>$task_id,
                                'percentage_share'=>$percentage_share,
                                'respect_task_percentage_share'=>$respect_task_percentage_share,
                               'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                               'create_time'=>new CDbExpression('NOW()'),
                               'create_user_id'=>$userid
                               
		
			)
			
		);
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully added to the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not added to the file',
                       )); 
                    } 
                              
                          }else{
                               $msg = 'Space Constraints: Remove some document from this file if you must add this document to the file';
                               header('Content-Type: application/json');
                               echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                              
                          }
                           
                  }elseif(isset($_POST['respect_share_but_could_squeeze_in'])&& $this->toolRemainingSpaceValue($tool_id,$task_id) > 0){
                      
                      if($percentage_share > $this->toolRemainingSpaceValue($tool_id,$task_id)){
                           $original_percentage_share = $percentage_share;
                          $percentage_share = $this->toolRemainingSpaceValue($tool_id,$task_id);
                          if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                                $result = $cmd->insert('duplicate_tool_has_task',
                                  array('tool_id'=>$tool_id,
                                    'task_id'=>$task_id,
                                    'percentage_share'=>$percentage_share,
                                    'respect_task_percentage_share'=>$respect_task_percentage_share,
                                    'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                                    'original_squeezed_share'=>$original_percentage_share,    
                                    'create_time'=>new CDbExpression('NOW()'),
                                    'create_user_id'=>$userid
                               
		
                            )
			
                        );
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully added to the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not added to the file',
                       )); 
                    } 
                               
                           }else{
                              $msg = 'Space Constraints: Remove some document from this file if you must add this documwnt to the file';
                              header('Content-Type: application/json');
                              echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                              ); 
                               
                           }
                      }
                  }else{
                      $msg = 'Space Constraints: Remove some document from this file if you must add this document to the file';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }     
                    
                           
                       
                   }//end of isOriginatingToolDomainDuplicateToolPolicyApplicable function if statement
                       
                    
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document already exist in the file',
                       ));
                    
                }//tool not already in the toolbox if statement
              }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'The owner of the file does not permit the addition of document to their file',
                       ));
                
                } 
                       
                 
        }
        
        /**
         * This is the function to edit duplicated tools information
         */
        public function actionEditDuplicatedToolInformation(){
            
            $task_id = $_POST['task_id'];
           $tool_id = $_POST['tool_id'];
            if(isset($_POST['respect_task_percentage_share'])){
                $respect_task_percentage_share = $_POST['respect_task_percentage_share'];
            }else{
                $respect_task_percentage_share = 0;
            }
            if(isset($_POST['respect_share_but_could_squeeze_in'])){
               $respect_share_but_could_squeeze_in = $_POST['respect_share_but_could_squeeze_in'];  
            }else{
                $respect_share_but_could_squeeze_in = 0;
            }
            if(isset($_POST['original_squeezed_share'])){
               $original_squeezed_share = $_POST['original_squeezed_share'];  
            }else{
                $original_squeezed_share = 0;
            }
            
            
            //get the domain of the tool owner
            $domainid = $this->retrieveTheIdOfTheDomainThatOwnsThisTool($tool_id);
            //get the domain of the tool consumer 
            $userid = Yii::app()->user->id;
            $consumer_domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->isPermittedToAddTaskToToolByThisDomain($domainid)){
               // if($this->noOccurrenceOfThisTaskInThisTool($tool_id,$task_id)){
                   if($this->isOriginatingToolDomainDuplicateToolPolicyApplicable($domainid)){
                       $percentage_share = $this->determineTheCorrectPercentageShareForThisToolPerThisDomain($domainid);
                       if($this->isThereSpaceInThisTool($task_id,$tool_id,$percentage_share,$domainid)){
                           if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                                $result = $cmd->update('duplicate_tool_has_task',
                                  array('percentage_share'=>$percentage_share,
                                     'respect_task_percentage_share'=>$respect_task_percentage_share,
                                     'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                                      'original_squeezed_share'=>$original_squeezed_share,
                                     'update_time'=>new CDbExpression('NOW()'),
                                     'update_user_id'=>$userid
                               
		
			),
                         "task_id = $task_id and tool_id = $tool_id"           
			
                        );
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully updated in the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not updated in the file',
                       )); 
                    } 
                               
                           }else{
                              $msg = 'Space Constraints: Remove some document from this file if you must increase the share size of the document in the file';
                              header('Content-Type: application/json');
                              echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                              ); 
                               
                           }
                           
                           
                  }elseif(isset($_POST['respect_share_but_could_squeeze_in'])&& $this->toolRemainingSpaceValue($tool_id,$task_id) > 0){
                      if($percentage_share > $this->toolRemainingSpaceValue($tool_id,$task_id)){
                          $original_percentage_share = $percentage_share;
                          $percentage_share = $this->toolRemainingSpaceValue($tool_id,$task_id);
                          if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                                $result = $cmd->update('duplicate_tool_has_task',
                                  array('percentage_share'=>$percentage_share,
                                    'respect_task_percentage_share'=>$respect_task_percentage_share,
                                    'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                                    'original_squeezed_share'=>$original_squeezed_share,  
                                    'update_time'=>new CDbExpression('NOW()'),
                                    'update_user_id'=>$userid
                               
		
			),
                         "task_id = $task_id and tool_id = $tool_id"           
			
                        );
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This docuent is successfully updated in the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not updated in the file',
                       )); 
                    } 
                               
                           }else{
                              $msg = 'Space Constraints: Remove some document from this file if you must increase the share size of the document in the file';
                              header('Content-Type: application/json');
                              echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                              ); 
                               
                           }
                      }
                      
                      
                  }else{
                      $msg = 'Space Constraints: Remove some document from this file if you must increase the share size of the document in the file';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }//end of if there is space conditional statement
                       
                           
                      
                   }else{
                      $percentage_share = $this->determineTheCorrectPercentageShareForThisToolPerThisDomain($consumer_domainid);
                      if($this->isThereSpaceInThisTool($task_id,$tool_id,$percentage_share,$consumer_domainid)){
                          if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                           $result = $cmd->update('duplicate_tool_has_task',
                           array('percentage_share'=>$percentage_share,
                                'respect_task_percentage_share'=>$respect_task_percentage_share,
                               'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                               'original_squeezed_share'=>$original_squeezed_share,
                               'update_time'=>new CDbExpression('NOW()'),
                               'update_user_id'=>$userid
                               
		
			),
                         "task_id = $task_id and tool_id = $tool_id"           
			
		);
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully updated in the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not updated in the file',
                       )); 
                    } 
                              
                          }else{
                               $msg = 'Space Constraints:Remove some document from this file if you must increase the share size of the document in the file';
                               header('Content-Type: application/json');
                               echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                              
                          }
                           
                  }elseif(isset($_POST['respect_share_but_could_squeeze_in'])&& $this->toolRemainingSpaceValue($tool_id,$task_id) > 0){
                      
                      if($percentage_share > $this->toolRemainingSpaceValue($tool_id,$task_id)){
                          $percentage_share = $this->toolRemainingSpaceValue($tool_id,$task_id);
                          if($this->isTaskShareValueAcceptable($percentage_share,$tool_id,$task_id)){
                                $cmd =Yii::app()->db->createCommand();
                                $result = $cmd->update('duplicate_tool_has_task',
                                  array('percentage_share'=>$percentage_share,
                                'respect_task_percentage_share'=>$respect_task_percentage_share,
                               'respect_share_but_could_squeeze_in'=>$respect_share_but_could_squeeze_in,
                               'original_squeezed_share'=>$original_squeezed_share,       
                               'update_time'=>new CDbExpression('NOW()'),
                               'update_user_id'=>$userid
                               
		
			),
                         "task_id = $task_id and tool_id = $tool_id"           
			
                        );
                    if($result > 0){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>'This document is successfully updated in the file',
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This document was not updated in the file',
                       )); 
                    } 
                               
                           }else{
                              $msg = 'Space Constraints:Remove some document from this file if you must increase the share size of the document in the file';
                              header('Content-Type: application/json');
                              echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                              ); 
                               
                           }
                      }
                  }else{
                      $msg = 'Space Constraints: Remove some document from this file if you must increase the share size of the document in the file';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }     
                    
                           
                       
                   }//end of isOriginatingToolDomainDuplicateToolPolicyApplicable function if statement
                       
                    
            /**    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'This task already exist in the tool',
                       ));
                    
                }//tool not already in the toolbox if statement
             * 
             */
              }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>'The owner of the file does not permit the addition of document to their file',
                       ));
                
                } 
            
            
        }
        
        
        /**
         * This is the function that determines if a domain policy will be applicable on tool reconstruction
         */
        public function isOriginatingToolDomainDuplicateToolPolicyApplicable($domainid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $permit = DomainPolicy::model()->find($criteria); 
                          
            if($permit['duplicate_tools_within_percentage_share_policy'] == 1){
                return true;
                
            }else{
                return false;
                 
            }
            
        }
        
        /**
         * This is the function that determines if a task is assignable to tool within the applicable domain policies
         */
        public function determineTheCorrectPercentageShareForThisToolPerThisDomain($domainid){
            
            if(isset($_POST['percentage_share'])){
                    if($this->isSpecialMinimumTaskShareSet($domainid)){
                        if($this->isValueLessThanTheMinSpecialPercentageShareForThisDomain($_POST['percentage_share'], $domainid)){
                            $percentage_share = $this->determineTheSpecialTaskMinimumShareValue($domainid);
                        }else{
                            $percentage_share = $_POST['percentage_share'];
                        }
                        
                    }else{
                        //verify if the given value is less than the domain set min share percentage
                        if($this->isValueLessThanDomainTaskMinPercentageShare($_POST['percentage_share'], $domainid)){
                            $percentage_share = $this->determineTaskMinShareForADomain($domainid);
                        }else{
                            $percentage_share = $_POST['percentage_share'];
                        }
                    }
                    
                }else{
                   $percentage_share = $this->determineTaskMinShareForADomain($domainid);
                }
            
            return $percentage_share;
        }
        
         /**
         * This is the function that obtains the value of the special task min share
         */
        public function determineTheSpecialTaskMinimumShareValue($domainid){
            
              //retreive the set domain special task minimum share
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_min_share = DomainPolicy::model()->find($criteria); 
            
            return $special_min_share['special_min_task_share_in_tool'];
            
        }
        
        /**
         * This is the function that determines the minimum task percentage share for a domain
         */
        public function determineTaskMinShareForADomain($domainid){
            
             //retreive the set domain task minimum share
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $min_share = DomainPolicy::model()->find($criteria); 
            
            return $min_share['min_task_share_in_tool'];
            
            
            
        }
        
        /**
         * This is the funcrion that determines if  the special min task percentage share is set
         */
        public function isSpecialMinimumTaskShareSet($domainid){
            
              //determine if the special min tasl share is set
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_min_share = DomainPolicy::model()->find($criteria); 
            
            if($special_min_share['special_min_task_share_in_tool'] >0){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that will determine if the provided value is less than the domain's task minimum share
         */
        public function isValueLessThanDomainTaskMinPercentageShare($value, $domainid){
            
            if($value < $this->determineTaskMinShareForADomain($domainid)){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that determines if a value is less than the special min percentage task share in that domain
         */
        public function isValueLessThanTheMinSpecialPercentageShareForThisDomain($value, $domainid){
            if($value < $this->determineTheSpecialTaskMinimumShareValue($domainid)){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that determines if there is still space in a tool
         */
        public function isThereSpaceInThisTool($task_id,$tool_id, $task_share_value,$domainid){
            
            if($this->isSpecialMinimumTaskShareSet($domainid)){
                if($task_id === null){
                   if($this->determineTheSpecialTaskMinimumShareValue($domainid) <= $this->toolRemainingSpaceValue($tool_id, $task_id)){
                    return true;
                }else{
                    return false;
                } 
                }else{
                    if($this->isTaskShareValueTheSameAsThisExistingOne($task_id,$task_share_value)){
                   
                        return true;
                        
                    }else{
                        
                        if($this->isNewTaskPercentageShareLowerThanTheExistingOne($task_share_value,$task_id)){
                          return true;
                                     
                        }else{
                            if($this->isTaskShareValueAcceptable($task_share_value, $tool_id,$task_id)){
                                return true;
                                
                                
                    
                            }else{
                                return false;
                            }
                        }
                    }
                }
                
            }else{
               if($task_id === null){
                  if($this->determineTaskMinShareForADomain($domainid) <= $this->toolRemainingSpaceValue($tool_id,$task_id)){
                    return true;
                    
                }else{
                    return false;
                } 
               }else{
                   if($this->isTaskShareValueTheSameAsThisExistingOne($task_id,$task_share_value)){
                        return true;
                    }else{
                        
                        if($this->isNewTaskPercentageShareLowerThanTheExistingOne($task_share_value,$task_id)){
                            return true;
                            
                        }else{
                            if($this->isTaskShareValueAcceptable($task_share_value, $tool_id,$task_id)){
                                return true;
                            }else{
                                return false;
                            }
                        }
                    }
               }
                
            }
            
        }
        
        
        /**
         * This is the function that determines the remaining tool space 
         */
        public function toolRemainingSpaceValue($tool_id,$id){
            
            $remaining_space = 0.00;
            $total_space = 0.00;
            //spool all the tasks in this tool
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='tool_id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $tasks = DuplicateToolHasTask::model()->findAll($criteria); 
                    
            foreach($tasks as $task){
                $total_space = $total_space + (double)$task['percentage_share'];
            }
           if($id === null){
                $remaining_space = 100.00 - $total_space;
            
                return $remaining_space;
           }else{
               //return $task_share_value;
                 $exemp_total = 0.00;
                  $criteria1 = new CDbCriteria();
                  $criteria1->select = '*';
                  $criteria1->condition='tool_id=:id and task_id!=:taskid';
                  $criteria1->params = array(':id'=>$tool_id,':taskid'=>$id);
                  $exemp_task = DuplicateToolHasTask::model()->findAll($criteria1);
                  
                  foreach($exemp_task as $value){
                      $exemp_total = $exemp_total + $value['percentage_share'];
                  }
                  $remaining_space = 100.00 - $exemp_total;
                  
                  return $remaining_space;
           } 
           
           
        }
        
        
        /**
         * This is the function that determines if a task could be added to a tool base on its share value
         */
        public function isTaskShareValueAcceptable($percentage_share, $tool_id,$id){
            
            if($percentage_share <= $this->toolRemainingSpaceValue($tool_id,$id)){
                 return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that determines if a stated task share value had not changed
         */
        public function isTaskShareValueTheSameAsThisExistingOne($id,$task_share_value){
            if($task_share_value == (double)$this->determineThisTaskPercentageShareValue($id)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that retrieves the task percentage share in a tool
         */
        public function determineThisTaskPercentageShareValue($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $task = Resources::model()->find($criteria); 
            
            return $task['percentage_share'];
        }
        
        /**
         * This is the function that determines if the new task share is lower that the existing one
         */
        public function isNewTaskPercentageShareLowerThanTheExistingOne($task_share_value, $id){
            
            if($task_share_value <= (double)$this->determineThisTaskPercentageShareValue($id)){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
	
        /**
         * get the preferred currency code
         */
        public function getThisCurrencyCode($preferred_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$preferred_currency);
            $currency = Currencies::model()->find($criteria); 
            
            return $currency['currency_code'];
        }
        
        
        /**
         * This is the function that gets the resource type name
         */
        public function getTheResourcetypeName($resourcetype_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';  
            $criteria->params = array(':id'=>$resourcetype_id);
            $type = ResourceType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        
        /**
         * This is the function that gets the platform base currency
         */
        public function getThePlatformBaseCurrency(){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                    // $criteria->condition='country_id=:id';
                   //  $criteria->params = array(':id'=>$country_id);
                     $platform= PlatformSettings::model()->find($criteria);
                     
                     return $platform['platform_default_currency_id'];
            
        }
        
        /**
         * This is the function that gets the exchange rate of a currency
         */
        public function getThePreferredCurrencyExchangeRate($currency,$base_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='base_currency_id=:baseid and currency_id=:currencyid';
            $criteria->params = array(':baseid'=>$base_currency,':currencyid'=>$currency);
            $currency= CurrencyExchange::model()->find($criteria);
            
            return $currency['exchange_rate'];
        }
        
        /**
         * This is the function that gets the preferred currency for a domain
         */
        public function getThisDomainPreferredCurrency($domain_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='domain_id=:id and status="active"';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= DomainPolicy::model()->find($criteria);
                     
                     return $domain['domain_currency_preference'];
            
            
        }
        
        
        
        /**
         * This is the function that gets the tool or task price from the original resource
         */
        public function getTheOriginalToolOrTaskPrice($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $resource = Resources::model()->find($criteria); 
            
            return $resource['price'];
            
        }
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Duplications the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Duplications::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Duplications $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='duplications-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
