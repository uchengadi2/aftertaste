<?php

class FeedbackTemplateController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','retrivefeedbacksingletextoptions','retrivefeedbackmultipletextoptions','retrivefeedbacksinglenumericoptions',
                                    'retrivefeedbackmultiplenumericoptions','retrivesecondfeedbackmultipletextoptions','retrivesecondfeedbacksingletextoptions',
                                    'retrivethirdfeedbacksingletextoptions','retrivefourthfeedbacksingletextoptions','retrivefifthfeedbacksingletextoptions',
                                    'retrivesecondfeedbackmultipletextoptions','retrivethirdfeedbackmultipletextoptions','retrivefourthfeedbackmultipletextoptions',
                                    'retrivefifththfeedbackmultipletextoptions','retrivesecondfeedbacksinglenumericoptions','retrivethirdfeedbacksinglenumericoptions',
                                    'retrivefourthfeedbacksinglenumericoptions','retrivefifthfeedbacksinglenumericoptions','retrivesecondfeedbackmultiplenumericoptions',
                                    'retrivethirdfeedbackmultiplenumericoptions','retrivefourthfeedbackmultiplenumericoptions','retrivefifthfeedbackmultiplenumericoptions',
                                    'listAllQuestionsInATemplate','getThisQuestionInTheTemplate','listalltemplatesforaunit','listAllTemplates','retrievethistemplateissue',
                                    'listalltemplatequestionswithouttheprimaryquestion','retrievetheprojectidofthiscode','listallReviewIssueForThisCode','retrieveallresponsestoaquestion'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','creatinganewservicecodefeedbacktemplatedesign','listAllTemplatesForACode','enabletemplateforussd',
                                    'activatethisfeedback','deletefeedbacktemplate','updatefeedbacktemplate','listAllFeedbackResponsesFromAFeedbackCode',
                                    'listAllTemplates','listalltemplatesforaunit','retrievethistemplateissue','listalltemplatesinaproject','listallquestionsinatemplate',
                                    'retrievethistemplatequestionandresponse'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that creates a new feedback template design
         */
        public function actioncreatinganewservicecodefeedbacktemplatedesign(){
            
            $model = new FeedbackTemplate;
            
            if(isset($_REQUEST['is_first_feedback_included'])){
                $model->is_first_feedback_included = $_REQUEST['is_first_feedback_included'];
                $model->first_feedback_type = $_REQUEST['first_feedback_type'];
                $model->first_feedback_question = $_REQUEST['first_feedback_question'];
                $model->first_feedback_name = $_REQUEST['first_feedback_name'];
                $model->first_feedback_purpose = $_REQUEST['first_feedback_purpose'];
                $model->first_feedback_classification = $_REQUEST['first_feedback_classification'];
                
              if($_REQUEST['first_feedback_type'] == 'single_option'){
                   $model->first_feedback_single_option = trim($_REQUEST['first_question_options']);
                   $first_question_number = 1;
                  }else if($_REQUEST['first_feedback_type'] == 'multiple_option'){
                   $model->first_feedback_multiple_option = trim($_REQUEST['first_question_options']);
                   $first_question_number = 1;
                }else if($_REQUEST['first_feedback_type'] == 'single_option_number'){
                    $model->first_feedback_single_option_number =trim($_REQUEST['first_question_options']);
                    $first_question_number = 1;
                }else if($_REQUEST['first_feedback_type'] == 'multiple_option_number'){
                     $model->first_feedback_multiple_option_number=trim($_REQUEST['first_question_options']);
                     $first_question_number = 1;
                }
                $first_question_number = 1;
                
            }else{
                $model->is_first_feedback_included = 0;
                $model->first_feedback_type = NULL;
                $model->first_feedback_question = NULL;
                $model->first_feedback_name = NULL;
                $model->first_feedback_purpose = NULL;
                $model->first_feedback_classification = "generic";
                $first_question_number = 0;
            }
             if(isset($_REQUEST['is_second_feedback_included'])){
                $model->is_second_feedback_included = $_REQUEST['is_second_feedback_included'];
                $model->second_feedback_type = $_REQUEST['second_feedback_type'];
                $model->second_feedback_question = $_REQUEST['second_feedback_question'];
                $model->second_feedback_name = $_REQUEST['second_feedback_name'];
                $model->second_feedback_purpose = $_REQUEST['second_feedback_purpose'];
                $model->second_feedback_classification = $_REQUEST['second_feedback_classification'];
                
              if($_REQUEST['second_feedback_type'] == 'single_option'){
                   $model->second_feedback_single_option = trim($_REQUEST['second_question_options']);
                    $second_question_number = 2;
                }else if($_REQUEST['second_feedback_type'] == 'multiple_option'){
                   $model->second_feedback_multiple_option = trim($_REQUEST['second_question_options']);
                    $second_question_number = 2;
                }else if($_REQUEST['second_feedback_type'] == 'single_option_number'){
                    $model->second_feedback_single_option_number=trim($_REQUEST['second_question_options']);
                     $second_question_number = 2;
                }else if($_REQUEST['second_feedback_type'] == 'multiple_option_number'){
                   $model->second_feedback_multiple_option_number = trim($_REQUEST['second_question_options']);
                    $second_question_number = 2;
                }
               $second_question_number = 2;
                
            }else{
                $model->is_second_feedback_included = 0;
                $model->second_feedback_type = NULL;
                $model->second_feedback_question = NULL;
                $model->second_feedback_name = NULL;
                $model->second_feedback_purpose = NULL;
                $model->second_feedback_classification="generic";
                $second_question_number = 0;
            }
            
            
            
            if(isset($_REQUEST['is_third_feedback_included'])){
                $model->is_third_feedback_included = $_REQUEST['is_third_feedback_included'];
                $model->third_feedback_type = $_REQUEST['third_feedback_type'];
                $model->third_feedback_question = $_REQUEST['third_feedback_question'];
                $model->third_feedback_name = $_REQUEST['third_feedback_name'];
                $model->third_feedback_purpose = $_REQUEST['third_feedback_purpose'];
                $model->third_feedback_classification = $_REQUEST['third_feedback_classification'];
                
              if($_REQUEST['third_feedback_type'] == 'single_option'){
                   $model->third_feedback_single_option = trim($_REQUEST['third_question_options']);
                    $third_question_number = 3;
                }else if($_REQUEST['third_feedback_type'] == 'multiple_option'){
                    $model->third_feedback_multiple_option = trim($_REQUEST['third_question_options']);
                    $third_question_number = 3;
                }else if($_REQUEST['third_feedback_type'] == 'single_option_number'){
                     $model->third_feedback_single_option_number = trim($_REQUEST['third_question_options']);
                     $third_question_number = 3;
                }else if($_REQUEST['third_feedback_type'] == 'multiple_option_number'){
                     $model->third_feedback_multiple_option_number = trim($_REQUEST['third_question_options']);
                     $third_question_number = 3;
                }
                $third_question_number = 3;
            }else{
                $model->is_third_feedback_included = 0;
                $model->third_feedback_type = NULL;
                $model->third_feedback_question = NULL;
                $model->third_feedback_name = NULL;
                $model->third_feedback_purpose = NULL;
                $model->third_feedback_classification = "generic";
                $third_question_number = 0;
            }
            
             if(isset($_REQUEST['is_fourth_feedback_included'])){
                $model->is_fourth_feedback_included = $_REQUEST['is_fourth_feedback_included'];
                $model->fourth_feedback_type = $_REQUEST['fourth_feedback_type'];
                $model->fourth_feedback_question = $_REQUEST['fourth_feedback_question'];
                $model->fourth_feedback_name = $_REQUEST['fourth_feedback_name'];
                $model->fourth_feedback_purpose = $_REQUEST['fourth_feedback_purpose'];
                $model->fourth_feedback_classification = $_REQUEST['fourth_feedback_classification'];
                
              if($_REQUEST['fourth_feedback_type'] == 'single_option'){
                   $model->fourth_feedback_single_option = trim($_REQUEST['fourth_question_options']);
                   $fourth_question_number = 4;
                }else if($_REQUEST['fourth_feedback_type'] == 'multiple_option'){
                    $model->fourth_feedback_multiple_option = trim($_REQUEST['fourth_question_options']);
                    $fourth_question_number = 4;
                }else if($_REQUEST['fourth_feedback_type'] == 'single_option_number'){
                     $model->fourth_feedback_single_option_number = trim($_REQUEST['fourth_question_options']);
                     $fourth_question_number = 4;
                }else if($_REQUEST['fourth_feedback_type'] == 'multiple_option_number'){
                    $model->fourth_feedback_multiple_option_number = trim($_REQUEST['fourth_question_options']);
                    $fourth_question_number = 4;
                }
              $fourth_question_number = 4;
                
            }else{
                $model->is_fourth_feedback_included = 0;
                $model->fourth_feedback_type = NULL;
                $model->fourth_feedback_question = NULL;
                $model->fourth_feedback_name = NULL;
                $model->fourth_feedback_purpose = NULL;
                $model->fourth_feedback_classification="generic";
                $fourth_question_number = 0;
            }
            
            if(isset($_REQUEST['is_fifth_feedback_included'])){
                $model->is_fifth_feedback_included = $_REQUEST['is_fifth_feedback_included'];
                $model->fifth_feedback_type = $_REQUEST['fifth_feedback_type'];
                $model->fifth_feedback_question = $_REQUEST['fifth_feedback_question'];
                $model->fifth_feedback_name = $_REQUEST['fifth_feedback_name'];
                $model->fifth_feedback_purpose = $_REQUEST['fifth_feedback_purpose'];
                $model->fifth_feedback_classification = $_REQUEST['fifth_feedback_classification'];
                
               if($_REQUEST['fifth_feedback_type'] == 'single_option'){
                   $model->fifth_feedback_single_option = trim($_REQUEST['fifth_question_options']);
                   $fifth_question_number = 5;
                }else if($_REQUEST['fifth_feedback_type'] == 'multiple_option'){
                     $model->fifth_feedback_multiple_option = trim($_REQUEST['fifth_question_options']);
                     $fifth_question_number = 5;
                }else if($_REQUEST['fifth_feedback_type'] == 'single_option_number'){
                     $model->fifth_feedback_single_option_number = trim($_REQUEST['fifth_question_options']);
                     $fifth_question_number = 5;
                }else if($_REQUEST['fifth_feedback_type'] == 'multiple_option_number'){
                    $model->fifth_feedback_multiple_option_number = trim($_REQUEST['fifth_question_options']);
                    $fifth_question_number = 5;
                }
                
                $fifth_question_number = 5;
            }else{
                $model->is_fifth_feedback_included = 0;
                $model->fifth_feedback_type = NULL;
                $model->fifth_feedback_question = NULL;
                $model->fifth_feedback_name = NULL;
                $model->fifth_feedback_purpose = NULL;
                $model->fifth_feedback_classification="generic";
                $fifth_question_number = 0;
            }
            
            
            //other model fields
            $model->code_id = $_REQUEST['code_id'];
            //$model->status = $_REQUEST['status'];
            $model->status = "inactive";
            $model->template_name = $_REQUEST['template_name'];
            $model->template_label = $_REQUEST['template_label'];
            $model->maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
            $model->is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
            if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                $model->is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
            }else{
                $model->is_multiple_feedback_responses_allowed = 0;
            }
            if($model->isThisTemplateNameAlreadyUsed($model->code_id,$model->template_name)== false){
                
                if($model->save()){
                    //registering the feedback options if any
                      if($model->isRegisteringTheOptionsASuccess($model,$first_question_number,$second_question_number,$third_question_number,$fourth_question_number,$fifth_question_number)){
                         header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"This feedback template is created succesfully",
                          
                           
                        ));
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Some or all the feedback options could not be registered. Please check your data and try again",
                             
                                
                        ));  
                    }
                        
                  
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be created. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"This template name had already been used. Please use a different template name"
                        )); 
                
            }
            
        }
        
        
        
        
       
        
        /**
         * This is the function that list all templates for a code
         */
        public function actionlistAllTemplatesForACode(){
            $code_id = $_REQUEST['code_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $templates = FeedbackTemplate::model()->findAll($criteria);
            
             if($templates===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "template" =>$templates,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
        /**
         * This is the function that updates a template
         */
        public function actionupdatefeedbacktemplate(){
            
             $_id = $_POST['id'];
            $model= FeedbackTemplate::model()->findByPk($_id);
            
            if(isset($_REQUEST['is_first_feedback_included'])){
                $model->is_first_feedback_included = $_REQUEST['is_first_feedback_included'];
                $model->first_feedback_type = $_REQUEST['first_feedback_type'];
                $model->first_feedback_question = $_REQUEST['first_feedback_question'];
                $model->first_feedback_name = $_REQUEST['first_feedback_name'];
                $model->first_feedback_purpose = $_REQUEST['first_feedback_purpose'];
                $model->first_feedback_classification = $_REQUEST['first_feedback_classification'];
                
                 if($_REQUEST['first_feedback_type'] == 'single_option'){
                    $model->first_feedback_single_option =trim($_REQUEST['first_question_options']);
                }else if($_REQUEST['first_feedback_type'] == 'multiple_option'){
                    $model->first_feedback_multiple_option =trim($_REQUEST['first_question_options']);
                }else if($_REQUEST['first_feedback_type'] == 'single_option_number'){
                     $model->first_feedback_single_option_number =trim($_REQUEST['first_question_options']);
                }else if($_REQUEST['first_feedback_type'] == 'multiple_option_number'){
                     $model->first_feedback_multiple_option_number =trim($_REQUEST['first_question_options']);
                }
                $first_question_number = 1;
               
                
            }else{
                $model->is_first_feedback_included = 0;
                $model->first_feedback_type = NULL;
                $model->first_feedback_question = NULL;
                $model->first_feedback_name = NULL;
                $model->first_feedback_purpose = NULL;
                $model->first_feedback_classification ="generic";
                 $first_question_number = 0;
            }
             if(isset($_REQUEST['is_second_feedback_included'])){
                $model->is_second_feedback_included = $_REQUEST['is_second_feedback_included'];
                $model->second_feedback_type = $_REQUEST['second_feedback_type'];
                $model->second_feedback_question = $_REQUEST['second_feedback_question'];
                $model->second_feedback_name = $_REQUEST['second_feedback_name'];
                $model->second_feedback_purpose = $_REQUEST['second_feedback_purpose'];
                $model->second_feedback_classification = $_REQUEST['second_feedback_classification'];
                
                if($_REQUEST['second_feedback_type'] == 'single_option'){
                    $model->second_feedback_single_option =trim($_REQUEST['second_question_options']);
                }else if($_REQUEST['second_feedback_type'] == 'multiple_option'){
                    $model->second_feedback_multiple_option =trim($_REQUEST['second_question_options']);
                }else if($_REQUEST['second_feedback_type'] == 'single_option_number'){
                     $model->second_feedback_single_option_number =trim($_REQUEST['second_question_options']);
                }else if($_REQUEST['second_feedback_type'] == 'multiple_option_number'){
                     $model->second_feedback_multiple_option_number =trim($_REQUEST['second_question_options']);
                }
                $second_question_number = 2;
                
            }else{
                $model->is_second_feedback_included = 0;
                $model->second_feedback_type = NULL;
                $model->second_feedback_question = NULL;
                $model->second_feedback_name = NULL;
                $model->second_feedback_purpose = NULL;
                $model->second_feedback_classification ="generic";
                $second_question_number = 0;
            }
            
            
            
            if(isset($_REQUEST['is_third_feedback_included'])){
                $model->is_third_feedback_included = $_REQUEST['is_third_feedback_included'];
                $model->third_feedback_type = $_REQUEST['third_feedback_type'];
                $model->third_feedback_question = $_REQUEST['third_feedback_question'];
                $model->third_feedback_name = $_REQUEST['third_feedback_name'];
                $model->third_feedback_purpose = $_REQUEST['third_feedback_purpose'];
                $model->third_feedback_classification = $_REQUEST['third_feedback_classification'];
                
                 if($_REQUEST['third_feedback_type'] == 'single_option'){
                    $model->third_feedback_single_option =trim($_REQUEST['third_question_options']);
                }else if($_REQUEST['third_feedback_type'] == 'multiple_option'){
                    $model->third_feedback_multiple_option =trim($_REQUEST['third_question_options']);
                }else if($_REQUEST['third_feedback_type'] == 'single_option_number'){
                     $model->third_feedback_single_option_number =trim($_REQUEST['third_question_options']);
                }else if($_REQUEST['third_feedback_type'] == 'multiple_option_number'){
                     $model->third_feedback_multiple_option_number =trim($_REQUEST['third_question_options']);
                }
                $third_question_number = 3;
                
            }else{
                $model->is_third_feedback_included = 0;
                $model->third_feedback_type = NULL;
                $model->third_feedback_question = NULL;
                $model->third_feedback_name = NULL;
                $model->third_feedback_purpose = NULL;
                $model->third_feedback_classification ="generic";
                $third_question_number = 0;
            }
            
             if(isset($_REQUEST['is_fourth_feedback_included'])){
                $model->is_fourth_feedback_included = $_REQUEST['is_fourth_feedback_included'];
                $model->fourth_feedback_type = $_REQUEST['fourth_feedback_type'];
                $model->fourth_feedback_question = $_REQUEST['fourth_feedback_question'];
                $model->fourth_feedback_name = $_REQUEST['fourth_feedback_name'];
                $model->fourth_feedback_purpose = $_REQUEST['fourth_feedback_purpose'];
                $model->fourth_feedback_classification = $_REQUEST['fourth_feedback_classification'];
             
                
                if($_REQUEST['fourth_feedback_type'] == 'single_option'){
                    $model->fourth_feedback_single_option =trim($_REQUEST['fourth_question_options']);
                }else if($_REQUEST['fourth_feedback_type'] == 'multiple_option'){
                    $model->fourth_feedback_multiple_option =trim($_REQUEST['fourth_question_options']);
                }else if($_REQUEST['fourth_feedback_type'] == 'single_option_number'){
                     $model->fourth_feedback_single_option_number =trim($_REQUEST['fourth_question_options']);
                }else if($_REQUEST['fourth_feedback_type'] == 'multiple_option_number'){
                     $model->fourth_feedback_multiple_option_number =trim($_REQUEST['fourth_question_options']);
                }
                $fourth_question_number = 4;
                
            }else{
                $model->is_fourth_feedback_included = 0;
                $model->fourth_feedback_type = NULL;
                $model->fourth_feedback_question = NULL;
                $model->fourth_feedback_name = NULL;
                $model->fourth_feedback_purpose = NULL;
                $model->fourth_feedback_classification ="generic";
                $fourth_question_number = 0;
            }
            
            if(isset($_REQUEST['is_fifth_feedback_included'])){
                $model->is_fifth_feedback_included = $_REQUEST['is_fifth_feedback_included'];
                $model->fifth_feedback_type = $_REQUEST['fifth_feedback_type'];
                $model->fifth_feedback_question = $_REQUEST['fifth_feedback_question'];
                $model->fifth_feedback_name = $_REQUEST['fifth_feedback_name'];
                $model->fifth_feedback_purpose = $_REQUEST['fifth_feedback_purpose'];
                $model->fifth_feedback_classification = $_REQUEST['fifth_feedback_classification'];
                
                 if($_REQUEST['fifth_feedback_type'] == 'single_option'){
                    $model->fifth_feedback_single_option =trim($_REQUEST['fifth_question_options']);
                }else if($_REQUEST['fifth_feedback_type'] == 'multiple_option'){
                    $model->fifth_feedback_multiple_option =trim($_REQUEST['fifth_question_options']);
                }else if($_REQUEST['fifth_feedback_type'] == 'single_option_number'){
                     $model->fifth_feedback_single_option_number =trim($_REQUEST['fifth_question_options']);
                }else if($_REQUEST['fifth_feedback_type'] == 'multiple_option_number'){
                     $model->fifth_feedback_multiple_option_number =trim($_REQUEST['fifth_question_options']);
                }
                $fifth_question_number = 5;
                
            }else{
                $model->is_fifth_feedback_included = 0;
                $model->fifth_feedback_type = NULL;
                $model->fifth_feedback_question = NULL;
                $model->fifth_feedback_name = NULL;
                $model->fifth_feedback_purpose = NULL;
                $model->fifth_feedback_classification ="generic";
                $fifth_question_number = 0;
            }
            
            
            //other model fields
            $model->code_id = $_REQUEST['code_id'];
            //$model->status = $_REQUEST['status'];
            $model->template_name = $_REQUEST['template_name'];
            $model->template_label = $_REQUEST['template_label'];
            $model->maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
            $model->is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
            if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                $model->is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
            }else{
                $model->is_multiple_feedback_responses_allowed = 0;
            }
            
            //get the existing template name of this feedback templake
            $template_name = $model->getThisFeedbackTemplateName($_id);
            
         if($this->isThisFeedbackTemplateAlreadyWithReponses($_id)== false){
                     if($template_name ==$model->template_name){
              if($model->save()){
                   if($model->isUpdatingTheseOptionsRegisteringASuccess($model,$first_question_number,$second_question_number,$third_question_number,$fourth_question_number,$fifth_question_number)){
                          header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"This feedback template is updated succesfully"
                                                 
                           
                        ));
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Some or all the feedback options could not be registered. Please check your data and try again",
                             
                                
                        ));  
                    }
                
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be updated. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                
            }else{
               if($model->isThisTemplateNameAlreadyUsed($model->code_id,$model->template_name)== false){
                
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"This feedback template is updated succesfully"
                        ));
                
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be created. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                
            }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"This template name had already been used. Please use a different template name"
                        )); 
                
            }
         }
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"This template could not be updated as it had already started to recieve responses. It is advisable to create a new template instead"
                        ));
                
            }
            
           
                          
           
                
          
        }
        
        
        /**
         * This is the function that deletes feedback template
         */
        public function actiondeletefeedbacktemplate(){
            $_id = $_POST['id'];
            $model= FeedbackTemplate::model()->findByPk($_id);
            
            //get the template name
            $template_name = $model->getThisFeedbackTemplateName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$template_name' template was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
            
        }
        
        
        /**
         * This is the function that activates a feedback
         */
        public function actionactivatethisfeedback(){
             $_id = $_POST['id'];
             $code_id = $_POST['code_id'];
             $model= FeedbackTemplate::model()->findByPk($_id);
             
             //deactivate all templates by this code
             if($this->isAllTemplatesByThisCodeDeactivates($code_id)){
                 $model->status = "active";
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"This feedback template is activated"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be activated. There is possibly some data validation issue. Check your data and try again"
                        ));  
            }
                 
             }else{
                  header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be activated. Please contact service desk for assistance"
                        ));  
             }
       
        }
        
        
         /**
              * This is the function that deactivates all templates for a code
              */
             public function isAllTemplatesByThisCodeDeactivates($code_id){
                 $model = new FeedbackTemplate;     
                 $error_counter = 0;
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='code_id=:codeid';
                 $criteria->params = array(':codeid'=>$code_id);
                 $templates = FeedbackTemplate::model()->findAll($criteria);
                 
                 foreach($templates as $template){
                     if($model->isTheDeactivationOfThisTemplateASuccess($template['id']) == false){
                         $error_counter = $error_counter + 1;
                     }
                 }
                 if($error_counter == 0){
                     return true;
                 }else{
                     return false;
                 }
                 
             }
             
             
             /**
              * This is the function that enables a template for ussd
              */
             public function actionenabletemplateforussd(){
                 $_id = $_POST['id'];
                $code_id = $_POST['code_id'];
                $model= FeedbackTemplate::model()->findByPk($_id);
             
                //deactivate all templates by this code
                if($this->isAllTemplatesByThisCodeUssdDeactivates($code_id)){
                    $model->is_ussd_active = 1;
                    if($model->save()){
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                           "msg" =>"This feedback template is enabled for ussd"
                        ));
                
                
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be enabled for ussd. There is possibly some data validation issue. Check your data and try again"
                        ));  
                }
                 
                }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() != 0,
                           "msg" =>"Sorry this feedback template could not be enabled for ussd. Please contact service desk for assistance"
                        ));  
                }
             }
             
             
              /**
              * This is the function that deactivates all templates for a ussd
              */
             public function isAllTemplatesByThisCodeUssdDeactivates($code_id){
                 $model = new FeedbackTemplate;  
                 $error_counter = 0;
                 $criteria = new CDbCriteria();
                 $criteria->select = '*';
                 $criteria->condition='code_id=:codeid';
                 $criteria->params = array(':codeid'=>$code_id);
                 $templates = FeedbackTemplate::model()->findAll($criteria);
                 
                 foreach($templates as $template){
                    if($model->isTheDisablingOfThisUssdTemplateASuccess($template['id']) == false){
                         $error_counter = $error_counter + 1;
                     }
                 }
                 if($error_counter == 0){
                     return true;
                 }else{
                     return false;
                 }
                 
                 
             }
             
             
             /**
              * This is the function that determines if a feedback template has responses
              */
             public function isThisFeedbackTemplateAlreadyWithReponses($template_id){
                 $model = new FeedbacksTemplateResponse;
                 return $model->isThisFeedbackTemplateAlreadyWithReponses($template_id);
             }
             
             
             
       /**
         * This is the function that list all templates
         */
        public function actionlistAllTemplates(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $templates = FeedbackTemplate::model()->findAll($criteria);
            
             if($templates===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "template" =>$templates,
                                    
                    
                            ));
                       
                         }
            
        }
        
        
        
         /**
         * This is the function that retrieves all responses of a feedback code
         */
        public function actionlistAllFeedbackResponsesFromAFeedbackCode(){
            $code_id = $_REQUEST['code_id'];
            $target = [];
            
            //get the feedbakc template othis code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $templates = FeedbackTemplate::model()->findAll($criteria);
            
            foreach($templates as $template){
                 //get the feedbakc template othis code
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='template_id=:tempid';
                    $criteria->params = array(':tempid'=>$template['id']);
                    $feedbacks = FeedbacksTemplateResponse::model()->findAll($criteria);
                    foreach($feedbacks as $feedback){
                        $target[] = $feedback;
                    }
        
            }
       
            if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "feedback" =>$target
                                                                        
                    
                            ));
                       
                         }
        }
        
        
        
         /**
         * This is the function that list all templates for a unit
         */
        public function actionlistalltemplatesforaunit(){
            
           $enlistment_id = $_REQUEST['enliatment_id'];
            $targets = [];
         
            //list all templates for this enlistment
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:enlistid';
            $criteria->params = array(':enlistid'=>$enlistment_id);
            $codes= EnlistmentVerificationCode::model()->findAll($criteria);
            
            foreach($codes as $code){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='code_id=:codeid';
                $criteria->params = array(':codeid'=>$code['id']);
                $templates= FeedbackTemplate::model()->findAll($criteria);
                
                foreach($templates as $temp){
                    $targets[] = $temp;
                }
                
                
            }
           
            
                       
             if($codes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "templates" => $targets
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves a template issue
         */
        public function actionretrievethistemplateissue(){
            $model = new FeedbackTemplate;
            $template_id = $_REQUEST['template_id'];
            $issue_code = $_REQUEST['issue_code'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$template_id);
            $template= FeedbackTemplate::model()->find($criteria);
            
            //write a script to limit template to only analyzable issues. Also retrieve the issue types
            
            if($issue_code == 1){
                if($model->isIssueTypeAnalyzable($template['first_feedback_type'])){
                    $issue = $template['first_feedback_question'];
                    $issue_type = $template['first_feedback_type'];
                }else{
                    $issue="";
                    $issue_type = $template['first_feedback_type'];
                }
                
            }else if($issue_code == 2){
                 if($model->isIssueTypeAnalyzable($template['second_feedback_type'])){
                     $issue = $template['second_feedback_question'];
                     $issue_type = $template['second_feedback_type'];
                 }else{
                     $issue="";
                     $issue_type = $template['second_feedback_type'];
                 }
                
            }else if($issue_code == 3){
                if($model->isIssueTypeAnalyzable($template['third_feedback_type'])){
                    $issue = $template['third_feedback_question'];
                    $issue_type = $template['third_feedback_type'];
                }else{
                     $issue="";
                     $issue_type = $template['third_feedback_type'];
                }
                
            }else if($issue_code == 4){
                if($model->isIssueTypeAnalyzable($template['fourth_feedback_type'])){
                    $issue = $template['fourth_feedback_question'];
                    $issue_type = $template['fourth_feedback_type'];
                }else{
                     $issue="";
                     $issue_type = $template['fourth_feedback_type'];
                }
                
            }else if($issue_code == 5){
                if($model->isIssueTypeAnalyzable($template['fifth_feedback_type'])){
                    $issue = $template['fifth_feedback_question'];
                    $issue_type = $template['fifth_feedback_type'];
                }else{
                     $issue="";
                     $issue_type = $template['fifth_feedback_type'];
                }
                
            }else{
                $issue="";
                $issue_type ="";
            }
             if($issue_code===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "issue" => $issue,
                           "issue_type"=>$issue_type
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all single options of a feedback 
         */
        public function actionretrivefeedbacksingletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['first_feedback_single_option']);
            
            
            if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
        
        /**
         * This is the function that retrieves all single options of the second feedback 
         */
        public function actionretrivesecondfeedbacksingletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['second_feedback_single_option']);
            
            
            if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
         /**
         * This is the function that retrieves all single options of the third feedback 
         */
        public function actionretrivethirdfeedbacksingletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['third_feedback_single_option']);
            
            
            if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
        
         /**
         * This is the function that retrieves all single options of the fourth feedback 
         */
        public function actionretrivefourthfeedbacksingletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['fourth_feedback_single_option']);
            
            
            if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all single options of the fifth feedback 
         */
        public function actionretrivefifthfeedbacksingletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['fifth_feedback_single_option']);
            
            
            if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
      /**
         * This is the function that retrieves all multiple text options of a feedback 
         */
        public function actionretrivefeedbackmultipletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['first_feedback_multiple_option']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all multiple text options of a second feedback 
         */
        public function actionretrivesecondfeedbackmultipletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
            $feedback_options = [];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['second_feedback_multiple_option']);
            
           
                     
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
         /**
         * This is the function that retrieves all multiple text options of the third feedback 
         */
        public function actionretrivethirdfeedbackmultipletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['third_feedback_multiple_option']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
         /**
         * This is the function that retrieves all multiple text options of the fourth feedback 
         */
        public function actionretrivefourthfeedbackmultipletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['fourth_feedback_multiple_option']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
        
          /**
         * This is the function that retrieves all multiple text options of the fifth feedback 
         */
        public function actionretrivefifththfeedbackmultipletextoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheQuestionOptions($FeedbackOptions['fifth_feedback_multiple_option']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
            
        }
        
        
        
        
        
        
        
        /**
         * This is the function that retrieves all single numeric options of a feedback 
         */
        public function actionretrivefeedbacksinglenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['first_feedback_single_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves all single numeric options of the second feedback 
         */
        public function actionretrivesecondfeedbacksinglenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['second_feedback_single_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves all single numeric options of the third feedback 
         */
        public function actionretrivethirdfeedbacksinglenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['third_feedback_single_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves all single numeric options of the fourth feedback 
         */
        public function actionretrivefourthfeedbacksinglenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['fourth_feedback_single_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves all single numeric options of the fifth feedback 
         */
        public function actionretrivefifthfeedbacksinglenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['fifth_feedback_single_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves all multiple numeric options of a feedback 
         */
        public function actionretrivefeedbackmultiplenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['first_feedback_multiple_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves all multiple numeric options of the second feedback 
         */
        public function actionretrivesecondfeedbackmultiplenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['second_feedback_multiple_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves all multiple numeric options of the third feedback 
         */
        public function actionretrivethirdfeedbackmultiplenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['third_feedback_multiple_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves all multiple numeric options of the fourth feedback 
         */
        public function actionretrivefourthfeedbackmultiplenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['fourth_feedback_multiple_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        
        /**
         * This is the function that retrieves all multiple numeric options of the fifth feedback 
         */
        public function actionretrivefifthfeedbackmultiplenumericoptions(){
            $model = new FeedbackTemplate;
            $feedback_template_id = $_REQUEST['feedback_id'];
                       
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$feedback_template_id);
            $FeedbackOptions= FeedbackTemplate::model()->find($criteria);
            
            $options = $model->getTheArrayOfTheNumericQuestionOptions($FeedbackOptions['fifth_feedback_multiple_option_number']);
            
               if($FeedbackOptions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "option" => $options
                        
          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retreive the primary question in a template
         */
        public function actiongetThisQuestionInTheTemplate(){
            
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            
            
            if($question_number == 1){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, first_feedback_question as question';
                $criteria->condition='id=:tempid';
                $criteria->params = array(':tempid'=>$template_id);
                $option = FeedbackTemplate::model()->find($criteria); 
                
            }else if($question_number == 2){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, second_feedback_question  as question';
                $criteria->condition='id=:tempid';
                $criteria->params = array(':tempid'=>$template_id);
                $option = FeedbackTemplate::model()->find($criteria); 
                
            }else if($question_number == 3){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, third_feedback_question as question';
                $criteria->condition='id=:tempid';
                $criteria->params = array(':tempid'=>$template_id);
                $option = FeedbackTemplate::model()->find($criteria); 
                
            }else if($question_number == 4){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, fourth_feedback_question as question';
                $criteria->condition='id=:tempid';
                $criteria->params = array(':tempid'=>$template_id);
                $option = FeedbackTemplate::model()->find($criteria); 
                
            }else if($question_number == 5){
                $criteria = new CDbCriteria();
                $criteria->select = 'id, fifth_feedback_question as question';
                $criteria->condition='id=:tempid';
                $criteria->params = array(':tempid'=>$template_id);
                $option = FeedbackTemplate::model()->find($criteria); 
                
            }
            
            
            
            if($option===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "option"=>$option,
                                                            
                            ));
                       
                         }
            
            
        }
        
        
        
        /**
         * This is the function that retrieves the questions in a template except of the primary question for analysis
         */
        public function actionlistalltemplatequestionswithouttheprimaryquestion(){
            $model = new FeedbackTemplate;
            
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
          
            $data = [];
           if($question_number ==1){
               $data = $model->getAllTheQuestionsInATemplateWithoutQuestionOne($template_id);
           }else if($question_number == 2){
               $data = $model->getAllTheQuestionsInATemplateWithoutQuestionTwo($template_id);
           }else if($question_number == 3){
                $data = $model->getAllTheQuestionsInATemplateWithoutQuestionThree($template_id);
           }else if($question_number ==4){
               $data = $model->getAllTheQuestionsInATemplateWithoutQuestionFour($template_id);
           }else if($question_number == 5){
               $data = $model->getAllTheQuestionsInATemplateWithoutQuestionFive($template_id);
           }
           
                
                    
            if($data===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "question"=>$data,
                                                            
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that will list all templates for a project
         */
        public function actionlistalltemplatesinaproject(){
            
            $model = new FeedbackTemplate;
            
            $target = [];
            $project_id = $_REQUEST['project_id'];
            
            //get all the subproject from this project
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='enlistment_id=:listid';
            $criteria->params = array(':listid'=>$project_id);
            $subs = EnlistmentVerificationCode::model()->findAll($criteria); 
            
            foreach($subs as $sub){
                //list all template in this subproject
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='code_id=:tempid';
                $criteria->params = array(':tempid'=>$sub['id']);
                $templates = FeedbackTemplate::model()->findAll($criteria); 
                if($templates!=NULL){
                    foreach($templates as $temp){
                        $target[] = $temp;
                    }
                    
                }
                
            }
            
             if($subs===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "template"=>$target,
                                                            
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the fuction that list all questions in a template
         */
        public function actionlistallquestionsinatemplate(){
            $model = new FeedbackTemplate;
            
            $response_id = $_REQUEST['response_id'];
            $template_id = $_REQUEST['template_id'];
            
            $questions = $model->getAllTheQuestionsInATemplate($template_id);
            
            
            
            if($questions===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "question"=>$questions,
                                                            
                            ));
                       
                         }
            
            
        }
        
        
        /**
         * This is the function that retrieves a template question and responses
         */
        public function actionretrievethistemplatequestionandresponse(){
            $model = new FeedbacksTemplateResponse;
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            $reference_id = $_REQUEST['reference_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$template_id);
            $template= FeedbackTemplate::model()->find($criteria);
            
            //write a script to limit template to only analyzable issues. Also retrieve the issue types
            
            if($question_number == 1){
                $issue = $template['first_feedback_question'];
                $issue_type = $template['first_feedback_type'];
                $response = $model->getTheResponseToThisQuestionByThisUser($template_id,$question_number,$reference_id,$issue_type);
                
            }else if($question_number == 2){
                 $issue = $template['second_feedback_question'];
                 $issue_type = $template['second_feedback_type'];
                  $response = $model->getTheResponseToThisQuestionByThisUser($template_id,$question_number,$reference_id,$issue_type);
                
            }else if($question_number == 3){
                $issue = $template['third_feedback_question'];
                $issue_type = $template['third_feedback_type'];
                 $response = $model->getTheResponseToThisQuestionByThisUser($template_id,$question_number,$reference_id,$issue_type);
                
            }else if($question_number == 4){
               $issue = $template['fourth_feedback_question'];
               $issue_type = $template['fourth_feedback_type'];
                $response = $model->getTheResponseToThisQuestionByThisUser($template_id,$question_number,$reference_id,$issue_type);
                
            }else if($question_number == 5){
                $issue = $template['fifth_feedback_question'];
                $issue_type = $template['fifth_feedback_type'];
                 $response = $model->getTheResponseToThisQuestionByThisUser($template_id,$question_number,$reference_id,$issue_type);
                
            }else{
                $issue="";
                $issue_type ="";
                $response ="";
            }
             if($question_number===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "question" => $issue,
                           "issue_type"=>$issue_type,
                           "response"=>$response
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that will retrieve the project id of a code
         */
        public function actionretrievetheprojectidofthiscode(){
            $model = new EnlistmentVerificationCode;
            $code = $_REQUEST['code'];
            $domain = $_REQUEST['domain'];
            $location = $_REQUEST['location'];
            
            $code_id = $model->getTheCodeIdOfThisCode($code);
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$code_id);
            $codedetails = EnlistmentVerificationCode::model()->find($criteria); 
            
                $project_id = $codedetails['enlistment_id'];
            
             if($code===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "code_id" => $code_id,
                            "project_id"=>$project_id,
                           "domain"=>$domain,
                           "code"=>$code,
                           "location"=>$location
                           
                          
                       ));
                       
                }
        }
        
        
        /**
         * This is the function that retrieves all feedback issues that are reviewable
         */
        public function actionlistallReviewIssueForThisCode(){
            
            $code_id = $_REQUEST['code_id'];
            $project_id = $_REQUEST['project_id'];
            $display_type = $_REQUEST['display_type'];
            
            
            $data = [];
             $template = [];
             
              //get all the template for this code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $templates= FeedbackTemplate::model()->findAll($criteria);
            
            foreach($templates as $temp){
               $template[] = $temp['id'];
            }
            
           
             $id = 1;
            if($display_type == "graphic"){
                
                foreach($template as $tem){
            
                
            //retrieve the first question
             $q = "select id as template_id, (select '$id') as id,(select 1) as question_number,(select '$project_id') as project_id,first_feedback_type as issue_type,code_id, first_feedback_question as question from feedback_template
                     Where (id=$tem and first_feedback_purpose='review') and (first_feedback_type ='single_option' or first_feedback_type='multiple_option' or first_feedback_type='single_option_number' or first_feedback_type='multiple_option_number')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
             
             $id = $id + 1;
           //retrieve the second question
             $q = "select id as template_id, (select '$id') as id,(select 2) as question_number,(select '$project_id') as project_id,second_feedback_type as issue_type,code_id,second_feedback_question as question from feedback_template 
                     Where (id=$tem and second_feedback_purpose='review') and (second_feedback_type ='single_option' or second_feedback_type='multiple_option' or second_feedback_type='single_option_number' or second_feedback_type='multiple_option_number')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
             
             $id = $id + 1;          
            //retrieve the third question
            $q = "select id as template_id,(select '$id') as id,(select 3) as question_number,(select '$project_id') as project_id,third_feedback_type as issue_type,code_id,third_feedback_question as question from feedback_template 
                    Where (id=$tem and third_feedback_purpose='review') and (third_feedback_type ='single_option' or third_feedback_type='multiple_option' or third_feedback_type='single_option_number' or third_feedback_type='multiple_option_number')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != null){
                     $data[] = $res;
                 }
             }
            $id = $id + 1;
            //retrieve the fourth question
            $q = "select id as template_id,(select '$id') as id,(select 4) as question_number,(select '$project_id') as project_id,fourth_feedback_type as issue_type,code_id,fourth_feedback_question as question from feedback_template
                    Where (id=$tem and fourth_feedback_purpose='review') and (fourth_feedback_type ='single_option' or fourth_feedback_type='multiple_option' or fourth_feedback_type='single_option_number' or fourth_feedback_type='multiple_option_number')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
            $id = $id + 1; 
            //retrieve the fifth question
           $q = "select id as template_id,(select '$id') as id,(select 5) as question_number,(select '$project_id') as project_id,fifth_feedback_type as issue_type,code_id,fifth_feedback_question as question from feedback_template
                   Where (id=$tem and fifth_feedback_purpose='review') and (fifth_feedback_type ='single_option' or fifth_feedback_type='multiple_option' or fifth_feedback_type='single_option_number' or fifth_feedback_type='multiple_option_number')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                if($res['question'] != null){
                     $data[] = $res;
                 }
                 
             }
             $id = $id + 1; 
                
            }
                
            }else if($display_type == "text"){
                
                foreach($template as $tem){
            
                
            //retrieve the first question
             $q = "select id as template_id, (select '$id') as id,(select 1) as question_number,(select '$project_id') as project_id,first_feedback_type as issue_type,code_id, first_feedback_question as question from feedback_template
                     Where (id=$tem and first_feedback_purpose='review') and (first_feedback_type ='short_text' or first_feedback_type='long_text' or first_feedback_type='double' or first_feedback_type='integer' or first_feedback_type='boolean')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
             
             $id = $id + 1;
           //retrieve the second question
             $q = "select id as template_id, (select '$id') as id,(select 2) as question_number,(select '$project_id') as project_id,second_feedback_type as issue_type,code_id,second_feedback_question as question from feedback_template 
                     Where (id=$tem and second_feedback_purpose='review') and (second_feedback_type ='short_text' or second_feedback_type='long_text' or second_feedback_type='double' or second_feedback_type='integer' or second_feedback_type='boolean')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
             
             $id = $id + 1;          
            //retrieve the third question
            $q = "select id as template_id,(select '$id') as id,(select 3) as question_number,(select '$project_id') as project_id,third_feedback_type as issue_type,code_id,third_feedback_question as question from feedback_template 
                    Where (id=$tem and third_feedback_purpose='review') and (third_feedback_type ='short_text' or third_feedback_type='long_text' or third_feedback_type='double' or third_feedback_type='integer' or third_feedback_type='boolean')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 if($res['question'] != null){
                     $data[] = $res;
                 }
             }
            $id = $id + 1;
            //retrieve the fourth question
            $q = "select id as template_id,(select '$id') as id,(select 4) as question_number,(select '$project_id') as project_id,fourth_feedback_type as issue_type,code_id,fourth_feedback_question as question from feedback_template
                    Where (id=$tem and fourth_feedback_purpose='review') and (fourth_feedback_type ='short_text' or fourth_feedback_type='long_text' or fourth_feedback_type='double' or fourth_feedback_type='integer' or fourth_feedback_type='boolean')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                  if($res['question'] != null){
                     $data[] = $res;
                 }
             }
            $id = $id + 1; 
            //retrieve the fifth question
           $q = "select id as template_id,(select '$id') as id,(select 5) as question_number,(select '$project_id') as project_id,fifth_feedback_type as issue_type,code_id,fifth_feedback_question as question from feedback_template
                   Where (id=$tem and fifth_feedback_purpose='review') and (fifth_feedback_type ='short_text' or fifth_feedback_type='long_text' or fifth_feedback_type='double' or fifth_feedback_type='integer' or fifth_feedback_type='boolean')";
                                 
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                if($res['question'] != null){
                     $data[] = $res;
                 }
                 
             }
             
             $id = $id + 1;    
            }
                
                
            }
            
            
           
            
        
         
          
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "issue"=>$data
                           
                          
                       ));
            
            
        }
        
        
        /**
         * This is the function that retrieves all responses to a question
         */
        public function actionretrieveallresponsestoaquestion(){
            $model = new FeedbacksTemplateResponse;
            
            $template_id = $_REQUEST['template_id'];
            $question_number = $_REQUEST['question_number'];
            $issue_type = $_REQUEST['issue_type'];
            $reviewtype = $_REQUEST['reviewtype'];
            $issue = $_REQUEST['issue'];
            $start_date =date("Y-m-d H:i:s", strtotime($_REQUEST['start_date']));
            $end_date = date("Y-m-d H:i:s", strtotime($_REQUEST['end_date']));
                        
           
            //retrieve all responses to a question number
            
             $responses = $model->getAllTheResponseToThisQuestion($template_id,$question_number,$reviewtype,$issue_type,$start_date,$end_date);
             if($question_number===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysqli_connect_errno() == 0,
                            "question" => $issue,
                           "issue_type"=>$issue_type,
                           "response"=>$responses,
                           "size"=>sizeof($responses)
                          
                           
                           
                          
                       ));
                       
                }
            
            
            
        }
        
}
