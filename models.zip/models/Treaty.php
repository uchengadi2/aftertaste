<?php

/**
 * This is the model class for table "treaty".
 *
 * The followings are the available columns in table 'treaty':
 * @property string $id
 * @property string $domain_id
 * @property string $related_domain_id
 * @property string $resourcegroup_id
 * @property integer $groups
 * @property integer $subgroups
 * @property integer $employees
 * @property string $description
 * @property string $status
 * @property string $treaty_start_date
 * @property string $treaty_end_date
 * @property integer $acceptable
 * @property integer $initiated_by
 * @property integer $accepted_by
 * @property string $date_of_current_renewal
 * @property string $date_terminated
 * @property integer $renewal_initiated_by
 * @property integer $renewal_accepted_by
 * @property integer $terminated_by
 * @property string $termination_reason
 * @property string $date_activated
 * @property integer $activated_by
 * @property integer $extended_by
 * @property string $date_extended
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $relatedDomain
 * @property Resourcegroup $resourcegroup
 * @property Resourcegroupcategory $domain
 * @property Group[] $groups0
 * @property User[] $users
 * @property Subgroup[] $subgroups0
 */
class Treaty extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'treaty';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, related_domain_id, resourcegroup_id', 'required'),
			array('groups, subgroups, employees, acceptable, initiated_by, accepted_by, renewal_initiated_by, renewal_accepted_by, terminated_by, activated_by, extended_by', 'numerical', 'integerOnly'=>true),
			array('domain_id, related_domain_id, resourcegroup_id, status', 'length', 'max'=>10),
			array('description, termination_reason', 'length', 'max'=>250),
			array('treaty_start_date, treaty_end_date, date_of_current_renewal, date_terminated, date_activated, date_extended', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, domain_id, related_domain_id, resourcegroup_id, groups, subgroups, employees, description, status, treaty_start_date, treaty_end_date, acceptable, initiated_by, accepted_by, date_of_current_renewal, date_terminated, renewal_initiated_by, renewal_accepted_by, terminated_by, termination_reason, date_activated, activated_by, extended_by, date_extended', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'relatedDomain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'related_domain_id'),
			'resourcegroup' => array(self::BELONGS_TO, 'Resourcegroup', 'resourcegroup_id'),
			'domain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'domain_id'),
			'groups0' => array(self::MANY_MANY, 'Group', 'treaty_has_group(treaty_id, group_id)'),
			'users' => array(self::MANY_MANY, 'User', 'treaty_has_individual(treaty_id, user_id)'),
			'subgroups0' => array(self::MANY_MANY, 'Subgroup', 'treaty_has_subgroup(treaty_id, subgroup_id)'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'domain_id' => 'Domain',
			'related_domain_id' => 'Related Domain',
			'resourcegroup_id' => 'Resourcegroup',
			'groups' => 'Groups',
			'subgroups' => 'Subgroups',
			'employees' => 'Employees',
			'description' => 'Description',
			'status' => 'Status',
			'treaty_start_date' => 'Treaty Start Date',
			'treaty_end_date' => 'Treaty End Date',
			'acceptable' => 'Acceptable',
			'initiated_by' => 'Initiated By',
			'accepted_by' => 'Accepted By',
			'date_of_current_renewal' => 'Date Of Current Renewal',
			'date_terminated' => 'Date Terminated',
			'renewal_initiated_by' => 'Renewal Initiated By',
			'renewal_accepted_by' => 'Renewal Accepted By',
			'terminated_by' => 'Terminated By',
			'termination_reason' => 'Termination Reason',
			'date_activated' => 'Date Activated',
			'activated_by' => 'Activated By',
			'extended_by' => 'Extended By',
			'date_extended' => 'Date Extended',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('related_domain_id',$this->related_domain_id,true);
		$criteria->compare('resourcegroup_id',$this->resourcegroup_id,true);
		$criteria->compare('groups',$this->groups);
		$criteria->compare('subgroups',$this->subgroups);
		$criteria->compare('employees',$this->employees);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('treaty_start_date',$this->treaty_start_date,true);
		$criteria->compare('treaty_end_date',$this->treaty_end_date,true);
		$criteria->compare('acceptable',$this->acceptable);
		$criteria->compare('initiated_by',$this->initiated_by);
		$criteria->compare('accepted_by',$this->accepted_by);
		$criteria->compare('date_of_current_renewal',$this->date_of_current_renewal,true);
		$criteria->compare('date_terminated',$this->date_terminated,true);
		$criteria->compare('renewal_initiated_by',$this->renewal_initiated_by);
		$criteria->compare('renewal_accepted_by',$this->renewal_accepted_by);
		$criteria->compare('terminated_by',$this->terminated_by);
		$criteria->compare('termination_reason',$this->termination_reason,true);
		$criteria->compare('date_activated',$this->date_activated,true);
		$criteria->compare('activated_by',$this->activated_by);
		$criteria->compare('extended_by',$this->extended_by);
		$criteria->compare('date_extended',$this->date_extended,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Treaty the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
