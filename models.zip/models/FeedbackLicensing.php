<?php

/**
 * This is the model class for table "feedback_licensing".
 *
 * The followings are the available columns in table 'feedback_licensing':
 * @property string $id
 * @property string $plan
 * @property integer $response_limit
 * @property double $cost_per_month
 * @property double $monthly_discount
 * @property double $cost_per_year
 * @property double $yearly_discount
 * @property integer $is_with_monthly_discount
 * @property integer $is_with_yearly_discount
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class FeedbackLicensing extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedback_licensing';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('response_limit, is_with_monthly_discount, is_with_yearly_discount, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('cost_per_month, monthly_discount, cost_per_year, yearly_discount', 'numerical'),
			array('plan', 'length', 'max'=>250),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, plan, response_limit, cost_per_month, monthly_discount, cost_per_year, yearly_discount, is_with_monthly_discount, is_with_yearly_discount, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'plan' => 'Plan',
			'response_limit' => 'Response Limit',
			'cost_per_month' => 'Cost Per Month',
			'monthly_discount' => 'Monthly Discount',
			'cost_per_year' => 'Cost Per Year',
			'yearly_discount' => 'Yearly Discount',
			'is_with_monthly_discount' => 'Is With Monthly Discount',
			'is_with_yearly_discount' => 'Is With Yearly Discount',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('plan',$this->plan,true);
		$criteria->compare('response_limit',$this->response_limit);
		$criteria->compare('cost_per_month',$this->cost_per_month);
		$criteria->compare('monthly_discount',$this->monthly_discount);
		$criteria->compare('cost_per_year',$this->cost_per_year);
		$criteria->compare('yearly_discount',$this->yearly_discount);
		$criteria->compare('is_with_monthly_discount',$this->is_with_monthly_discount);
		$criteria->compare('is_with_yearly_discount',$this->is_with_yearly_discount);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbackLicensing the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that retrieves the response limit of a feedback license
         */
        public function getTheMaxResponseForThisFeedbacklicense($feedback_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$feedback_license_id);
             $feedback = FeedbackLicensing::model()->find($criteria);
             
             return $feedback['response_limit'];
             
        }
}
