<?php

/**
 * This is the model class for table "message_has_buckets".
 *
 * The followings are the available columns in table 'message_has_buckets':
 * @property integer $message_id
 * @property string $bucket_id
 * @property integer $is_bucket_assessed
 * @property string $date_accessed
 * @property integer $accessed_user_id
 */
class MessageHasBuckets extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'message_has_buckets';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('message_id, bucket_id', 'required'),
			array('message_id, is_bucket_assessed, accessed_user_id', 'numerical', 'integerOnly'=>true),
			array('bucket_id', 'length', 'max'=>10),
			array('date_accessed', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('message_id, bucket_id, is_bucket_assessed, date_accessed, accessed_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'message_id' => 'Message',
			'bucket_id' => 'Bucket',
			'is_bucket_assessed' => 'Is Bucket Assessed',
			'date_accessed' => 'Date Accessed',
			'accessed_user_id' => 'Accessed User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('message_id',$this->message_id);
		$criteria->compare('bucket_id',$this->bucket_id,true);
		$criteria->compare('is_bucket_assessed',$this->is_bucket_assessed);
		$criteria->compare('date_accessed',$this->date_accessed,true);
		$criteria->compare('accessed_user_id',$this->accessed_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return MessageHasBuckets the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function inserts assets to messages
         */
        public function attachTheAssetsInTheBucket($message_id,$buckets){
            $counter = 0;
            foreach($buckets as $buck){
                if($this->isTheInsertionOfThisBucketToMessageSuccessful($message_id,$buck)){
                    $counter = $counter + 1;
                }
            }
            return $counter;
        }
        
        
        /**
         * This is the function that determines if insertion of buckets to messages is a success
         */
        public function isTheInsertionOfThisBucketToMessageSuccessful($message_id,$bucket_id){
               
            if(!empty($bucket_id)){
             $cmd =Yii::app()->db->createCommand();
                $result= $cmd->insert('message_has_buckets',
                                        array(
                                           'message_id'=>$message_id,
                                           'bucket_id'=>$bucket_id,
                                          
                ));
            
             if($result>0){
               return true;
            }else{
               return false;
            }
                
            }else{
                return true;
            }
           
        
        }
        
        
        /**
         * This is the function that test if message already has a bucket
         */
        public function isBucketNotAlreadyAssignedToMessage($message_id,$bucket_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_has_buckets')
                    ->where("message_id = $message_id and bucket_id=$bucket_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that retrieves all buckets in a message
         */
        public function getAllBucketsForThisMessage($message_id){
            $targets = [];
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='message_id=:messid';
            $criteria1->params = array(':messid'=>$message_id);
            $buckets= MessageHasBuckets::model()->findAll($criteria1);
            
            foreach($buckets as $buck){
                $targets[] = $buck['bucket_id'];
            }
            return $targets;
        }
        
        
        /**
         * This is the function that removes all buckets for a message
         */
        public function isTheMessageBucketsSuccessfullyRemoved($message_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('message_has_buckets', 'message_id=:messageid', array(':messageid'=>$message_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
                
        }
        
        
        /**
         * This is the function that confirms if a message has some assets
         */
        public function  isMessageWithAssets($message_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('message_has_buckets')
                    ->where("message_id = $message_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /*8
         * This is the function that removes assets from message
         */
        public function isRemovalOfAllAssetsFromMessageSuccessful($message_id){
            if($this->isTheMessageBucketsSuccessfullyRemoved($message_id)){
                return true;
            }else{
                return false;
            }
            
        }
}
