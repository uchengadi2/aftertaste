<?php

/**
 * This is the model class for table "reviews_licensing".
 *
 * The followings are the available columns in table 'reviews_licensing':
 * @property string $id
 * @property string $plan
 * @property integer $views_limit
 * @property double $cost_per_1000_views
 * @property integer $minimum_views_block
 * @property double $plan_cost
 * @property integer $is_with_duration
 * @property string $duration
 * @property integer $could_be_rolled_over
 * @property integer $users_limit
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class ReviewsLicensing extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'reviews_licensing';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('duration', 'required'),
			array('views_limit, minimum_views_block, is_with_duration, could_be_rolled_over, users_limit, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('cost_per_1000_views, plan_cost', 'numerical'),
			array('plan', 'length', 'max'=>250),
			array('duration', 'length', 'max'=>7),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, plan, views_limit, cost_per_1000_views, minimum_views_block, plan_cost, is_with_duration, duration, could_be_rolled_over, users_limit, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'plan' => 'Plan',
			'views_limit' => 'Views Limit',
			'cost_per_1000_views' => 'Cost Per 1000 Views',
			'minimum_views_block' => 'Minimum Views Block',
			'plan_cost' => 'Plan Cost',
			'is_with_duration' => 'Is With Duration',
			'duration' => 'Duration',
			'could_be_rolled_over' => 'Could Be Rolled Over',
			'users_limit' => 'Users Limit',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('plan',$this->plan,true);
		$criteria->compare('views_limit',$this->views_limit);
		$criteria->compare('cost_per_1000_views',$this->cost_per_1000_views);
		$criteria->compare('minimum_views_block',$this->minimum_views_block);
		$criteria->compare('plan_cost',$this->plan_cost);
		$criteria->compare('is_with_duration',$this->is_with_duration);
		$criteria->compare('duration',$this->duration,true);
		$criteria->compare('could_be_rolled_over',$this->could_be_rolled_over);
		$criteria->compare('users_limit',$this->users_limit);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ReviewsLicensing the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that retrieves the views limit of a reviews license
         */
        public function getTheViewsLimitForThisReviews($reviews_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$reviews_license_id);
             $reviews =ReviewsLicensing::model()->find($criteria);
             
             if($reviews['views_limit']>=0){
                 return $reviews['views_limit'];
             }else{
                 return -1;
             }
        }
        
        
         /**
         * This is the function that retrieves the users limit for a reviews license
         */
        public function getTheMaxUserForThisReviewsLicense($reviews_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$reviews_license_id);
             $reviews =ReviewsLicensing::model()->find($criteria);
             
             return $reviews['users_limit'];
        }
        
         /**
         * This is the function that retrieves the duration of reviews license
         */
        public function getTheDurationOfThisReviews($reviews_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$reviews_license_id);
             $reviews =ReviewsLicensing::model()->find($criteria);
             
             return $reviews['duration'];
        }
        
        
          /**
         * This is the function that retrieves the total acquired view of a reviews plan
         */
        public function getTheValueOfViewLimitOfThisLicense($reviews_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$reviews_license_id);
             $reviews =ReviewsLicensing::model()->find($criteria);
             
             return $reviews['views_limit'];
        }
        
        
         /**
         * This is the function that retrieves the total remaining view of a reviews plan
         */
        public function getTheRemainingViewOfThisLicense($reviews_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$reviews_license_id);
             $reviews =ReviewsLicensing::model()->find($criteria);
             
             return $reviews['views_limit'];
        }
        
        
        /**
         * This is the function that retrieves the user limit of a reviews plan
         */
        public function getTheTotalUserLimitOfThisLicense($reviews_license_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$reviews_license_id);
             $reviews =ReviewsLicensing::model()->find($criteria);
             
             return $reviews['users_limit'];
        }
}
