<?php

/**
 * This is the model class for table "blacklist_has_domain".
 *
 * The followings are the available columns in table 'blacklist_has_domain':
 * @property string $blacklist_id
 * @property string $domain_id
 * @property integer $is_conditional
 * @property string $condition
 * @property string $date_blacklisted
 * @property string $date_removed_from_blacklist
 * @property integer $blacklisted_by
 * @property integer $removed_id
 */
class BlacklistHasDomain extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'blacklist_has_domain';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('blacklist_id, domain_id', 'required'),
			array('is_conditional, blacklisted_by, removed_id', 'numerical', 'integerOnly'=>true),
			array('blacklist_id, domain_id', 'length', 'max'=>10),
			array('condition, date_blacklisted, date_removed_from_blacklist', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('blacklist_id, domain_id, is_conditional, condition, date_blacklisted, date_removed_from_blacklist, blacklisted_by, removed_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'blacklist_id' => 'Blacklist',
			'domain_id' => 'Domain',
			'is_conditional' => 'Is Conditional',
			'condition' => 'Condition',
			'date_blacklisted' => 'Date Blacklisted',
			'date_removed_from_blacklist' => 'Date Removed From Blacklist',
			'blacklisted_by' => 'Blacklisted By',
			'removed_id' => 'Removed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('blacklist_id',$this->blacklist_id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('is_conditional',$this->is_conditional);
		$criteria->compare('condition',$this->condition,true);
		$criteria->compare('date_blacklisted',$this->date_blacklisted,true);
		$criteria->compare('date_removed_from_blacklist',$this->date_removed_from_blacklist,true);
		$criteria->compare('blacklisted_by',$this->blacklisted_by);
		$criteria->compare('removed_id',$this->removed_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return BlacklistHasDomain the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
