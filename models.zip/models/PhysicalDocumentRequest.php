<?php

/**
 * This is the model class for table "physical_document_request".
 *
 * The followings are the available columns in table 'physical_document_request':
 * @property string $id
 * @property integer $document_id
 * @property integer $batch_id
 * @property integer $box_id
 * @property integer $requesting_domain_id
 * @property integer $requesting_user_id
 * @property integer $requesting_group_id
 * @property integer $requesting_subgroup_id
 * @property string $request_at
 * @property integer $is_requested
 * @property integer $is_sent
 * @property integer $is_received
 * @property integer $maximum_requesting_period_in_days
 * @property string $request_initiation_date
 * @property integer $request_initiated_by
 * @property integer $is_request_initiated
 * @property integer $is_request_accepted
 * @property string $request_accepted_date
 * @property integer $request_accepted_by
 * @property integer $is_sending_initiated
 * @property integer $is_receipt_confirmed
 * @property string $sending_initiation_date
 * @property integer $sent_by
 * @property string $date_received
 * @property integer $received_by
 * @property integer $is_group_request
 * @property integer $is_subgroup_request
 * @property integer $is_single_user_request
 * @property integer $is_request_cancelled
 * @property integer $request_cancelled_by
 * @property string $request_cancelled_date
 */
class PhysicalDocumentRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'physical_document_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('document_id, batch_id, box_id, requesting_domain_id, requesting_user_id', 'required'),
			array('document_id, batch_id, box_id, requesting_domain_id, requesting_user_id, requesting_group_id, requesting_subgroup_id, is_requested, is_sent, is_received, maximum_requesting_period_in_days, request_initiated_by, is_request_initiated, is_request_accepted, request_accepted_by, is_sending_initiated, is_receipt_confirmed, sent_by, received_by, is_group_request, is_subgroup_request, is_single_user_request, is_request_cancelled, request_cancelled_by', 'numerical', 'integerOnly'=>true),
			array('request_at', 'length', 'max'=>11),
			array('request_initiation_date, request_accepted_date, sending_initiation_date, date_received, request_cancelled_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, document_id, batch_id, box_id, requesting_domain_id, requesting_user_id, requesting_group_id, requesting_subgroup_id, request_at, is_requested, is_sent, is_received, maximum_requesting_period_in_days, request_initiation_date, request_initiated_by, is_request_initiated, is_request_accepted, request_accepted_date, request_accepted_by, is_sending_initiated, is_receipt_confirmed, sending_initiation_date, sent_by, date_received, received_by, is_group_request, is_subgroup_request, is_single_user_request, is_request_cancelled, request_cancelled_by, request_cancelled_date', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'document_id' => 'Document',
			'batch_id' => 'Batch',
			'box_id' => 'Box',
			'requesting_domain_id' => 'Requesting Domain',
			'requesting_user_id' => 'Requesting User',
			'requesting_group_id' => 'Requesting Group',
			'requesting_subgroup_id' => 'Requesting Subgroup',
			'request_at' => 'Request At',
			'is_requested' => 'Is Requested',
			'is_sent' => 'Is Sent',
			'is_received' => 'Is Received',
			'maximum_requesting_period_in_days' => 'Maximum Requesting Period In Days',
			'request_initiation_date' => 'Request Initiation Date',
			'request_initiated_by' => 'Request Initiated By',
			'is_request_initiated' => 'Is Request Initiated',
			'is_request_accepted' => 'Is Request Accepted',
			'request_accepted_date' => 'Request Accepted Date',
			'request_accepted_by' => 'Request Accepted By',
			'is_sending_initiated' => 'Is Sending Initiated',
			'is_receipt_confirmed' => 'Is Receipt Confirmed',
			'sending_initiation_date' => 'Sending Initiation Date',
			'sent_by' => 'Sent By',
			'date_received' => 'Date Received',
			'received_by' => 'Received By',
			'is_group_request' => 'Is Group Request',
			'is_subgroup_request' => 'Is Subgroup Request',
			'is_single_user_request' => 'Is Single User Request',
			'is_request_cancelled' => 'Is Request Cancelled',
			'request_cancelled_by' => 'Request Cancelled By',
			'request_cancelled_date' => 'Request Cancelled Date',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('document_id',$this->document_id);
		$criteria->compare('batch_id',$this->batch_id);
		$criteria->compare('box_id',$this->box_id);
		$criteria->compare('requesting_domain_id',$this->requesting_domain_id);
		$criteria->compare('requesting_user_id',$this->requesting_user_id);
		$criteria->compare('requesting_group_id',$this->requesting_group_id);
		$criteria->compare('requesting_subgroup_id',$this->requesting_subgroup_id);
		$criteria->compare('request_at',$this->request_at,true);
		$criteria->compare('is_requested',$this->is_requested);
		$criteria->compare('is_sent',$this->is_sent);
		$criteria->compare('is_received',$this->is_received);
		$criteria->compare('maximum_requesting_period_in_days',$this->maximum_requesting_period_in_days);
		$criteria->compare('request_initiation_date',$this->request_initiation_date,true);
		$criteria->compare('request_initiated_by',$this->request_initiated_by);
		$criteria->compare('is_request_initiated',$this->is_request_initiated);
		$criteria->compare('is_request_accepted',$this->is_request_accepted);
		$criteria->compare('request_accepted_date',$this->request_accepted_date,true);
		$criteria->compare('request_accepted_by',$this->request_accepted_by);
		$criteria->compare('is_sending_initiated',$this->is_sending_initiated);
		$criteria->compare('is_receipt_confirmed',$this->is_receipt_confirmed);
		$criteria->compare('sending_initiation_date',$this->sending_initiation_date,true);
		$criteria->compare('sent_by',$this->sent_by);
		$criteria->compare('date_received',$this->date_received,true);
		$criteria->compare('received_by',$this->received_by);
		$criteria->compare('is_group_request',$this->is_group_request);
		$criteria->compare('is_subgroup_request',$this->is_subgroup_request);
		$criteria->compare('is_single_user_request',$this->is_single_user_request);
		$criteria->compare('is_request_cancelled',$this->is_request_cancelled);
		$criteria->compare('request_cancelled_by',$this->request_cancelled_by);
		$criteria->compare('request_cancelled_date',$this->request_cancelled_date,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return PhysicalDocumentRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
