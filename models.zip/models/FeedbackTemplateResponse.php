<?php

/**
 * This is the model class for table "feedback_template_response".
 *
 * The followings are the available columns in table 'feedback_template_response':
 * @property string $id
 * @property string $template_id
 * @property string $user_id
 * @property integer $first_feedback_response_boolean
 * @property string $first_feedback_response_text
 * @property integer $first_feedback_response_integer
 * @property double $first_feedback_response_double
 * @property integer $second_feedback_response_boolean
 * @property string $second_feedback_response_text
 * @property integer $second_feedback_response_integer
 * @property double $second_feedback_response_double
 * @property integer $third_feedback_response_boolean
 * @property string $third_feedback_response_text
 * @property integer $third_feedback_response_integer
 * @property double $third_feedback_response_double
 * @property integer $fourth_feedback_response_boolean
 * @property string $fourth_feedback_response_text
 * @property integer $fourth_feedback_response_integer
 * @property double $fourth_feedback_response_double
 * @property integer $fifth_feedback_response_boolean
 * @property string $fifth_feedback_response_text
 * @property integer $fifth_feedback_response_integer
 * @property double $fifth_feedback_response_double
 * @property string $date_provided
 */
class FeedbackTemplateResponse extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'feedback_template_response';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('template_id, user_id', 'required'),
			array('first_feedback_response_boolean, first_feedback_response_integer, second_feedback_response_boolean, second_feedback_response_integer, third_feedback_response_boolean, third_feedback_response_integer, fourth_feedback_response_boolean, fourth_feedback_response_integer, fifth_feedback_response_boolean, fifth_feedback_response_integer', 'numerical', 'integerOnly'=>true),
			array('first_feedback_response_double, second_feedback_response_double, third_feedback_response_double, fourth_feedback_response_double, fifth_feedback_response_double', 'numerical'),
			array('template_id, user_id', 'length', 'max'=>10),
			array('first_feedback_response_text, second_feedback_response_text, third_feedback_response_text, fourth_feedback_response_text, fifth_feedback_response_text, date_provided', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, template_id, user_id, first_feedback_response_boolean, first_feedback_response_text, first_feedback_response_integer, first_feedback_response_double, second_feedback_response_boolean, second_feedback_response_text, second_feedback_response_integer, second_feedback_response_double, third_feedback_response_boolean, third_feedback_response_text, third_feedback_response_integer, third_feedback_response_double, fourth_feedback_response_boolean, fourth_feedback_response_text, fourth_feedback_response_integer, fourth_feedback_response_double, fifth_feedback_response_boolean, fifth_feedback_response_text, fifth_feedback_response_integer, fifth_feedback_response_double, date_provided', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'template_id' => 'Template',
			'user_id' => 'User',
			'first_feedback_response_boolean' => 'First Feedback Response Boolean',
			'first_feedback_response_text' => 'First Feedback Response Text',
			'first_feedback_response_integer' => 'First Feedback Response Integer',
			'first_feedback_response_double' => 'First Feedback Response Double',
			'second_feedback_response_boolean' => 'Second Feedback Response Boolean',
			'second_feedback_response_text' => 'Second Feedback Response Text',
			'second_feedback_response_integer' => 'Second Feedback Response Integer',
			'second_feedback_response_double' => 'Second Feedback Response Double',
			'third_feedback_response_boolean' => 'Third Feedback Response Boolean',
			'third_feedback_response_text' => 'Third Feedback Response Text',
			'third_feedback_response_integer' => 'Third Feedback Response Integer',
			'third_feedback_response_double' => 'Third Feedback Response Double',
			'fourth_feedback_response_boolean' => 'Fourth Feedback Response Boolean',
			'fourth_feedback_response_text' => 'Fourth Feedback Response Text',
			'fourth_feedback_response_integer' => 'Fourth Feedback Response Integer',
			'fourth_feedback_response_double' => 'Fourth Feedback Response Double',
			'fifth_feedback_response_boolean' => 'Fifth Feedback Response Boolean',
			'fifth_feedback_response_text' => 'Fifth Feedback Response Text',
			'fifth_feedback_response_integer' => 'Fifth Feedback Response Integer',
			'fifth_feedback_response_double' => 'Fifth Feedback Response Double',
			'date_provided' => 'Date Provided',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('template_id',$this->template_id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('first_feedback_response_boolean',$this->first_feedback_response_boolean);
		$criteria->compare('first_feedback_response_text',$this->first_feedback_response_text,true);
		$criteria->compare('first_feedback_response_integer',$this->first_feedback_response_integer);
		$criteria->compare('first_feedback_response_double',$this->first_feedback_response_double);
		$criteria->compare('second_feedback_response_boolean',$this->second_feedback_response_boolean);
		$criteria->compare('second_feedback_response_text',$this->second_feedback_response_text,true);
		$criteria->compare('second_feedback_response_integer',$this->second_feedback_response_integer);
		$criteria->compare('second_feedback_response_double',$this->second_feedback_response_double);
		$criteria->compare('third_feedback_response_boolean',$this->third_feedback_response_boolean);
		$criteria->compare('third_feedback_response_text',$this->third_feedback_response_text,true);
		$criteria->compare('third_feedback_response_integer',$this->third_feedback_response_integer);
		$criteria->compare('third_feedback_response_double',$this->third_feedback_response_double);
		$criteria->compare('fourth_feedback_response_boolean',$this->fourth_feedback_response_boolean);
		$criteria->compare('fourth_feedback_response_text',$this->fourth_feedback_response_text,true);
		$criteria->compare('fourth_feedback_response_integer',$this->fourth_feedback_response_integer);
		$criteria->compare('fourth_feedback_response_double',$this->fourth_feedback_response_double);
		$criteria->compare('fifth_feedback_response_boolean',$this->fifth_feedback_response_boolean);
		$criteria->compare('fifth_feedback_response_text',$this->fifth_feedback_response_text,true);
		$criteria->compare('fifth_feedback_response_integer',$this->fifth_feedback_response_integer);
		$criteria->compare('fifth_feedback_response_double',$this->fifth_feedback_response_double);
		$criteria->compare('date_provided',$this->date_provided,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return FeedbackTemplateResponse the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that registers a customers feedback response
         */
        public function isRegisteringTheResponseOptionsASuccess($model){
            
             $model = new FeedbackTemplateOptionResponse;
            $counter =0;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$pmodel->template_id);
             $template = FeedbackTemplate::model()->find($criteria);
             
             
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';   
             $criteria->params = array(':id'=>$pmodel->id);
             $response = FeedbackTemplateResponse::model()->find($criteria);
             
             if($this->isThisFeedbackWithOptions($template)){
                 
                 //addressing the first feedback question
              if($template['is_first_feedback_included'] == 1){
                 if($this->isFirstFeedbackWithOptions($template['first_feedback_type'])){
                     //register this feedback
                     if($template['first_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_single_option'],$template['first_feedback_type']);
                     }else if($template['first_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_multiple_option'],$template['first_feedback_type']);
                     }else if($template['first_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_single_option_number'],$template['first_feedback_type']);
                     }else if($template['first_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['first_feedback_response_multiple_option_number'],$template['first_feedback_type']);
                     }
                     
                 }
                $counter = $counter + 1;
             }
             
             //addressing the second feedback question
              if($template['is_second_feedback_included'] == 1){
                 if($this->isSecondFeedbackWithOptions($template['second_feedback_type'])){
                       //register this feedback
                    if($template['second_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_single_option'],$template['second_feedback_type']);
                     }else if($template['second_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_multiple_option'],$template['second_feedback_type']);
                     }else if($template['second_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_single_option_number'],$template['second_feedback_type']);
                     }else if($template['second_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['second_feedback_response_multiple_option_number'],$template['second_feedback_type']);
                     }
                   }
                   $counter = $counter + 1;
                 
             }
             
              //addressing the third feedback question
             
            if($template['is_third_feedback_included'] == 1){
                 if($this->isThirdFeedbackWithOptions($template['third_feedback_type'])){
                     //register this feedback
                    if($template['third_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_single_option'],$template['third_feedback_type']);
                     }else if($template['third_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_multiple_option'],$template['third_feedback_type']);
                     }else if($template['third_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_single_option_number'],$template['third_feedback_type']);
                     }else if($template['third_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['third_feedback_response_multiple_option_number'],$template['third_feedback_type']);
                     }
                }
                 $counter = $counter + 1;
             }
             
              //addressing the fourth feedback question
             if($template['is_fourth_feedback_included'] == 1){
                 if($this->isFourthFeedbackWithOptions($template['fourth_feedback_type'])){
                     //register this feedback
                    if($template['fourth_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_single_option'],$template['fourth_feedback_type']);
                     }else if($template['fourth_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_multiple_option'],$template['fourth_feedback_type']);
                     }else if($template['fourth_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_single_option_number'],$template['fourth_feedback_type']);
                     }else if($template['fourth_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fourth_feedback_response_multiple_option_number'],$template['fourth_feedback_type']);
                     }
                }
                 $counter = $counter + 1;
             }
             
             
             //addressing the fifth feedback question
             
                if($template['is_fifth_feedback_included'] == 1){
                    if($this->isFifthFeedbackWithOptions($template['fifth_feedback_type'])){
                     //register this feedback
                    if($template['fifth_feedback_type'] =='single_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_single_option'],$template['fifth_feedback_type']);
                     }else if($template['fifth_feedback_type'] =='multiple_option'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_multiple_option'],$template['fifth_feedback_type']);
                     }else if($template['fifth_feedback_type'] =='single_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_single_option_number'],$template['fifth_feedback_type']);
                     }else if($template['fifth_feedback_type'] =='multiple_option_number'){
                         $model->registerFeedbackOptionResponse($template['id'],$response['fifth_feedback_response_multiple_option_number'],$template['fifth_feedback_type']);
                     }
                }
                  $counter = $counter + 1; 
             }
             
             if($counter>0){
                 return true;
             }else{
                 return false;
             }
                 
             }else{
                 return true;
                 
             }
             
        }
        
        
       /**
        * This is the function that provides the total number of responses on a feedback question
        */
        public function getTheTotalResponseOnThisFeedbackIssue($issue_type,$template_id,$question_number,$start_date,$end_date){
            
        }
}
