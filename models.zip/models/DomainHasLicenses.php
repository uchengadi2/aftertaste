<?php

/**
 * This is the model class for table "domain_has_licenses".
 *
 * The followings are the available columns in table 'domain_has_licenses':
 * @property string $id
 * @property string $domain_id
 * @property integer $feedback_license_id
 * @property integer $reviews_license_id
 * @property integer $total_acquired_views
 * @property integer $total_remaining_views
 * @property string $license_option
 * @property string $feedback_license_status
 * @property string $reviews_license_status
 * @property string $reviews_license_end_date
 * @property string $feedback_license_end_date
 * @property integer $maximum_reviews_users_number
 * @property integer $create_user_id
 * @property integer $update_user_id
 */
class DomainHasLicenses extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_has_licenses';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, license_option, feedback_license_status, reviews_license_status', 'required'),
			array('feedback_license_id, reviews_license_id, total_acquired_views, total_remaining_views, maximum_reviews_users_number, create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('domain_id', 'length', 'max'=>10),
			array('license_option, feedback_license_status, reviews_license_status', 'length', 'max'=>8),
			array('reviews_license_end_date, feedback_license_end_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, domain_id, feedback_license_id, reviews_license_id, total_acquired_views, total_remaining_views, license_option, feedback_license_status, reviews_license_status, reviews_license_end_date, feedback_license_end_date, maximum_reviews_users_number, create_user_id, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'domain_id' => 'Domain',
			'feedback_license_id' => 'Feedback License',
			'reviews_license_id' => 'Reviews License',
			'total_acquired_views' => 'Total Acquired Views',
			'total_remaining_views' => 'Total Remaining Views',
			'license_option' => 'License Option',
			'feedback_license_status' => 'Feedback License Status',
			'reviews_license_status' => 'Reviews License Status',
			'reviews_license_end_date' => 'Reviews License End Date',
			'feedback_license_end_date' => 'Feedback License End Date',
			'maximum_reviews_users_number' => 'Maximum Reviews Users Number',
			'create_user_id' => 'Create User',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('feedback_license_id',$this->feedback_license_id);
		$criteria->compare('reviews_license_id',$this->reviews_license_id);
		$criteria->compare('total_acquired_views',$this->total_acquired_views);
		$criteria->compare('total_remaining_views',$this->total_remaining_views);
		$criteria->compare('license_option',$this->license_option,true);
		$criteria->compare('feedback_license_status',$this->feedback_license_status,true);
		$criteria->compare('reviews_license_status',$this->reviews_license_status,true);
		$criteria->compare('reviews_license_end_date',$this->reviews_license_end_date,true);
		$criteria->compare('feedback_license_end_date',$this->feedback_license_end_date,true);
		$criteria->compare('maximum_reviews_users_number',$this->maximum_reviews_users_number);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainHasLicenses the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that calculates the total acquired views
         */
        public function getTheTotalAcquiredViews($reviews_license_id,$number_of_views_block){
            $model = new ReviewsLicensing;
            $license_view_limit = $model->getTheViewsLimitForThisReviews($reviews_license_id);
            if($license_view_limit==0){
                $total_acquired_views = 0;
            }else if($license_view_limit<0){
                $total_acquired_views = -1;
            }else{
                $total_acquired_views = (int)$license_view_limit * (int)$number_of_views_block; 
            }
                  
            return $total_acquired_views;
            
        }
        
        /**
         * This is the function that gets the maximum number of users required for a license
         */
        public function getTheMaximumUsersRequired($reviews_license_id){
            $model = new ReviewsLicensing;
            $user_limit = $model->getTheMaxUserForThisReviewsLicense($reviews_license_id);
            return $user_limit;
        }
        
        /**
         * This is the function that retrieves the total number of remianing response of a feedback license
         */
        public function getTheTotalRemainingFeedbackResponse($feedback_license_id,$number_of_months){
            $model = new FeedbackLicensing;
            $response_limit = $model->getTheMaxResponseForThisFeedbacklicense($feedback_license_id);
            if($response_limit == 0){
                $total_acquired_response = 0;
            }else{
               $total_acquired_response = (int)$response_limit *  (int)$number_of_months; 
            }
            return $total_acquired_response;
        }
        
        
        /**
         * This is the function that will calculate the end date of a reviews license
         */
        public function getTheReviewsEndDate($reviews_license_id,$number_of_views_block){
            $model = new ReviewsLicensing;
            $license_duration = $model->getTheDurationOfThisReviews($reviews_license_id);
            if($license_duration =="none"){
                return null;
            }else if($license_duration =="monthly"){
                $end_date = $this->getTheEndDateOfThisReviewsLicense($number_of_views_block,$license_duration);
                return $end_date;
            }else if($license_duration =="yearly"){
                $end_date = $this->getTheEndDateOfThisReviewsLicense($number_of_views_block,$license_duration);
                return $end_date;
                
            }
        }
        
        
         /**
         * This is the function that set the end of a  subscription date
         */
        public function getTheEndDateOfThisReviewsLicense($duration,$period){
            
            $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            if($period == "monthly"){
                $end_date = date("Y-m-d",mktime(0, 0, 0, date("m")+ $duration  , date("d")-1, date("Y")));
            }else if($period == "yearly"){
                $monthly = (int)$duration * 12;
                $end_date = date("Y-m-d",mktime(0, 0, 0, date("m")+$monthly  , date("d")-1, date("Y")));
            }
            return $end_date;
        }
        
        
        /**
         * This is the function that retrieves the end date of a feedback license
         */
        public function getTheFeedbackLIcenseEndDate($feedback_license_id,$number_of_months){
            $end_date = $this->getThisFeedbackLicenseEndDate($number_of_months);
            return $end_date;
            
        }
        
        
         /**
         * This is the function that set the end of a  subscription date
         */
        public function getThisFeedbackLicenseEndDate($duration){
            
            $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
             $end_date = date("Y-m-d",mktime(0, 0, 0, date("m")+$duration  , date("d")-1, date("Y")));
            
             return $end_date;
        }
        
        
        /**
         * This is the function that confirms if a domain has already assigned license or not
         */
        public function isThisDomainWithoutLicense($domain_id){
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('domain_has_licenses')
                    ->where("domain_id = $domain_id");
                $result = $cmd->queryScalar();
                
                if($result == 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * this is the function that retrieves the adjusted date of the end date of feedback license
         */
        public function getTheNewDateForThisFeedbackLicense($feedback_license_end_date,$number_of_months){
            
            $current_end_date = getdate(strtotime($feedback_license_end_date));
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $new_date = $this->getThisNewEndDate($current_end_date,$today,$number_of_months);
           return $new_date;
        }
        
        
        /**
         * This is the function that calculates the new end date of a feedback license
         */
        public function getThisNewEndDate($end_date,$today,$number_of_months){
            
            if($end_date['year'] -$today['year']<=0 ){
                            if($end_date['mon']- $today['mon']<=0 ){
                                if(($end_date['mday']- $today['mday']<=0 )){
                                    $new_end_date = (mktime(0, 0, 0, date("m")+$number_of_months  , date("d"), date("Y")));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m") + $number_of_months  , date("d")+$day_diff, date("Y")));
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon'];
                                if($end_date['mon']- $today['mon']<=0){
                                   $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff + $number_of_months  , date("d"), date("Y")));  
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff + $number_of_months  , date("d")+$day_diff, date("Y")));
                                }
                            }
                        }else{
                            $year_diff = $end_date['year'] -$today['year'];
                            if($end_date['mon']- $today['mon']<=0){
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m") + $number_of_months  , date("d"), date("Y") + $year_diff));
                                }else{
                                   $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+ $number_of_months  , date("d")+$day_diff, date("Y")+$year_diff)); 
                                }
                            }else{
                                $mon_diff = $end_date['mon']- $today['mon'];
                                if($end_date['mday']- $today['mday']<=0){
                                    $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff + $number_of_months  , date("d"), date("Y")+$year_diff));
                                }else{
                                    $day_diff = $end_date['mday']- $today['mday'];
                                     $new_end_date = (mktime(0, 0, 0, date("m")+$mon_diff + $number_of_months  , date("d")+$day_diff, date("Y")+$year_diff)); 
                                }
                            }
                        }
                       // extend the value of the service by then= new date value
                        $new_expiry_date = date("Y-m-d", $new_end_date);
                        return $new_expiry_date;
        }
        
        /**
         * This is the function that computes the reviews end date
         */
        public function getTheNewDateOfThisReviewsLicense($reviews_license_id,$reviews_license_end_date,$number_of_views_block){
            $model = new ReviewsLicensing;
            if($reviews_license_end_date == null){
                $end_date = $this->getTheReviewsEndDate($reviews_license_id,$number_of_views_block);
                return $end_date;
            }else{
                $license_duration = $model->getTheDurationOfThisReviews($reviews_license_id);
             if($license_duration =="none"){
                return null;
            }else if($license_duration =="monthly"){
                $end_date = $this->getTheNewDateForThisReviewsLicense($reviews_license_end_date,$number_of_views_block);;
                return $end_date;
            }else if($license_duration =="yearly"){
                $end_date = $this->getTheNewDateForThisReviewsLicense($reviews_license_end_date,$number_of_views_block);;
                return $end_date;
                
            }
                
            }
        }
        
        
         /**
         * this is the function that retrieves the adjusted date of the end date of reviews license
         */
        public function getTheNewDateForThisReviewsLicense($reviews_license_end_date,$number_of_views_block){
            
            $current_end_date = getdate(strtotime($reviews_license_end_date));
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $new_date = $this->getThisNewEndDate($current_end_date,$today,$number_of_views_block);
           return $new_date;
        }
        
        
        /**
         * This is the function that will modify the reviews license of a domain
         */
        public function isTheModificationOfDomainLicenseASuccess($id,$reviews_license_id ){
            $model= DomainHasLicenses::model()->findByPk($id); 
            $model->reviews_license_id = $reviews_license_id;
            if($model->save()){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that gets the maximum reviews user limit of a reviews license
         */
        public function getTheUserLimitOfThisReviewsLicense($reviews_license_id,$number_of_views_block){
            $model = new ReviewsLicensing;
            $license_user_limit = $model->getTheMaxUserForThisReviewsLicense($reviews_license_id);
            
             if($license_user_limit==0){
                $total_user_limit = 0;
            }else if($license_user_limit<0){
                $total_user_limit = -1;
            }else{
                $total_user_limit = (int)$license_user_limit * (int)$number_of_views_block; 
            }
            
            return $total_user_limit;
        }
        
        
        /**
         * This is the function that confirms if total views acquired is unlimited
         */
        public function isLicenseViewUnlimited($reviews_license_id){
            $model = new ReviewsLicensing;
            $view_limit = $model->getTheValueOfViewLimitOfThisLicense($reviews_license_id);
            if($view_limit<0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if remaining views  is unlimited
         */
        public function isTotalRemainingViewsUnlimited($reviews_license_id){
            $model = new ReviewsLicensing;
            $total_remaining_view = $model->getTheRemainingViewOfThisLicense($reviews_license_id);
            if($total_remaining_view<0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if remaining views  is unlimited
         */
        public function isUserLimitless($reviews_license_id){
            $model = new ReviewsLicensing;
            $user_limit = $model->getTheTotalUserLimitOfThisLicense($reviews_license_id);
            if($user_limit<0){
                return true;
            }else{
                return false;
            }
        }
}
