<?php

/**
 * This is the model class for table "document_in_location".
 *
 * The followings are the available columns in table 'document_in_location':
 * @property string $id
 * @property integer $document_id
 * @property string $location_id
 * @property string $type
 * @property string $status
 * @property string $in_date
 * @property string $out_date
 * @property integer $assigned_by
 * @property integer $update_user_id
 */
class DocumentInLocation extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'document_in_location';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('id, document_id, location_id, status', 'required'),
			array('document_id, assigned_by, update_user_id', 'numerical', 'integerOnly'=>true),
			array('id, location_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>8),
			array('status', 'length', 'max'=>3),
			array('in_date, out_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, document_id, location_id, type, status, in_date, out_date, assigned_by, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'document_id' => 'Document',
			'location_id' => 'Location',
			'type' => 'Type',
			'status' => 'Status',
			'in_date' => 'In Date',
			'out_date' => 'Out Date',
			'assigned_by' => 'Assigned By',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('document_id',$this->document_id);
		$criteria->compare('location_id',$this->location_id,true);
		$criteria->compare('type',$this->type,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('in_date',$this->in_date,true);
		$criteria->compare('out_date',$this->out_date,true);
		$criteria->compare('assigned_by',$this->assigned_by);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DocumentInLocation the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
       
}
