<?php

/**
 * This is the model class for table "package_content_verification".
 *
 * The followings are the available columns in table 'package_content_verification':
 * @property string $id
 * @property string $package_id
 * @property string $status
 * @property string $remark
 * @property integer $verified_by
 * @property string $date_of_verification
 * @property string $date_of_delivery_confirmation
 */
class PackageContentVerification extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'package_content_verification';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('package_id, status, verified_by', 'required'),
			array('verified_by', 'numerical', 'integerOnly'=>true),
			array('package_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>19),
			array('remark, date_of_verification, date_of_delivery_confirmation', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, package_id, status, remark, verified_by, date_of_verification, date_of_delivery_confirmation', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'package_id' => 'Package',
			'status' => 'Status',
			'remark' => 'Remark',
			'verified_by' => 'Verified By',
			'date_of_verification' => 'Date Of Verification',
			'date_of_delivery_confirmation' => 'Date Of Delivery Confirmation',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('package_id',$this->package_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('remark',$this->remark,true);
		$criteria->compare('verified_by',$this->verified_by);
		$criteria->compare('date_of_verification',$this->date_of_verification,true);
		$criteria->compare('date_of_delivery_confirmation',$this->date_of_delivery_confirmation,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return PackageContentVerification the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
