<?php

/**
 * This is the model class for table "order".
 *
 * The followings are the available columns in table 'order':
 * @property string $id
 * @property string $order_number
 * @property string $status
 * @property string $confirmation_status
 * @property integer $is_term_acceptable
 * @property string $delivery_address
 * @property integer $delivery_city_id
 * @property string $receiver_mobile_number
 * @property string $address_landmark
 * @property string $nearest_bus_stop
 * @property string $person_in_care_of
 * @property string $payment_preference
 * @property string $date_ordered
 * @property string $last_updated_date
 * @property integer $ordered_by
 * @property integer $order_updated_by
 */
class Order extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'order';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status, confirmation_status', 'required'),
			array('is_term_acceptable, delivery_city_id, ordered_by, order_updated_by', 'numerical', 'integerOnly'=>true),
			array('order_number', 'length', 'max'=>50),
			array('status', 'length', 'max'=>6),
			array('confirmation_status', 'length', 'max'=>11),
			array('delivery_address, address_landmark, nearest_bus_stop, person_in_care_of', 'length', 'max'=>250),
			array('receiver_mobile_number', 'length', 'max'=>100),
			array('payment_preference', 'length', 'max'=>7),
			array('date_ordered, last_updated_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, order_number, status, confirmation_status, is_term_acceptable, delivery_address, delivery_city_id, receiver_mobile_number, address_landmark, nearest_bus_stop, person_in_care_of, payment_preference, date_ordered, last_updated_date, ordered_by, order_updated_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'order_number' => 'Order Number',
			'status' => 'Status',
			'confirmation_status' => 'Confirmation Status',
			'is_term_acceptable' => 'Is Term Acceptable',
			'delivery_address' => 'Delivery Address',
			'delivery_city_id' => 'Delivery City',
			'receiver_mobile_number' => 'Receiver Mobile Number',
			'address_landmark' => 'Address Landmark',
			'nearest_bus_stop' => 'Nearest Bus Stop',
			'person_in_care_of' => 'Person In Care Of',
			'payment_preference' => 'Payment Preference',
			'date_ordered' => 'Date Ordered',
			'last_updated_date' => 'Last Updated Date',
			'ordered_by' => 'Ordered By',
			'order_updated_by' => 'Order Updated By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('order_number',$this->order_number,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('confirmation_status',$this->confirmation_status,true);
		$criteria->compare('is_term_acceptable',$this->is_term_acceptable);
		$criteria->compare('delivery_address',$this->delivery_address,true);
		$criteria->compare('delivery_city_id',$this->delivery_city_id);
		$criteria->compare('receiver_mobile_number',$this->receiver_mobile_number,true);
		$criteria->compare('address_landmark',$this->address_landmark,true);
		$criteria->compare('nearest_bus_stop',$this->nearest_bus_stop,true);
		$criteria->compare('person_in_care_of',$this->person_in_care_of,true);
		$criteria->compare('payment_preference',$this->payment_preference,true);
		$criteria->compare('date_ordered',$this->date_ordered,true);
		$criteria->compare('last_updated_date',$this->last_updated_date,true);
		$criteria->compare('ordered_by',$this->ordered_by);
		$criteria->compare('order_updated_by',$this->order_updated_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Order the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
